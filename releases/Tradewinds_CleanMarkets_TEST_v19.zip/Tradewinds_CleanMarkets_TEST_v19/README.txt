Tradewinds v19 — clean marketplace layout, all ports

The redundant upper Tea amount/Buy/Max/Sell/Max row is removed in EVERY port.
The upper market panel is shortened to fit its item list. The Buy/Sell/Leave
menu and lower trading window move up, preserving a 20-pixel gap below it.
Tea remains between General Merchandise and Arms. Its quantity controls are
in the lower Buy/Sell window, where the main buttons and Sell All include Tea.
Tea still buys exclusively in Tanchon and sells elsewhere. All other v18 ship,
warehouse, commodity, pricing, command and save behavior is unchanged.

Only assets/xml/int_buildings.txt changes; the executable and other resource
payloads are verified byte-identical to v18. The shared marketplace window is
used by every port; city-specific data do not override this layout.

INSTALL
Close the game, back up saves and your current patch files, extract the ZIP and
replace BOTH executable and TW1_00.data in the original game folder. No DLL or
save replacement is needed. Startup logs still say v18 because the EXE is the
same. Verify appearance at any port; test Tea using Buy/Sell in Tanchon.

VALIDATION
94 regression checks and five lower Tea trading tests passed, covering buying,
selling, Sell All, quantity controls, source restrictions, warehouse trades and
window bounds. All unrelated resources and executable bytes are unchanged.
Actual Windows rendering remains to be checked by the user.

REBUILD
source/remove_tea_shortcuts.py --base <v18 folder> --output <v19 folder>
