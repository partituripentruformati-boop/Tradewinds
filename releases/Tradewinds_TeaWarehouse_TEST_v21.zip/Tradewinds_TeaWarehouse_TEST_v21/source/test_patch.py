from pathlib import Path
import sys,struct,json,argparse,copy,xml.etree.ElementTree as ET
ROOT=Path(__file__).parent;sys.path.insert(0,str(ROOT/'python-libs'))
import pefile
from unicorn import Uc,UC_ARCH_X86,UC_MODE_32,UC_HOOK_CODE
from unicorn.x86_const import *
parser=argparse.ArgumentParser()
parser.add_argument('--output',type=Path,required=True)
parser.add_argument('--original-data',type=Path,required=True)
args=parser.parse_args()
OUT=args.output;exe=OUT/'TradewindsClassic_100Ships_2xHull_ShipyardCatalog_TEST.exe';pe=pefile.PE(str(exe))
syms=json.loads((OUT/'patch-manifest.json').read_text())['symbols']
regional=(OUT/'regional-manifest.json').exists()
TYPES=['junk','onemast','twomast','brigantine','megaship'];COSTS=[1000,8000,12000,20000,30000]
YARD=0x210000;MANAGER=0x200100;FLEET=0x200200;PLAYER=0x200300;STACK=0x318000
passed=[]
class Machine:
 def __init__(self,count=1):
  self.u=Uc(UC_ARCH_X86,UC_MODE_32)
  for base,size in [(0,0x1000),(0x400000,max(0x80000,pe.OPTIONAL_HEADER.SizeOfImage)),(0x200000,0x80000),(0x300000,0x20000)]:self.u.mem_map(base,size)
  self.u.mem_write(0x400000,pe.get_memory_mapped_image())
  self.w(0x465d68,0x200400);self.w(0x465dac,MANAGER);self.w(0x465d74,PLAYER);self.w(FLEET,count)
  self.u.reg_write(UC_X86_REG_ESP,STACK);self.u.reg_write(UC_X86_REG_ESI,YARD)
  self.u.reg_write(UC_X86_REG_EBX,0);self.u.reg_write(UC_X86_REG_EBP,0x12345678)
  self.registered={};self.created=[];self.freed=[];self.notifications=0;self.shown=[];self.random_calls=0;self.next=0x220000;self.stops=set();self.alloc=0x250000
  self.u.hook_add(UC_HOOK_CODE,self.hook)
 def r(self,a):return struct.unpack('<I',self.u.mem_read(a,4))[0]
 def w(self,a,v):self.u.mem_write(a,struct.pack('<I',v&0xffffffff))
 def str(self,a):
  b=bytearray()
  while (v:=bytes(self.u.mem_read(a+len(b),1)))!=b'\0':b+=v
  return b.decode()
 def string(self,a,text):
  p=self.alloc;self.alloc+=0x100;self.u.mem_write(p,text.encode()+b'\0');self.w(a,len(text));self.w(a+4,p)
 def ret(self,pop=0,eax=None):
  esp=self.u.reg_read(UC_X86_REG_ESP);dest=self.r(esp)
  self.u.reg_write(UC_X86_REG_ESP,esp+4+pop)
  if eax is not None:self.u.reg_write(UC_X86_REG_EAX,eax)
  self.u.reg_write(UC_X86_REG_EIP,dest)
 def hook(self,u,a,n,user):
  if a in self.stops:u.emu_stop();return
  esp=u.reg_read(UC_X86_REG_ESP);ecx=u.reg_read(UC_X86_REG_ECX)
  if a==0x4375c7:self.random_calls+=1;raise AssertionError('Random generator unexpectedly reached')
  if a==0x42d0e0:
   self.string(ecx,self.str(self.r(esp+4)));self.ret(4,ecx)
  elif a==0x42d330:self.ret(0,self.r(ecx+4))
  elif a==0x4346f0:
   assert ecx==0x200400
   command=self.str(self.r(esp+4));owner=self.r(esp+8)
   assert command not in self.registered
   self.registered[command]=owner;self.ret(8)
  elif a==0x42d390:
   self.ret(4,int(self.str(self.r(ecx+4))==self.str(self.r(esp+4))))
  elif a==0x424480:
   assert ecx==MANAGER
   name=self.str(self.r(esp+8));assert name in TYPES
   assert self.r(esp+12)==0x3f800000 and self.r(esp+16)==1 and self.r(esp+20)==0
   ptr=self.next;self.next+=0x100;self.w(ptr+0x2c,COSTS[TYPES.index(name)]);self.w(ptr+0x14,1)
   self.u.mem_write(ptr+0x31,b'\x01');self.created.append((name,ptr));self.ret(20,ptr)
  elif a==0x423210:
   assert ecx==MANAGER and self.str(self.r(esp+8))=='blackdragon_visual'
   self.ret(8,self.template)
  elif a==0x4232f0 and not getattr(self,'grouping',False):assert ecx==MANAGER;self.ret(0,FLEET)
  elif a==0x42d1a0:self.ret(0)
  elif a==0x4373ff:self.freed.append(self.r(esp+4));self.ret(0)
  elif a==0x427240:self.shown.append(self.r(YARD+0x10));self.ret(0)
  elif a==0x4137b0:self.notifications+=1;self.ret(12)
  elif a==0x42d180:self.string(ecx,'');self.ret(0,ecx)
  elif a==0x42d230:self.string(ecx,self.str(self.r(esp+4)));self.ret(4,ecx)
  elif a==0x42d1d0:
   self.string(ecx,self.str(self.r(self.r(esp+4)+4)));self.ret(4,ecx)
  elif a==0x423140:
   self.purchased=self.r(esp+4);self.w(FLEET,self.r(FLEET)+1);self.ret(4)
  elif a==0x414760:
   cost=self.r(esp+4)+(self.r(esp+8)<<32);gold=self.r(PLAYER+0x10)+(self.r(PLAYER+0x14)<<32)
   gold-=cost;self.w(PLAYER+0x10,gold);self.w(PLAYER+0x14,gold>>32);self.ret(8)
  elif a==0x4260c0:
   ship=self.r(self.r(YARD+0x0c));price=self.r(YARD+0x24)
   gold=self.r(PLAYER+0x10)+(self.r(PLAYER+0x14)<<32)
   assert gold>=price
   self.w(ship+0x14,self.r(ship+0x14)+1)
   gold-=price;self.w(PLAYER+0x10,gold);self.w(PLAYER+0x14,gold>>32)
   self.notifications+=1;self.ret()
  elif a==0x4154d0:self.ret()
  elif getattr(self,'grouping',False) and a in [0x4303c0,0x430380,0x430340,0x430370,0x430360,0x4303a0,0x430400,0x430390]:
   if a==0x4303c0:self.grouped=[];self.ret()
   elif a in [0x430380,0x430340]:
    root=self.r(esp+4);items=self.group_types if root==MANAGER+0x14 else self.group_ships
    self.iterators[ecx]=[items,-1];self.ret(4)
   elif a==0x430370:
    it=self.iterators[ecx];it[1]+=1;self.ret(0,int(it[1]<len(it[0])))
   elif a in [0x430360,0x4303a0]:
    it=self.iterators[ecx];self.ret(0,it[0][it[1]])
   elif a==0x430400:
    assert ecx==MANAGER+0x44;self.grouped.append(self.r(esp+4));self.ret(4)
   else:self.ret()
 def run(self,a,stops):
  self.stops=set(stops);self.u.emu_start(a,0,count=2000000 if regional else 20000)
  assert self.u.reg_read(UC_X86_REG_EIP) in self.stops

def check(label):passed.append(label);print('PASS',label)
# Execute the native registration routine, mocking only its dictionary storage
# and string methods. Each XML command must route to the Shipyards instance.
m=Machine();m.u.reg_write(UC_X86_REG_EAX,0x234500);m.w(STACK,0xabcdef01)
m.run(0x4251d8,[0x4251df])
assert m.registered==dict({'yard_'+name:YARD for name in TYPES},buy_max_cannons=YARD)
assert m.r(YARD+0x2c)==0x234500
assert m.u.reg_read(UC_X86_REG_ESP)==STACK+4
assert m.u.reg_read(UC_X86_REG_EDI)==0xabcdef01
assert m.u.reg_read(UC_X86_REG_ESI)==YARD and m.u.reg_read(UC_X86_REG_EBX)==0
check('Native router registers all five commands and preserves initialization frame')
for name in TYPES:
 assert m.registered['yard_'+name]==YARD
 m.u.reg_write(UC_X86_REG_ESP,STACK);m.string(STACK+0x20,'yard_'+name)
 m.run(0x427545,[0x4277a3]);assert m.created[-1][0]==name
 check('Registered click routes to matching offer: '+name)
for name in TYPES:
 m=Machine();m.w(syms['selected'],syms['type_'+name]);m.u.reg_write(UC_X86_REG_ECX,MANAGER);m.w(STACK,0x47f000)
 m.run(syms['make_offer'],[0x47f000]);assert m.created[0][0]==name
 assert m.u.reg_read(UC_X86_REG_ESP)==STACK+4
 assert m.u.reg_read(UC_X86_REG_ESI)==YARD
 assert bytes(m.u.mem_read(m.created[0][1]+0x31,1))==b'\0'
 check('Factory '+name+': full hull, one cannon, unowned offer, balanced stack')
for name in TYPES:
 for previous in [0,0x230000]:
  m=Machine();m.w(YARD+0x10,previous);m.string(STACK+0x20,'yard_'+name)
  m.run(0x427545,[0x4277a3]);assert m.created[0][0]==name
  assert m.shown==[m.created[0][1]] and m.r(YARD+0x10)==m.created[0][1]
  assert m.freed==([previous] if previous else [])
  assert m.u.reg_read(UC_X86_REG_ESP)==STACK
  check('Catalog '+name+(' replaces old offer' if previous else ' creates missing offer'))
m=Machine();m.string(STACK+0x20,'repair_all');m.run(0x427545,[0x42754a]);assert m.r(STACK-4)==0x456288 and not m.created
check('Unrelated actions resume original dispatcher')
for count in [99,100]:
 m=Machine(count);m.string(STACK+0x20,'yard_megaship');m.run(0x427545,[0x4277a3]);assert bool(m.created)==(count<100)
 check('Catalog respects fleet count '+str(count))
for count in [1,99,100]:
 m=Machine(count);m.u.reg_write(UC_X86_REG_ECX,YARD);m.run(0x4273f0,[0x4274a3])
 assert bool(m.created)==(count<100);assert m.random_calls==0
 if count<100:assert m.r(YARD+0x10)==m.created[0][1]
 check('Native availability path fleet '+str(count)+': no random gate')
for name in TYPES:
 m=Machine(2);m.w(syms['selected'],syms['type_'+name]);m.w(YARD+0x10,0x230000)
 for i in range(4):
  m.u.reg_write(UC_X86_REG_ESP,STACK);m.run(0x425731,[0x425739])
  assert m.r(YARD+0x10)==m.created[-1][1] and m.created[-1][0]==name
  assert m.u.reg_read(UC_X86_REG_ESP)==STACK+12
 assert len({p for _,p in m.created})==4 and not m.freed
 check('Restock '+name+': four distinct offers, purchased objects never freed')
m=Machine(100);m.w(YARD+0x10,0x230000);m.run(0x425731,[0x425739]);assert not m.created and m.r(YARD+0x10)==0
check('Restock stops at fleet limit 100')
for gold in [0,999,1000,1001,2**32+500]:
 m=Machine();ship=0x230000;m.w(ship+0x2c,1000);m.w(YARD+0x10,ship)
 m.w(PLAYER+0x10,gold);m.w(PLAYER+0x14,gold>>32);m.w(STACK,0x47f000);m.u.reg_write(UC_X86_REG_ECX,YARD)
 m.run(0x425590,[0x42564e,0x425739])
 success=m.u.reg_read(UC_X86_REG_EIP)==0x42564e
 assert success==(gold>=1000)
 actual=m.r(PLAYER+0x10)+(m.r(PLAYER+0x14)<<32)
 assert actual==gold-(1000 if success else 0)
 assert m.r(FLEET)==(2 if success else 1)
 check('Native purchase affordability and gold deduction: gold '+str(gold))
# Bulk purchase capacity and gold boundary checks. Native single-cannon
# purchase is stubbed; injected eligibility/repeat logic executes as x86.
for cargo,current,goods,gold,price,owned in [
 (25,1,0,100000,6000,1),(150,1,0,1000000,6000,1),
 (200,1,0,1000000,6000,1),(300,1,0,1000000,6000,1),
 (350,1,0,1000000,6000,1),(150,2,105,1000000,6000,1),
 (150,15,0,1000000,6000,1),(150,1,0,5999,6000,1),
 (150,1,0,6000,6000,1),(150,1,0,17999,6000,1),
 (350,1,0,2**32+500,6000,1),(150,1,0,12000,3000,1),
 (150,1,0,1000000,6000,0),(150,1,0,1000000,0,1)]:
 m=Machine();ship=0x230000;info=0x231000;typ=0x232000
 m.w(YARD+0x0c,info);m.w(info,ship);m.w(ship,typ);m.w(typ+0x18,cargo)
 m.w(ship+0x14,current);m.w(ship+0x18,goods);m.u.mem_write(ship+0x31,bytes([owned]))
 m.w(YARD+0x24,price);m.w(PLAYER+0x10,gold);m.w(PLAYER+0x14,gold>>32)
 m.u.reg_write(UC_X86_REG_ECX,YARD);m.w(STACK,0x47f000)
 m.run(syms['buy_max_cannons'],[0x47f000])
 amount=min(max(0,(cargo-current*10-goods)//10),gold//price) if owned and price>0 else 0
 assert m.r(ship+0x14)==current+amount and m.notifications==amount
 assert m.r(PLAYER+0x10)+(m.r(PLAYER+0x14)<<32)==gold-amount*price
 assert m.u.reg_read(UC_X86_REG_ESP)==STACK+4
 check(f'Max cannons: cargo={cargo}, current={current}, goods={goods}, gold={gold}, price={price}, owned={owned}')
m=Machine();m.string(STACK+0x20,'buy_max_cannons');m.run(0x427545,[0x4277a3]);assert m.notifications==0
check('Bulk command safely handles no selected ship')
# Archive roundtrip and unchanged unrelated content.
def unpack(data):
 out={};pos=8
 for _ in range(struct.unpack_from('<I',data,4)[0]):
  end=data.index(0,pos);name=data[pos:end].decode();off,n=struct.unpack_from('<II',data,end+1);pos=end+9
  assert off+n<=len(data);out[name]=data[off:off+n]
 return out
old=unpack(args.original_data.read_bytes());new=unpack((OUT/'TW1_00.data').read_bytes())
expected_extra={'assets/graphics/ui/hud/fleetstat_blackdragon.jpg','assets/graphics/ui/hud/fleetstat_blackdragon_alpha.png','assets/graphics/combatview/ships/fl_blackdragon.png','assets/graphics/combatview/ships/fl_blackdragon_alpha.png','assets/graphics/combatview/ships/el_blackdragon.png','assets/graphics/combatview/ships/el_blackdragon_alpha.png'}
if (OUT/'fairwind-manifest.json').exists():expected_extra|={'assets/graphics/ui/hud/fleetstat_fairwind.jpg','assets/graphics/ui/hud/fleetstat_fairwind_alpha.png','assets/graphics/combatview/ships/fl_fairwind.png','assets/graphics/combatview/ships/fl_fairwind_alpha.png','assets/graphics/combatview/ships/el_fairwind.png','assets/graphics/combatview/ships/el_fairwind_alpha.png'}
if regional:expected_extra|={'assets/graphics/ui/popup/icon_'+s+'.png' for s in ['tea']}
assert set(new)-set(old)==expected_extra
assert set(old)<=set(new)
for name in old:
 if name not in ['assets/xml/int_buildings.txt','assets/xml/ships.txt','assets/xml/sprites.txt']:
  if name=='assets/xml/characters.txt' and (OUT/'fairwind-manifest.json').exists():
   key=b'klxd8794lkds87934poi';decode_chars=lambda p:bytes((v-key[i%len(key)])%256 for i,v in enumerate(p))
   chars=ET.fromstring(decode_chars(old[name]));chars.find('douglas/fleet/onemast').tag='fairwind_visual'
   assert ET.tostring(chars)==ET.tostring(ET.fromstring(decode_chars(new[name])))
  elif name=='assets/xml/alehouse.txt' and (OUT/'tea-tip-manifest.json').exists():
   tip=json.loads((OUT/'tea-tip-manifest.json').read_text())['tip'];key=b'klxd8794lkds87934poi';plain=lambda p:bytes((v-key[i%len(key)])%256 for i,v in enumerate(p))
   expected=plain(old[name]).replace(b'</alehouse>',b'\t<tip>'+tip.encode('ascii')+b'</tip>\r\n</alehouse>')
   assert plain(new[name])==expected
  else:assert old[name]==new[name]
key=b'klxd8794lkds87934poi';decode=lambda b:bytes((v-key[i%len(key)])%256 for i,v in enumerate(b))
a=decode(old['assets/xml/int_buildings.txt']);b=decode(new['assets/xml/int_buildings.txt']);xml=ET.fromstring(b)
menu=xml.find('shipyard_menu/children');actions=[el.findtext('onlclick') for el in menu]
for name in TYPES:assert actions.count('yard_'+name)==1
assert 'repair_all' in actions and 'endshipyards' in actions
assert xml.find('ship_options/children/buymaxcannons').findtext('onlclick')=='buy_max_cannons'
assert xml.find('ship_options/children/sellcannon').findtext('y')=='100'
assert xml.find('ship_options/children/back').findtext('y')=='125'
before=a[:a.index(b'\t<ship_options ')]
if not regional:assert b[:len(before)]==before
else:
 original_ui=ET.fromstring(a)
 for window in original_ui:
  if window.tag not in ['marketplace','warehouse','market_menu','trade_menu','ship_options','shipyard_menu','shipyards']:assert ET.tostring(window)==ET.tostring(xml.find(window.tag))
check('Asset archive: five catalog entries; repairs, leave, unrelated assets preserved')
for name in TYPES:
 assert menu.find('label_'+name).findtext('text')
 assert menu.find('catalog_'+name).findtext('width')=='64'
 assert int(menu.find('catalog_'+name).findtext('x'))==340
 assert int(menu.find('label_'+name).findtext('x'))==18
 assert menu.find('cargo_'+name).findtext('text')==str([50,150,200,300,350][TYPES.index(name)])
rows=[int(menu.find('catalog_'+name).findtext('y')) for name in TYPES]
assert rows==[26,49,72,95,118]
assert menu.find('fixall').findtext('y')==menu.find('ok').findtext('y')=='148'
assert int(xml.find('shipyard_menu').findtext('y'))+int(xml.find('shipyard_menu').findtext('height'))<490
assert menu.find('fixall').findtext('width')=='272'
assert menu.find('fixall').findtext('x')=='148' and menu.find('ok').findtext('x')=='344'
assert pe.get_memory_mapped_image()[0x56390:0x56390+len(b'Repair all: ')+1]==b'Repair all: '+bytes([0])
check('UI layout: aligned type/cargo/Buy columns, spaced rows and separate footer above log')
# Regression: artwork hooks must not change any ship or type bytes. Native
# fleet grouping compares the exact type pointer, not its serialized name.
for entry in ['icon','combat']:
 for name,tag,target in [('Black Dragon','megaship',True),('Enterprise','megaship',False),('Black Dragon','brigantine',False)]:
  for owned in [0,1]:
   m=Machine();ship=0x230000;typ=0x231000;m.template=0x232000
   m.u.mem_write(typ,bytes(range(128)));m.u.mem_write(m.template,bytes(reversed(range(128))))
   m.string(typ,tag);m.string(ship+4,name);m.w(ship,typ)
   m.u.mem_write(ship+0x31,bytes([owned]))
   m.w(YARD,ship);m.w(YARD+0x64,ship)
   original_ship=bytes(m.u.mem_read(ship,0x38));original_type=bytes(m.u.mem_read(typ,128))
   selected=m.template if target else typ
   for refresh in range(6):
    m.u.reg_write(UC_X86_REG_ESP,STACK);m.u.reg_write(UC_X86_REG_EAX,ship)
    m.u.reg_write(UC_X86_REG_ECX,MANAGER);m.u.reg_write(UC_X86_REG_EDI,0x1234)
    if entry=='icon':
     m.run(0x424c2a,[0x424c2f]);assert m.u.reg_read(UC_X86_REG_EAX)==m.r(selected+0x30)
     assert m.u.reg_read(UC_X86_REG_EDX)==typ
    else:
     m.run(0x40cd80,[0x40cd85]);offset=0x34 if owned else 0x44
     assert bytes(m.u.mem_read(YARD+0x54,16))==bytes(m.u.mem_read(selected+offset,16))
     assert m.u.reg_read(UC_X86_REG_EAX)==typ and m.u.reg_read(UC_X86_REG_EDX)==ship
    assert bytes(m.u.mem_read(ship,0x38))==original_ship
    assert bytes(m.u.mem_read(typ,128))==original_type
    assert m.u.reg_read(UC_X86_REG_ESP)==STACK and m.u.reg_read(UC_X86_REG_ECX)==MANAGER
    assert m.u.reg_read(UC_X86_REG_EDI)==0x1234 and m.u.reg_read(UC_X86_REG_EBP)==0x12345678
   # Execute actual native fleet regrouping after these repeated UI initializations.
   m.grouping=True;m.iterators={};m.group_types=[typ];m.group_ships=[ship]
   m.u.reg_write(UC_X86_REG_ESP,STACK);m.w(STACK,0x47f000);m.u.reg_write(UC_X86_REG_ECX,MANAGER)
   m.run(0x4232f0,[0x47f000]);assert m.grouped==[ship]
   assert m.u.reg_read(UC_X86_REG_EAX)==MANAGER+0x44
   check(f'{entry}: {name}/{tag}, owned={owned}: repeated refresh preserves model, native fleet grouping keeps ship')
# Demonstrate that the previous shadow technique triggers the exact native bug.
m=Machine();ship=0x230000;typ=0x231000;shadow=0x232000
m.string(typ,'megaship');m.string(shadow,'megaship');m.w(ship,shadow)
m.grouping=True;m.iterators={};m.group_types=[typ];m.group_ships=[ship]
m.w(STACK,0x47f000);m.u.reg_write(UC_X86_REG_ECX,MANAGER)
m.run(0x4232f0,[0x47f000]);assert m.grouped==[]
check('Regression reproduced: native grouping drops v4 shadow pointer despite identical megaship name')
# Missing visual assets safely retain the native icon and combat sprites.
for failure in ['no_template','no_icon','no_sprite']:
 m=Machine();ship=0x230000;typ=0x231000;m.template=0x232000
 m.string(typ,'megaship');m.string(ship+4,'Black Dragon');m.w(ship,typ)
 for offset in range(0x30,0x64,4):m.w(m.template+offset,0x233000+offset)
 if failure=='no_template':m.template=0
 elif failure=='no_icon':m.w(m.template+0x30,0)
 else:m.w(m.template+0x38,0)
 m.w(STACK,0x47f000);m.u.reg_write(UC_X86_REG_EAX,ship)
 m.run(syms['dragon_visual_type'],[0x47f000])
 assert m.u.reg_read(UC_X86_REG_EAX)==typ and m.r(ship)==typ
 check('Art loader fallback preserves native ship: '+failure)
# Registered capacity selection must survive the same native regrouping that
# exposed v4. Only Black Dragon migrates; an ordinary Juggernaut stays original.
for entry in ['value','info']:
 for name,target in [('Black Dragon',True),('Enterprise',False)]:
  m=Machine();ship=0x230000;typ=0x231000;m.template=0x232000
  m.string(typ,'megaship');m.string(m.template,'blackdragon_visual')
  m.string(ship+4,name);m.w(ship,typ);m.w(typ+0x18,350);m.w(m.template+0x18,450)
  for offset in range(0x30,0x64,4):m.w(m.template+offset,0x233000+offset)
  m.w(YARD,ship);m.w(STACK+4,ship);m.w(STACK,0x47f000)
  for refresh in range(6):
   m.u.reg_write(UC_X86_REG_ESP,STACK)
   m.u.reg_write(UC_X86_REG_ECX,MANAGER)
   if entry=='value':m.run(0x423090,[0x423095])
   else:m.run(0x424c1d,[0x424c22])
   assert m.r(ship)==(m.template if target else typ)
  assert m.r(m.r(ship)+0x18)==(450 if target else 350)
  m.grouping=True;m.iterators={};m.group_types=[typ,m.template];m.group_ships=[ship]
  m.u.reg_write(UC_X86_REG_ESP,STACK);m.w(STACK,0x47f000);m.u.reg_write(UC_X86_REG_ECX,MANAGER)
  m.run(0x4232f0,[0x47f000]);assert m.grouped==[ship]
  check(f'Registered 450-capacity {entry} variant: {name}, repeated initialization remains in native fleet')
# Native bulk action honors the enlarged hold, commodity load and affordability.
for cargo,current,goods,gold,expected in [(50,1,0,1000000,5),(50,1,10,1000000,4),(450,35,0,1000000,45),(450,17,0,1000000,45),(450,35,10,1000000,44),(450,35,0,12000,37),(350,35,0,1000000,35)]:
 m=Machine();ship=0x230000;typ=0x231000;info=0x234000
 m.w(YARD+0x0c,info);m.w(info,ship);m.w(ship,typ);m.w(typ+0x18,cargo)
 m.w(ship+0x14,current);m.w(ship+0x18,goods);m.u.mem_write(ship+0x31,b'\x01')
 m.w(YARD+0x24,6000);m.w(PLAYER+0x10,gold);m.w(PLAYER+0x14,0)
 m.w(STACK,0x47f000);m.u.reg_write(UC_X86_REG_ECX,YARD)
 m.run(syms['buy_max_cannons'],[0x47f000]);assert m.r(ship+0x14)==expected
 assert m.r(PLAYER+0x10)==gold-(expected-current)*6000
 check(f'Cannon capacity regression: hold={cargo}, guns={current}, goods={goods}, gold={gold}, result={expected}')
ships_old=ET.fromstring(decode(old['assets/xml/ships.txt']));ships_new=ET.fromstring(decode(new['assets/xml/ships.txt']))
for element in ships_old.find('types'):
 element=copy.deepcopy(element)
 if element.tag=='junk':element.find('cargo').text='50'
 assert ET.tostring(element)==ET.tostring(ships_new.find('types/'+element.tag))
variant=ships_new.find('types/blackdragon_visual');original_ship=ships_old.find('types/megaship')
assert variant is not None and variant.findtext('cargo')=='450'
for el in original_ship:
 if el.tag not in ['shipicon','cargo'] and 'sprite' not in el.tag:assert ET.tostring(el)==ET.tostring(variant.find(el.tag))
assert 'blackdragon' in variant.findtext('shipicon/bitmap')
assert [variant.findtext('sprite'+str(i)) for i in range(4)]==['blackdragon0','blackdragon1','blackdragon2','blackdragon2']
check('Black Dragon template: 450 cargo, all other original stats, names, combat grid and wake; ordinary ship types unchanged except Junk cargo 50')
sprites_old=ET.fromstring(decode(old['assets/xml/sprites.txt']));sprites_new=ET.fromstring(decode(new['assets/xml/sprites.txt']))
for element in sprites_old:
 assert ET.tostring(element)==ET.tostring(next(el for el in sprites_new if el.tag==element.tag and el.get('name')==element.get('name')))
for prefix in ['','_ally','_enemy']:
 for i in range(3):
  original_sprite=next(el for el in sprites_old if el.get('name')==f'brig{prefix}{i}')
  sprite=next(el for el in sprites_new if el.get('name')==f'blackdragon{prefix}{i}')
  width,height=(109,76) if prefix=='_enemy' else (160,111)
  assert sprite.attrib==dict(original_sprite.attrib,name=f'blackdragon{prefix}{i}',xoffset=str(width//2),yoffset=str(height))
  page=next(el for el in sprites_new if el.tag=='spritepage' and el.get('name')==sprite.findtext('spritepage'))
  assert page.findtext('framewidth')==str(width) and page.findtext('frameheight')==str(height)
  assert width>int(next(el for el in sprites_old if el.get('name')==original_sprite.findtext('spritepage')).findtext('framewidth'))
  assert [el.text for el in sprite.findall('frame')]==[el.text for el in original_sprite.findall('frame')]
check('Combat sprite definitions preserve timing and damage sequences with enlarged frame rectangles and bottom-center anchors')
from PIL import Image,ImageChops
from io import BytesIO
for stem,size in [('fleetstat_blackdragon',(130,89)),('fl_blackdragon',(640,333)),('el_blackdragon',(436,228))]:
 folder='ui/hud/' if stem.startswith('fleetstat') else 'combatview/ships/'
 path='assets/graphics/'+folder+stem
 color=Image.open(BytesIO(new[path+('.jpg' if stem.startswith('fleetstat') else '.png')]))
 alpha_file=Image.open(BytesIO(new[path+'_alpha.png']))
 assert alpha_file.mode=='P', 'Alpha masks must use indexed PNG like the original engine assets'
 assert new[path+'_alpha.png'][24:26]==bytes([8,3])
 alpha=alpha_file.convert('L')
 assert color.size==alpha.size==size and alpha.getextrema()[0]==0 and alpha.getextrema()[1]>=250
 if not stem.startswith('fleetstat'):
  w,h=size[0]//4,size[1]//3
  frames=[color.crop((i*w,j*h,(i+1)*w,(j+1)*h)) for j in range(3) for i in range(4)]
  assert all(ImageChops.difference(frames[j*4],frames[j*4+1]).getbbox() for j in range(3))
  assert ImageChops.difference(frames[0],frames[4]).getbbox() and ImageChops.difference(frames[4],frames[8]).getbbox()
 check('Graphics format, dimensions, alpha and animation/damage content: '+stem)

# Execute native free-space calculations used by market buying and warehouse
# transfers, including inventories above the old 5,000-unit limit.
for stocks in [(0,0,0,0),(5000,0,0,0),(4000,3000,2000,1000),(15000,0,0,0),(15001,0,0,0)]:
 for entry,stop in [(0x418048,0x41805c),(0x42a3b7,0x42a3d7)]:
  m=Machine();inventory=0x230000
  for i,v in enumerate(stocks):m.w(inventory+i*4,v)
  m.u.reg_write(UC_X86_REG_ECX,inventory)
  m.run(entry,[stop]);expected=(15000-sum(stocks))&0xffffffff
  assert m.u.reg_read(UC_X86_REG_EAX)==expected
  if entry==0x42a3b7:assert m.r(YARD+0x30)==expected
 check('Native market and warehouse free space with inventory '+str(stocks))
m=Machine();m.u.reg_write(UC_X86_REG_EAX,6000);m.run(0x42a3e9,[0x42a3f4])
assert m.u.reg_read(UC_X86_REG_ECX)==9000
check('Warehouse occupied-space display uses the same 15,000-unit total')
assert pe.OPTIONAL_HEADER.CheckSum==pe.generate_checksum()
assert any(section.VirtualAddress==0x70000 for section in pe.sections)
if regional or (OUT/'isolation-manifest.json').exists():assert pe.sections[-1].VirtualAddress==0x80000 and pe.OPTIONAL_HEADER.SizeOfImage==0x80000+pe.sections[-1].SizeOfRawData
else:assert pe.sections[-1].VirtualAddress==0x70000 and pe.OPTIONAL_HEADER.SizeOfImage==0x71000
from fix_pe_layout import validate
validate(exe.read_bytes())
check('PE section mapping, contiguous Windows image layout and checksum')
(OUT/'validation.txt').write_text('\n'.join('PASS '+s for s in passed)+'\n\nThese are x86 emulation checks with engine/Windows calls stubbed. The full Windows game, UI rendering and save/load have not been tested.\n')
print(len(passed),'checks passed')
