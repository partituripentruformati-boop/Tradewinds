.intel_syntax noprefix
.section .text
.global startup_trace_hook
.extern startup_trace
startup_trace_hook:
 pushfd
 pushad
 mov eax,DWORD PTR [esp+12]
 push DWORD PTR [eax+8]
 call startup_trace
 add esp,4
 popad
 popfd
 push ebp
 mov ebp,esp
 and esp,-8
 jmp 0x401c46

.extern startup_stage
.global stage_4283c0
stage_4283c0:
 pushfd
 pushad
 push 0x4283c0
 call startup_stage
 add esp,4
 popad
 popfd
 jmp 0x4283c0
.global stage_4132e0
stage_4132e0:
 pushfd
 pushad
 push 0x4132e0
 call startup_stage
 add esp,4
 popad
 popfd
 jmp 0x4132e0
.global stage_41c130
stage_41c130:
 pushfd
 pushad
 push 0x41c130
 call startup_stage
 add esp,4
 popad
 popfd
 jmp 0x41c130
.global stage_416720
stage_416720:
 pushfd
 pushad
 push 0x416720
 call startup_stage
 add esp,4
 popad
 popfd
 jmp 0x416720
.global stage_41a340
stage_41a340:
 pushfd
 pushad
 push 0x41a340
 call startup_stage
 add esp,4
 popad
 popfd
 jmp 0x41a340
.global stage_40c050
stage_40c050:
 pushfd
 pushad
 push 0x40c050
 call startup_stage
 add esp,4
 popad
 popfd
 jmp 0x40c050
.global stage_40aa10
stage_40aa10:
 pushfd
 pushad
 push 0x40aa10
 call startup_stage
 add esp,4
 popad
 popfd
 jmp 0x40aa10
.global stage_4190c0
stage_4190c0:
 pushfd
 pushad
 push 0x4190c0
 call startup_stage
 add esp,4
 popad
 popfd
 jmp 0x4190c0
.global stage_417660
stage_417660:
 pushfd
 pushad
 push 0x417660
 call startup_stage
 add esp,4
 popad
 popfd
 jmp 0x417660
.global stage_429c90
stage_429c90:
 pushfd
 pushad
 push 0x429c90
 call startup_stage
 add esp,4
 popad
 popfd
 jmp 0x429c90
.global stage_424d40
stage_424d40:
 pushfd
 pushad
 push 0x424d40
 call startup_stage
 add esp,4
 popad
 popfd
 jmp 0x424d40
