"""Restore v7 native market code/UI while retaining Fair Wind and ship upgrades."""
from pathlib import Path
import argparse,hashlib,json,shutil,struct
import pefile
from fix_pe_layout import validate
p=argparse.ArgumentParser();p.add_argument('--base-v11',type=Path,required=True);p.add_argument('--base-v7',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
shutil.copytree(a.base_v11,a.output,dirs_exist_ok=True)
name='TradewindsClassic_100Ships_2xHull_ShipyardCatalog_TEST.exe'
b=bytearray((a.base_v11/name).read_bytes());old=(a.base_v7/name).read_bytes();pe=pefile.PE(data=b);v7=pefile.PE(data=old)
m=json.loads((a.base_v11/'regional-manifest.json').read_text());restored=[]
for h in m['hooks']:
 address=int(h['address'],16);off=pe.get_offset_from_rva(address-0x400000);before=bytes.fromhex(h['before']);assert b[off:off+len(before)]==bytes.fromhex(h['after']);b[off:off+len(before)]=before;restored.append(hex(address))
for address in [0x4241e9,0x424379,0x4244e9]:
 off=pe.get_offset_from_rva(address-0x400000);oldoff=v7.get_offset_from_rva(address-0x400000);b[off:off+5]=old[oldoff:oldoff+5];restored.append(hex(address))
fair=json.loads((a.base_v11/'fairwind-manifest.json').read_text());s=pe.sections[-1];off=pe.get_offset_from_rva(fair['selector_address']-0x400000);selector=bytes(b[off:off+fair['selector_bytes']]);b[s.PointerToRawData:s.PointerToRawData+s.SizeOfRawData]=bytes(s.SizeOfRawData);b[off:off+len(selector)]=selector
# Every original section's payload matches v7 except the three Fair Wind redirects.
expected=bytearray(old)
for h in fair['redirects']:
 off7=v7.get_offset_from_rva(int(h['address'],16)-0x400000);expected[off7:off7+5]=bytes.fromhex(h['after'])
for section in v7.sections:
 current=next(x for x in pe.sections if x.VirtualAddress==section.VirtualAddress)
 assert b[current.PointerToRawData:current.PointerToRawData+section.SizeOfRawData]==expected[section.PointerToRawData:section.PointerToRawData+section.SizeOfRawData],section.Name
struct.pack_into('<I',b,pe.OPTIONAL_HEADER.get_field_absolute_offset('CheckSum'),pefile.PE(data=b).generate_checksum());validate(bytes(b));(a.output/name).write_bytes(b)
def entries(path):
 d=path.read_bytes();pos=8;out=[]
 for _ in range(struct.unpack_from('<I',d,4)[0]):
  end=d.index(0,pos);n=d[pos:end].decode();off,size=struct.unpack_from('<II',d,end+1);out.append((n,d[off:off+size]));pos=end+9
 return out
oldassets=dict(entries(a.base_v7/'TW1_00.data'));assets=entries(a.base_v11/'TW1_00.data');assets=[(n,oldassets[n] if n=='assets/xml/int_buildings.txt' else data) for n,data in assets if not n.startswith('assets/graphics/ui/popup/icon_') or n in oldassets]
pos=8+sum(len(n.encode())+9 for n,_ in assets);d=bytearray(struct.pack('<II',0xdcac,len(assets)));payload=bytearray()
for n,data in assets:d+=n.encode()+b'\0'+struct.pack('<II',pos,len(data));payload+=data;pos+=len(data)
(a.output/'TW1_00.data').write_bytes(d+payload)
for f in ['regional-manifest.json','regional-disassembly.txt','Regional_goods_preview.png']:
 path=a.output/f
 if path.exists():path.unlink()
report=dict(version='v15 commodities disabled',restored_sites=restored,native_code_matches_v7_except_fairwind=True,regional_payload_zeroed=True,market_ui_matches_v7=True,features_retained=['Black Dragon','Fair Wind','five shipyard tiers','max cannons','Junk 50 cargo','warehouse 15000'])
(a.output/'isolation-manifest.json').write_text(json.dumps(report,indent=2)+'\n')
print('Restored',len(restored),'regional hook sites; v7 native payload verified')
