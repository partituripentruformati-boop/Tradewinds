"""Strip serializer declarations unsupported by the legacy game's XML dialect."""
from pathlib import Path
import argparse,json,struct,hashlib,shutil
KEY=b'klxd8794lkds87934poi'
def decode(p):return bytes((v-KEY[i%len(KEY)])%256 for i,v in enumerate(p))
def encode(p):return bytes((v+KEY[i%len(KEY)])%256 for i,v in enumerate(p))
def entries(data):
 pos=8;result=[]
 for _ in range(struct.unpack_from('<I',data,4)[0]):
  end=data.index(0,pos);name=data[pos:end].decode();off,size=struct.unpack_from('<II',data,end+1);pos=end+9
  assert off+size<=len(data);result.append((name,data[off:off+size]))
 return result
def pack(items):
 pos=8+sum(len(name.encode())+9 for name,_ in items);header=bytearray(struct.pack('<II',0xdcac,len(items)));body=bytearray()
 for name,payload in items:header+=name.encode()+b'\0'+struct.pack('<II',pos,len(payload));body+=payload;pos+=len(payload)
 return bytes(header+body)
def correct(data):
 result=[];changes=[]
 for name,payload in entries(data):
  if name.startswith('assets/xml/'):
   plain=decode(payload)
   if plain.startswith(b'<?xml '):
    end=plain.index(b'?>')+2
    if plain[end:end+2]==b'\r\n':end+=2
    elif plain[end:end+1]==b'\n':end+=1
    changes.append(dict(resource=name,removed=plain[:end].decode('ascii')))
    payload=encode(plain[end:])
  result.append((name,payload))
 return pack(result),changes
if __name__=='__main__':
 parser=argparse.ArgumentParser();parser.add_argument('--base',type=Path,required=True);parser.add_argument('--output',type=Path,required=True);args=parser.parse_args()
 shutil.copytree(args.base,args.output,dirs_exist_ok=True);p=args.output/'TW1_00.data';original=p.read_bytes();fixed,changes=correct(original);p.write_bytes(fixed)
 (args.output/'xml-fix-manifest.json').write_text(json.dumps(dict(version='v11',input_sha256=hashlib.sha256(original).hexdigest(),output_sha256=hashlib.sha256(fixed).hexdigest(),changes=changes,scope='Serializer declarations only; remaining resource content and executable unchanged'),indent=2)+'\n')
 print('Corrected XML resources:',[item['resource'] for item in changes])
