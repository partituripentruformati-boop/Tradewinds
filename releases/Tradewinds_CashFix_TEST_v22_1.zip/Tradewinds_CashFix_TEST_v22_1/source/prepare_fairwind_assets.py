"""Prepare engine-sized atlases from the generated transparent Fair Wind art.
ImageMagick performs resizing, mild rocking frames and transparent damage holes.
"""
from pathlib import Path
import subprocess,tempfile,json,hashlib
ROOT=Path(__file__).resolve().parent/'fairwind-assets'
def convert(*args):subprocess.run(['convert',*map(str,args)],check=True)
with tempfile.TemporaryDirectory(prefix='fairwind-art-') as directory:
 d=Path(directory)
 convert(ROOT/'fairwind_rgba.png','-trim','+repage',d/'trim.png')
 convert(d/'trim.png','-resize','128x87','-background','none','-gravity','south','-extent','130x89',ROOT/'icon_preview.png')
 convert(ROOT/'icon_preview.png','-background','black','-alpha','remove','-alpha','off','-quality','95',ROOT/'fleetstat_fairwind.jpg')
 convert(ROOT/'icon_preview.png','-alpha','extract','-colors','256','PNG8:'+str(ROOT/'fleetstat_fairwind_alpha.png'))
 for stem,w,h in [('fl_fairwind',95,72),('el_fairwind',66,50)]:
  convert(d/'trim.png','-resize',f'{w-4}x{h-4}',d/'ship.png')
  rows=[]
  for row in range(3):
   frames=[]
   for i,angle in enumerate([-0.9,0,0.9,0.35]):
    frame=d/f'{stem}-{row}-{i}.png'
    args=[d/'ship.png','-background','none','-rotate',str(angle),'-gravity','south','-extent',f'{w}x{h}']
    if row:
     scale=w/95
     holes=[(42,30,3,2),(55,43,3,2)]+([(46,48,5,3),(31,26,2,3)] if row==2 else [])
     drawing=' '.join(f'ellipse {int(x*scale)},{int(y*scale)} {max(1,int(rx*scale))},{max(1,int(ry*scale))} 0,360' for x,y,rx,ry in holes)
     mask=d/'mask.png';convert('-size',f'{w}x{h}','xc:none','-fill','white','-draw',drawing,mask)
     args += [mask,'-compose','DstOut','-composite']
    convert(*args,frame);frames.append(frame)
   strip=d/f'{stem}-row{row}.png';convert(*frames,'+append',strip);rows.append(strip)
  sheet=ROOT/(stem+'_preview.png');convert(*rows,'-append',sheet)
  convert(sheet,'-background','black','-alpha','remove','-alpha','off','PNG24:'+str(ROOT/(stem+'.png')))
  convert(sheet,'-alpha','extract','-colors','256','PNG8:'+str(ROOT/(stem+'_alpha.png')))
files={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in ROOT.glob('*') if p.is_file() and p.name!='manifest.json'}
(ROOT/'manifest.json').write_text(json.dumps(dict(player_frame=[95,72],enemy_frame=[66,50],sidebar=[130,89],hashes=files),indent=2)+'\n')
print('Fair Wind engine artwork prepared:',ROOT)
