# Regional goods test patch v8

The v8 builder connects three additional commodities to native market commands,
cargo space, ship speed, warehouse transfers, ship sale, warehouse theft and
save files. It preserves the four existing goods and the previous v7 changes.

| Commodity | Base gold | Exclusive purchase port |
| --- | ---: | --- |
| Tea | 90 | Tanchon (`tanchon`) |
| Spices | 175 | Lama Sut (`lamasut`) |
| Jade & Gemstones | 2500 | Edamame (`edamame`) |

Sales are allowed at every port. Quotes use the native random generator at the
same refresh boundary as the original goods. Purchase-port quotes range from
75–125% of base, other-port quotes from 75–175%, rounded down. Quotes remain
stable while buying/selling and are included in saves. These ranges are
implementation defaults. Artwork is prepared from the user's supplied designs
as 20×20 indexed transparent PNGs, matching the legacy engine's icon format.

## Build and verification

Install `requirements-dev.txt`. The builder also requires GCC with support for
freestanding i386 compilation and GNU binutils. Build v7 from the original
uploaded executable and data with `build_patch.py`, then run:

```sh
python3 build_regional_patch.py --base /path/to/v7 --output /path/to/v8
python3 test_regional_runtime.py --output /path/to/v8
python3 test_regional_goods.py
python3 test_patch.py --output /path/to/v8 --original-data /path/to/original/TW1_00.data
```

The regional builder requires exact v7 EXE/data hashes. Patch lengths are checked
against instruction boundaries. The manifest records the overwritten bytes and
linked symbols. The new fixed-address PE section is `.goods` at VA `480000`.

Validation covers 94 existing regressions against the integrated executable,
16 compiled bridge/native hook integration tests, and nine x86 core tests,
including 306 reference transactions. Native engine services are stubbed.
Windows startup, UI rendering and full gameplay still require play testing.

## Storage and native ABI

Ship goods occupy only the four native slots at `ship+18..24`. Fields after those
slots contain prices, values and flags. Added goods instead use a separate
1024-entry table keyed by native ship/warehouse object. Entries are cleared on
ship release/reuse and new game/load reset. Exhaustion fails without overwriting
objects. All seven goods count toward cargo space, cannon purchase limits,
ship speed, warehouse fullness and native goods distribution.

Native ship serialization remains unchanged. A versioned `RGC1` trailer follows
the entire native save. It stores three quantities per serialized ship and
owned warehouse, current quotes, counts and a record checksum. Ship name/type
hashes and port tag hashes verify association with loaded objects; process
pointers are never serialized. Old saves ending before the trailer load with
zero extra inventory. Invalid/truncated extensions cause load failure. Preserve
pre-v8 save backups: older executables cannot retain added goods when saving.

The package includes both matching EXE and TW1_00.data. Original DLLs and
TW1_01.data must remain in the same installed game folder.
