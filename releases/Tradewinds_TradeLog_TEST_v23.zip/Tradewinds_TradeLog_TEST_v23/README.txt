Tradewinds v23 TEST — Tea and Spices transaction log

Adds the original-style Bought/Sold messages for Tea and Spices to the in-game
log, including quantity and gold total. Covers fleet and warehouse trading,
Sell All, and quantities limited by available cash or inventory. Failed or
zero-quantity trades produce no message. No additional gold is charged.
All v22.1 features retained; TW1_00.data unchanged; save format unchanged.

INSTALL
Close Tradewinds. Back up your saves and current executable/data. Extract this
ZIP and copy BOTH the executable and TW1_00.data into the original game folder.
Keep the original DLLs and TW1_01.data. Launch the patched executable.
Buy a small amount of Tea in Tanchon or Spices in Lama Sut, then sell some.
Confirm the in-game log shows quantity and gold for each completed trade.

VALIDATION
Five compiled-runtime log tests passed, including fleet/warehouse, both goods,
Sell All, actual affordable quantity, zero trades and a 64-bit gold total.
Native log/formatter GUI services are mocked; Windows gameplay confirmation
is still needed. Five cash checks, nine Spices checks, four original-selection
checks, eight diagnostic checks and 94 regression checks passed.

REBUILD
source/build_spices_patch.py --base-v7 <working v7 folder> --output <folder>
Requires Python, pefile, capstone, Pillow, gcc -m32 and binutils; tests use Unicorn.
