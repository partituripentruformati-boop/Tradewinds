"""Check legacy XML syntax and exact scope of declaration removal."""
from pathlib import Path
import argparse,re,unittest,xml.etree.ElementTree as ET
from fix_xml_format import entries,decode,correct
parser=argparse.ArgumentParser();parser.add_argument('--output',type=Path,required=True);parser.add_argument('--before',type=Path,required=True);args,remaining=parser.parse_known_args()
BEFORE=(args.before/'TW1_00.data').read_bytes();AFTER=(args.output/'TW1_00.data').read_bytes()
def validate(payload):
 plain=decode(payload)
 assert not plain.lstrip().startswith(b'<?xml'), 'Legacy engine rejects serializer declarations'
 assert not re.search(rb'<[^>]*\s[\w:]+\s*=\s*\x27',plain), 'Attributes must use double quotes'
 ET.fromstring(plain)
class XMLTests(unittest.TestCase):
 def test_old_problem_is_reproduced(self):
  old=dict(entries(BEFORE))
  with self.assertRaises(AssertionError):validate(old['assets/xml/ships.txt'])
 def test_all_game_xml_uses_legacy_compatible_headers_and_quotes(self):
  for name,payload in entries(AFTER):
   if name.startswith('assets/xml/'):validate(payload)
 def test_exactly_four_declarations_removed_and_other_content_preserved(self):
  fixed,changes=correct(BEFORE);self.assertEqual(fixed,AFTER);self.assertEqual(len(changes),4)
  old=dict(entries(BEFORE));new=dict(entries(AFTER));self.assertEqual(old.keys(),new.keys())
  changed={item['resource'] for item in changes}
  for name in old:
   if name in changed:self.assertEqual(decode(new[name]),decode(old[name]).split(b'?>\n',1)[1])
   else:self.assertEqual(old[name],new[name])
 def test_executable_is_unchanged(self):
  exe='TradewindsClassic_100Ships_2xHull_ShipyardCatalog_TEST.exe'
  self.assertEqual((args.before/exe).read_bytes(),(args.output/exe).read_bytes())
 def test_correction_is_idempotent(self):self.assertEqual(correct(AFTER),(AFTER,[]))
if __name__=='__main__':unittest.main(argv=[__file__]+remaining,verbosity=2)
