WINDOWS EXECUTABLE LAYOUT CORRECTION — v8.1

V8 and v9 had a gap between the .yard and .goods virtual sections that violated
Windows PE image layout requirements. Windows could reject the EXE with
"This app can't run on your PC" before game code ran. This package reserves
zero-filled virtual padding in .yard so the sections are adjacent, preserving
all code addresses, machine code, assets, prices and game logic.

INSTALL
Close Tradewinds and back up your saves. Replace BOTH the executable and
TW1_00.data in your original game folder with this package's matching files.
Keep bass.dll, fmod.dll, gd204.dll, TW1_01.data and other original files there.
V10 includes Fair Wind and all earlier changes. V8.1 retains only the v8 features.

VALIDATION
Layout checks reproduce rejection of the old gap and validate the correction.
Only the section virtual-size field and PE checksum differ from the preceding
EXE. Assets and all other EXE bytes are unchanged. The corrected v10 also passed
94 gameplay regression checks, 16 regional integration tests and eight Fair Wind
tests. Windows launch/full gameplay remains untested in this Linux environment;
please test launching, loading and saving on Windows.

PREVIOUS FEATURE AND INSTALLATION NOTES
Tradewinds Classic Regional Goods TEST patch v8

NEW GOODS
Tea: buy exclusively in Tanchon (base 90 gold).
Spices: buy exclusively in Lama Sut (base 175 gold).
Jade & Gemstones: buy exclusively in Edamame (base 2,500 gold).
Sell all three in any port. Prices fluctuate when native market prices refresh,
not on each click. The original four goods remain available as before.
The three supplied sprite designs appear in market and warehouse rows.

Use each new market row's Amount box and Buy / Sell buttons to trade a chosen
quantity. The adjoining Max buttons buy as much as gold and cargo space allow,
or sell the whole selected inventory. Send to Fleet / Warehouse applies to the
new goods as well. Outside a commodity's source port, its Buy and buy-Max
labels show -- and purchase attempts do nothing; selling remains available.
In the warehouse, Load all / Store all move as much as destination space allows.
Its Show me option selects warehouse or fleet quantities for all seven goods.
Added goods occupy one cargo unit each and affect cannon limits and ship speed.

PREVIOUS FEATURES RETAINED
Five shipyard tiers, automatic restocking, clean shipyard layout, maximum-cannon
purchases, 100-ship limit and doubled hull. Black Dragon retains its transparent
icon, enlarged combat animations, 450 cargo and up to 45 cannons. Junk retains
50 cargo / five cannons; ordinary Juggernauts retain 350 / 35. Warehouses retain
15,000 capacity and repair prices retain the shortened label.

INSTALL
1. Close Tradewinds. Back up the game folder and every save.tw* file.
2. Extract this ZIP. Copy BOTH TW1_00.data and
   TradewindsClassic_100Ships_2xHull_ShipyardCatalog_TEST.exe into your ORIGINAL
   game folder, replacing the matching patch files.
3. Keep bass.dll, fmod.dll, gd204.dll, TW1_01.data and other original game files
   in that same folder. This ZIP is a patch, not a complete game installation.
4. Launch the patched executable from the original folder and load your save.

SAVES AND ROLLBACK
Existing matching saves load with zero inventory of the three new goods.
V8 saves store new ship/warehouse quantities and current quotes in a versioned
extension after the original records. Keep the matching EXE/data together.
To roll back, restore your earlier EXE/data AND a save backed up before v8.
Saving with an older executable loses the three added inventories.

PLEASE TEST ON WINDOWS
At each source port, buy its exclusive good and check gold and cargo changes.
Try quantity and Max buttons, warehouse storage/loading, selling elsewhere,
travelling for fresh prices, saving/reloading and a battle. Check the new rows
fit their frames and Black Dragon still appears correctly.

VALIDATION
The integrated EXE passed 94 prior regression checks, 16 new native bridge/hook
integration tests and nine x86 core tests (including 306 reference trades).
Tests cover exclusive ports, quotes, gold, seven-good capacity, cannon limits,
ship sale, release, theft selection, commands and save extension compatibility.
Engine services are stubbed: full Windows gameplay/rendering has not been run.
This is a TEST build requiring in-game verification.

SOURCE
source/ includes both builders, native assembly/C, tests and artwork.
Install source/requirements-dev.txt and GCC / GNU binutils with i386 support.
Read source/REGIONAL_GOODS.md for build commands and native storage details.
