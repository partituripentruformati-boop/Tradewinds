/* Diagnostic only: preserve gameplay while logging actual native UI creation. */
typedef unsigned int U;
#define SC __attribute__((stdcall))
#define FN(a,t) (*(t *)(a))
typedef U (SC *Open)(const char *,U,U,void *,U,U,U);
typedef U (SC *Write)(U,const void *,U,U *,void *);
typedef U (SC *One)(U);
typedef U (SC *Filter)(void *);
typedef Filter (SC *Install)(Filter);
static U handle, initialized;
static Filter previous;
static void record(const char *p,U n) {
 U written;if(handle&&handle!=~0u){FN(0x452194,Write)(handle,p,n,&written,0);FN(0x45203c,One)(handle);}
}
static U text(char *out,const char *p,U max) {U n=0;if(p)while(n<max&&p[n]){out[n]=p[n];n++;}return n;}
static void hex(char *p,U v) {for(U i=0;i<8;i++)p[i]="0123456789ABCDEF"[(v>>(28-i*4))&15];}
static U SC crash(void *exception) {
 U *e=*(U **)exception;char b[]="CRASH code=00000000 address=00000000\r\n";
 if(e){hex(b+11,e[0]);hex(b+28,e[3]);record(b,sizeof(b)-1);}
 return previous?previous(exception):0;
}
void startup_trace(void *node) {
 if(!initialized){initialized=1;handle=FN(0x452038,Open)("Tradewinds-startup.log",0x40000000,3,0,2,0x80,0);previous=FN(0x452188,Install)(crash);record("Tradewinds v12 diagnostic: native UI loading\r\n",44);}
 char b[512];U n=text(b,"BEGIN ",6);void *parents[16];U count=0;
 while(node&&count<16){parents[count++]=node;node=*(void **)((char *)node+0x10);}
 while(count&&n<480){void *p=parents[--count];b[n++]='/';n+=text(b+n,*(const char **)((char *)p+4),480-n);}
 b[n++]='\r';b[n++]='\n';record(b,n);
}
