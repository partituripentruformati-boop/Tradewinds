"""Regression tests for the Windows-rejected section gap in v8/v9."""
from pathlib import Path
import argparse,struct,unittest
import pefile
from fix_pe_layout import fix,validate
parser=argparse.ArgumentParser();parser.add_argument('--executable',type=Path,required=True);args,remaining=parser.parse_known_args()
DATA=args.executable.read_bytes()
def broken_layout():
 p=pefile.PE(data=DATA);b=bytearray(DATA);yard=next(s for s in p.sections if s.Name.startswith(b'.yard'))
 struct.pack_into('<I',b,yard.get_field_absolute_offset('Misc_VirtualSize'),1064)
 q=pefile.PE(data=bytes(b));struct.pack_into('<I',b,q.OPTIONAL_HEADER.get_field_absolute_offset('CheckSum'),q.generate_checksum())
 return bytes(b)
class LayoutTests(unittest.TestCase):
 def test_corrected_layout_is_valid(self):validate(DATA)
 def test_v8_v9_gap_is_rejected(self):
  with self.assertRaises(AssertionError):validate(broken_layout())
 def test_repair_changes_only_section_size_and_checksum(self):
  broken=broken_layout();patched,changes=fix(broken);self.assertEqual(len(changes),1)
  self.assertEqual(changes[0]['section'],'.yard');self.assertEqual(changes[0]['after'],65536)
  self.assertEqual(patched,DATA);validate(patched)
 def test_repair_is_idempotent(self):
  patched,changes=fix(DATA);self.assertEqual(patched,DATA);self.assertEqual(changes,[])
if __name__=='__main__':unittest.main(argv=[__file__]+remaining,verbosity=2)
