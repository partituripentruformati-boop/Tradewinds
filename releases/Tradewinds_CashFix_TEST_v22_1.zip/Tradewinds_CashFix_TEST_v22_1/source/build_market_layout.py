"""Apply a UI-only Tea market layout to the matching v16 patch."""
from pathlib import Path
import argparse,hashlib,json,shutil,xml.etree.ElementTree as ET
from fix_xml_format import entries,pack,decode,encode
p=argparse.ArgumentParser();p.add_argument('--base',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
shutil.copytree(a.base,a.output,dirs_exist_ok=True)
path=a.output/'TW1_00.data';before=entries(path.read_bytes());assets=dict(before);resource='assets/xml/int_buildings.txt';ui=ET.fromstring(decode(assets[resource]));market=ui.find('marketplace');children=market.find('children')
def setv(node,key,value):
 el=node.find(key)
 if el is None:el=ET.SubElement(node,key)
 el.text=str(value)
def control(tag,**values):
 node=children.find(tag);assert node is not None,tag
 for key,value in values.items():setv(node,key,value)
# Native commodity IDs remain unchanged; only display positions move.
for i,y in [(1,48),(2,104),(3,132),(4,160)]:
 control('icon'+str(i),y=y)
 for prefix in ['item','value','qty']:control(prefix+str(i),y=y+5)
control('rgicon0',y=76)
for name in ['rgn0','rgp0','rgq0']:control(name,y=81)
setv(market,'height',240);setv(children.find('frame'),'height',240)
control('rgamountheader',x=34,y=207,text='Tea amount:')
control('rga0',x=120,y=202,width=80)
for name,x,text in [('rgb0',255,'Buy'),('rgb0m',345,'Max'),('rgs0',435,'Sell'),('rgs0m',525,'Max')]:control(name,x=x,y=202,width=80,text=text)
for name in ['market_menu','trade_menu']:setv(ui.find(name),'y',300)
note=ET.SubElement(children,'tea_source_note',{'_extends':'/controldefs/smalltext'})
for key,value in [('x',400),('y',148),('text','Buy Tea in Tanchon')]:setv(note,key,value)
assets[resource]=encode(ET.tostring(ui,encoding='ascii',xml_declaration=False))
path.write_bytes(pack([(n,assets[n]) for n,_ in before]))
after=dict(entries(path.read_bytes()));assert all(after[n]==payload for n,payload in before if n!=resource)
exe='TradewindsClassic_100Ships_2xHull_ShipyardCatalog_TEST.exe';assert (a.output/exe).read_bytes()==(a.base/exe).read_bytes()
assert [int(children.findtext(tag+'/y')) for tag in ['item1','rgn0','item2','item3','item4']]==[53,81,109,137,165]
# Button bounds include ornamental caps; reserve 10 pixels at each side.
boxes=[(120,200)]+[(x-40,x+40)for x in [255,345,435,525]]
assert all(a1+10<=b0 for (_,a1),(b0,_) in zip(boxes,boxes[1:]))
assert boxes[-1][1]+10<=int(market.findtext('width'))
assert int(ui.findtext('market_menu/y'))>=int(market.findtext('y'))+240+20
assert int(ui.findtext('trade_menu/y'))+int(ui.findtext('trade_menu/height'))<=480
report=dict(version='v17 Tea market layout',scope='Only assets/xml/int_buildings.txt changed; executable and other resources byte-identical to v16',item_order=['General Merchandise','Tea','Arms','Silk and textiles','Dream Dust'],row_spacing=28,action_row_y=202,menu_y=300,exe_sha256=hashlib.sha256((a.output/exe).read_bytes()).hexdigest(),data_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),startup_log_version='v16 (unchanged executable)')
(a.output/'market-layout-manifest.json').write_text(json.dumps(report,indent=2)+'\n');print('UI-only layout built and bounds/resource isolation verified')
