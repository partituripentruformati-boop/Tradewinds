from pathlib import Path
import argparse,copy,xml.etree.ElementTree as E
from fix_xml_format import entries,pack,decode,encode
p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True);a=p.parse_args();path=a.output/'TW1_00.data';assets=entries(path.read_bytes());m=dict(assets);name='assets/xml/int_buildings.txt';ui=E.fromstring(decode(m[name]));win=ui.find('trade_menu');children=win.find('children')
def setv(node,k,v):
 el=node.find(k)
 if el is None:el=E.SubElement(node,k)
 el.text=str(v)
for i,y in [(1,5),(2,55),(3,80),(4,105)]:
 for prefix in ['icon','item','qty_decrease','qty_edit','qty_increase','maxout']:
  node=children.find(prefix+str(i));setv(node,'y',y if prefix in ['icon','qty_edit'] else y+5)
for original,tag,y,command in [('icon1','rticon0',30,None),('item1','rtname0',35,None),('qty_edit1','rga0',30,None),('qty_decrease1','rtdec0',35,'trade_inc(rg0-)'),('qty_increase1','rtinc0',35,'trade_inc(rg0+)'),('maxout1','rtmax0',35,'trade_inc(rg0M)')]:
 node=copy.deepcopy(children.find(original));node.tag=tag;setv(node,'y',y)
 if tag=='rticon0':node.find('bitmap').set('bitmap','assets/graphics/ui/popup/icon_tea.png')
 if tag=='rtname0':setv(node,'text','Tea')
 if command:setv(node,'onlclick',command)
 children.append(node)
setv(win,'y',290);setv(win,'height',195);setv(children.find('topframe'),'height',195)
setv(children.find('message'),'y',140)
for tag in ['action','sell_all','back']:setv(children.find(tag),'y',165)
m[name]=encode(E.tostring(ui,encoding='ascii',xml_declaration=False));path.write_bytes(pack([(n,m[n])for n,_ in assets]));print('Tea lower quantity row added; trade window ends at y485')
