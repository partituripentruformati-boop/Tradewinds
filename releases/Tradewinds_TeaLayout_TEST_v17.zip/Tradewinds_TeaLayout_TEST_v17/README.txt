Tradewinds v17 — Tea market layout

Display order: General Merchandise, Tea, Arms, Silk and textiles, Dream Dust.
Item rows have consistent 28-pixel spacing. Tea quantity and Buy/Max/Sell/Max
controls occupy their own wide row beneath Dream Dust. The separate native
Buy/Sell/Leave menu and original commodity trade window move lower, with a
20-pixel gap below the marketplace panel. A note explains where to buy Tea.

Tea buys exclusively in Tanchon. In every other port, its Buy and purchase-Max
buttons display --. Use the Tea controls in the upper panel; the original lower
Buy window remains for the original four commodities. Tea can be sold elsewhere.
All v16 features, trading, saves and executable code are unchanged. The only
changed resource is assets/xml/int_buildings.txt. This does not change pricing,
port restrictions, command routing, ship stats or warehouse capacity.

INSTALL
Back up saves and your current two patch files. Extract the ZIP and copy BOTH
the executable and TW1_00.data into the original game folder. The executable is
byte-identical to v16; startup logs therefore still say v16, which is expected.
Check buying Tea in Tanchon, the new layout, and save/reload on a backup save.
If it crashes, send the startup log. Keep v15 files and pre-Tea saves for rollback.

VALIDATION
94 existing regressions and the Tea layout/command binding check passed.
Build assertions verify item ordering, button bounds/gaps and separation from
the lowered menu. All other resource payloads and the executable are verified
byte-identical to v16. Actual Windows rendering is pending user testing.

REBUILD
Run source/build_market_layout.py --base <v16 folder> --output <v17 folder>.
The included other sources reproduce the v16 Tea baseline.
