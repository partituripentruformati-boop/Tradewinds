"""Integration checks for the candidate's compiled native bridge and trailer."""
from pathlib import Path
import json, struct, unittest
import pefile
from unicorn import Uc, UC_ARCH_X86, UC_MODE_32, UC_HOOK_CODE
from unicorn.x86_const import *

import argparse
parser=argparse.ArgumentParser();parser.add_argument('--output',type=Path,default=Path('/workspace/Tradewinds-regional-candidate'));options,remaining=parser.parse_known_args()
OUT=options.output
PE=pefile.PE(str(OUT/'TradewindsClassic_100Ships_2xHull_ShipyardCatalog_TEST.exe'))
SYMS=json.loads(((OUT/'source/disabled-regional-manifest.json') if (OUT/'isolation-manifest.json').exists() else (OUT/'regional-manifest.json')).read_text())['symbols']
STOP,STACK,MANAGER,PORTS,PLAYER,MARKET=0x4ff000,0x318000,0x200000,0x200100,0x200200,0x200300

class Machine:
 def __init__(self):
  self.u=Uc(UC_ARCH_X86,UC_MODE_32)
  for a,n in [(0,4096),(0x400000,0x100000),(0x200000,0x80000),(0x300000,0x20000)]:self.u.mem_map(a,n)
  self.u.mem_write(0x400000,PE.get_memory_mapped_image())
  self.alloc=0x240000;self.windows={};self.controls={};self.texts={};self.it={};self.registered={}
  self.ships=[];self.ports=[];self.stream=b'';self.position=0;self.roll=0;self.refreshes=0;self.stops=set()
  for address,value in [(0x465dac,MANAGER),(0x465d98,PORTS),(0x465d74,PLAYER),(0x465d88,MARKET),(0x465dc0,0x200400),(0x465d44,0x200500),(0x465d68,0x200600)]:self.w(address,value)
  self.w(0x220000+0x28,0x401100)
  self.u.hook_add(UC_HOOK_CODE,self.hook)
  self.ship(450,35,'Black Dragon');self.ship(50,1,'Junk')
  for tag in ['tanchon','lamasut','edamame','jiaching']:
   p=0x212000+len(self.ports)*0x100;self.string(p,tag);self.ports.append(p)
   self.w(p+0x48,p+0x80)
  self.w(PORTS+0x1c,self.ports[0]);self.w(MARKET+0xa0,self.ports[0]+0x80)
  self.setgold(1000000)
 def r(self,a):return struct.unpack('<I',self.u.mem_read(a,4))[0]
 def w(self,a,v):self.u.mem_write(a,struct.pack('<I',v&0xffffffff))
 def cstr(self,a):
  b=bytearray()
  while self.u.mem_read(a+len(b),1)!=b'\0':b.extend(self.u.mem_read(a+len(b),1))
  return b.decode()
 def string(self,a,s):
  p=self.alloc;self.alloc+=(len(s)+16)&~15;self.u.mem_write(p,s.encode()+b'\0');self.w(a,len(s));self.w(a+4,p)
 def ship(self,capacity,guns,name):
  p=0x210000+len(self.ships)*0x100;t=p+0x80;self.w(p,t);self.string(p+4,name)
  self.string(t,'megaship' if capacity==450 else 'junk');self.w(t+0x18,capacity);self.w(t+0x1c,40)
  self.w(p+0x14,guns);self.u.mem_write(p+0x31,b'\x01');self.ships.append(p);return p
 def setgold(self,n):self.u.mem_write(PLAYER+0x10,struct.pack('<Q',n))
 def gold(self):return struct.unpack('<Q',self.u.mem_read(PLAYER+0x10,8))[0]
 def ret(self,n=0,value=None):
  sp=self.u.reg_read(UC_X86_REG_ESP);target=self.r(sp);self.u.reg_write(UC_X86_REG_ESP,sp+4+n)
  if value is not None:self.u.reg_write(UC_X86_REG_EAX,value&0xffffffff)
  self.u.reg_write(UC_X86_REG_EIP,target)
 def hook(self,u,a,n,_):
  if a in self.stops:u.emu_stop();return
  sp=u.reg_read(UC_X86_REG_ESP);cx=u.reg_read(UC_X86_REG_ECX)
  if a==0x42d0e0:self.string(cx,self.cstr(self.r(sp+4)));self.ret(4,cx)
  elif a==0x42d1a0:self.ret()
  elif a in [0x401890,0x40a580]:
   name=self.cstr(self.r(sp+8))
   if a==0x401890:
    if name not in self.windows:self.windows[name]=0x221000+len(self.windows)*0x100
    value=self.windows[name]
   else:
    key=(cx,name)
    if key not in self.controls:
     value=0x230000+len(self.controls)*0x40;self.controls[key]=value;self.w(value,0x220000);self.texts[value]='0'
    value=self.controls[key]
   self.ret(8,value)
  elif a==0x401100:self.texts[cx]=self.cstr(self.r(sp+8));self.ret(8)
  elif a==0x40bff0:
   out=self.r(sp+4);self.string(out,self.texts.get(cx,'0'));self.ret(4,out)
  elif a==0x412a00:
   self.registered[self.cstr(self.r(sp+8))]=self.r(sp+12);self.ret(12)
  elif a==0x430340:
   root=self.r(sp+4);assert root in [MANAGER+0x38,PORTS+0x28]
   self.it[cx]=[self.ships if root==MANAGER+0x38 else self.ports,-1];self.ret(4,cx)
  elif a==0x430370:
   self.it[cx][1]+=1;self.ret(0,int(self.it[cx][1]<len(self.it[cx][0])))
  elif a==0x430360:self.ret(0,self.it[cx][0][self.it[cx][1]])
  elif a==0x430390:self.it.pop(cx,None);self.ret()
  elif a==0x4260c0:
   ship=self.r(self.r(cx+0xc));price=self.r(cx+0x24);self.w(ship+0x14,self.r(ship+0x14)+1);self.setgold(self.gold()-price);self.ret()
  elif a==0x4375c7:self.roll=(self.roll+7919)&32767;self.ret(0,self.roll)
  elif a in [0x418010,0x42a340,0x414760]:self.refreshes+=1;self.ret(8 if a==0x414760 else 0)
  elif a in [0x438768,0x438a09]:
   pointer,size,count,file=[self.r(sp+i) for i in [4,8,12,16]];assert file==0x1234
   if a==0x438a09:
    data=bytes(u.mem_read(pointer,size*count));self.stream=self.stream[:self.position]+data;self.position+=len(data);self.ret(0,count)
   else:
    data=self.stream[self.position:self.position+size*count]
    if data:u.mem_write(pointer,data)
    self.position+=len(data);self.ret(0,len(data)//size)
 def call(self,name,*args):
  self.u.reg_write(UC_X86_REG_ESP,STACK)
  self.u.mem_write(STACK,struct.pack('<'+'I'*(len(args)+1),STOP,*args))
  self.u.emu_start(SYMS[name],STOP,count=500000)
  assert self.u.reg_read(UC_X86_REG_ESP)==STACK+4,(name,hex(self.u.reg_read(UC_X86_REG_ESP)))
  return self.u.reg_read(UC_X86_REG_EAX)
 def native(self,address,*args,owner=MANAGER):
  self.u.reg_write(UC_X86_REG_ESP,STACK);self.u.reg_write(UC_X86_REG_ECX,owner)
  self.u.mem_write(STACK,struct.pack('<'+'I'*(len(args)+1),STOP,*args))
  self.u.emu_start(address,STOP,count=500000)
  assert self.u.reg_read(UC_X86_REG_ESP)==STACK+4+4*len(args)
  return self.u.reg_read(UC_X86_REG_EAX)
 def fragment(self,address,target,registers):
  self.u.reg_write(UC_X86_REG_ESP,STACK)
  for r,v in registers.items():self.u.reg_write(r,v)
  self.stops.add(target);self.u.emu_start(address,STOP,count=500000);self.stops.remove(target)
  assert self.u.reg_read(UC_X86_REG_EIP)==target
 def action(self,text):self.u.mem_write(0x218000,text.encode()+b'\0');return self.call('rg_action',0x218000)
 def q(self,p):return self.call('regional_slot',p,1)
 def collect(self):
  self.call('rg_io_begin')
  for p in self.ships:self.call('rg_collect_ship',p)

class IntegrationTests(unittest.TestCase):
 def test_registration_and_all_purchase_sources(self):
  m=Machine();m.call('rg_register',MARKET);self.assertEqual(len(m.registered),24)
  for i in range(3):
   self.assertEqual(m.registered[f'rg{i}B'],MARKET)
   for port in m.ports:
    m.call('rg_reset');m.w(PORTS+0x1c,port);m.setgold(1000000)
    m.action(f'rg{i}B')
    count=sum(m.r(m.q(ship)+i*4) for ship in m.ships)
    self.assertEqual(count,140 if port==m.ports[i] else 0)
 def test_purchase_sale_gold_and_speed(self):
  m=Machine();m.call('rg_prices_refresh');price=m.r(SYMS['rg_prices'])
  before=m.gold();m.action('rg0B');self.assertEqual(m.gold(),before-140*price)
  self.assertEqual(m.r(m.ships[0]+0xc),22)
  m.action('rg0S');self.assertEqual(m.gold(),before)
  self.assertEqual(sum(m.r(m.q(s)) for s in m.ships),0)
 def test_sale_in_other_port_and_warehouse_transfers(self):
  m=Machine();m.action('rg0B');m.action('rg0D')
  ware=m.ports[0]+0x80;self.assertEqual(m.r(m.q(ware)),140)
  self.assertEqual(sum(m.r(m.q(s)) for s in m.ships),0)
  m.action('rg0L');self.assertEqual(m.r(m.q(ware)),0)
  m.w(PORTS+0x1c,m.ports[1]);m.call('rg_prices_refresh');m.action('rg0S')
  self.assertEqual(sum(m.r(m.q(s)) for s in m.ships),0)
 def test_full_warehouse_rejects_overflow(self):
  m=Machine();ware=m.ports[0]+0x80;m.w(ware,14999)
  m.action('rg0B');m.action('rg0D');self.assertEqual(m.r(m.q(ware)),1)
  self.assertEqual(sum(m.r(m.q(s)) for s in m.ships),139)
 def test_round_trip_ship_warehouse_and_price(self):
  m=Machine();m.action('rg0B');m.action('rg0D');m.action('rg0B');m.collect()
  self.assertEqual(m.call('rg_save',0x1234),1);saved=m.stream
  original=[bytes(m.u.mem_read(m.q(p),12)) for p in m.ships+[p+0x80 for p in m.ports]]
  prices=bytes(m.u.mem_read(SYMS['rg_prices'],12));m.call('rg_reset');m.position=0;m.collect()
  self.assertEqual(m.call('rg_load',0x1234),1)
  self.assertEqual(original,[bytes(m.u.mem_read(m.q(p),12)) for p in m.ships+[p+0x80 for p in m.ports]])
  self.assertEqual(bytes(m.u.mem_read(SYMS['rg_prices'],12)),prices)
  self.assertEqual(m.stream,saved)
 def test_old_save_and_bad_extension(self):
  m=Machine();m.collect();self.assertEqual(m.call('rg_load',0x1234),1)
  m.action('rg0B');m.collect();m.call('rg_save',0x1234);valid=m.stream
  for bad in [valid[:3],valid[:-1],b'XXXX'+valid[4:],valid[:-1]+bytes([valid[-1]^1])]:
   m.call('rg_reset');m.collect();m.stream=bad;m.position=0
   self.assertEqual(m.call('rg_load',0x1234),0)
   self.assertEqual(sum(m.r(m.q(s)) for s in m.ships),0)
 def test_native_original_trade_distributes_with_extra_cargo(self):
  for good in range(4):
   m=Machine();m.w(m.q(m.ships[0]),90);m.w(m.q(m.ships[1]),35)
   for ship in m.ships:m.u.mem_write(ship+0x30,b'\x01')
   m.native(0x423860,good,15,150)
   self.assertEqual(sum(m.r(s+0x18+good*4) for s in m.ships),15)
   self.assertEqual(m.call('regional_ship_free',m.ships[0]),0)
   self.assertEqual(m.call('regional_ship_free',m.ships[1]),0)
 def test_native_ship_sale_redistributes_all_goods(self):
  m=Machine();source=m.ships[1];dest=m.ships[0]
  m.w(m.q(source),20);m.w(source+0x18,15)
  m.native(0x423a20,source)
  self.assertEqual(m.r(m.q(dest)),20);self.assertEqual(m.r(m.q(source)),0)
  self.assertEqual(m.r(dest+0x18),15);self.assertEqual(m.r(source+0x18),0)
 def test_native_fleet_free_and_release(self):
  m=Machine();m.w(m.q(m.ships[0]),97)
  self.assertEqual(m.native(0x4236a0),43)
  m.native(0x423da0,m.ships[0]);self.assertEqual(m.call('regional_slot',m.ships[0],0),0)
 def test_cannon_limit_includes_extra_goods(self):
  m=Machine();yard=0x214000;info=yard+0x80;m.w(yard+0xc,info);m.w(info,m.ships[0]);m.w(yard+0x24,6000)
  m.w(m.q(m.ships[0]),85);before=m.gold()
  m.native(SYMS['rg_max_cannons'],owner=yard)
  self.assertEqual(m.r(m.ships[0]+0x14),36);self.assertEqual(m.gold(),before-6000)
  m.w(STACK,0x4563a4)
  m.fragment(0x425b1f,0x425b27,{UC_X86_REG_EBX:m.ships[0],UC_X86_REG_ECX:0x219000})
  self.assertEqual(m.u.reg_read(UC_X86_REG_EDI),5)
 def test_native_dispatch_and_refresh_fragments(self):
  m=Machine();m.u.mem_write(0x218000,b'rg0B\x00');m.w(STACK+0x40,0x218000)
  m.fragment(0x418a19,0x41905a,{UC_X86_REG_ESI:MARKET})
  self.assertEqual(sum(m.r(m.q(s)) for s in m.ships),140)
  m.fragment(0x417e33,0x417e3f,{})
  m.w(STACK+0x30,0x12345678)
  m.fragment(0x418185,0x418190,{})
  self.assertEqual(m.r(0),0x12345678)
  self.assertEqual(m.texts[m.controls[(m.windows['marketplace'],'rgb0')]],'Buy')
  m.fragment(0x42a550,0x42a55c,{})
  self.assertEqual(m.u.reg_read(UC_X86_REG_ECX),STACK+0x2c)
 def test_theft_selects_extra_stock(self):
  m=Machine();ware=m.ports[0]+0x80;q=m.q(ware);m.w(q,100)
  self.assertEqual(m.call('rg_theft_target',ware),q)
  ui=0x200400;m.w(ui+0x2c,ware)
  m.fragment(0x42a0df,0x42a11b,{UC_X86_REG_EDI:ui})
  m.fragment(0x42a158,0x42a15e,{UC_X86_REG_EDI:ui})
  self.assertEqual(m.u.reg_read(UC_X86_REG_ESI),q)
 def test_save_load_end_hook_stack_and_status(self):
  m=Machine();m.action('rg0B');m.collect()
  m.w(STACK,0x11223344);m.w(STACK+4,STOP);m.w(STACK+8,0x1234)
  m.u.reg_write(UC_X86_REG_ESP,STACK);m.u.reg_write(UC_X86_REG_ESI,0x1234)
  m.u.emu_start(0x420a21,STOP,count=500000)
  self.assertEqual(m.u.reg_read(UC_X86_REG_EAX),1);self.assertEqual(m.u.reg_read(UC_X86_REG_ESP),STACK+12)
  m.call('rg_reset');m.collect();m.position=0
  for offset,value in [(0,0x11),(4,0x22),(8,0x33),(12,STOP),(16,0x1234)]:m.w(STACK+offset,value)
  m.u.reg_write(UC_X86_REG_ESP,STACK);m.u.reg_write(UC_X86_REG_EDI,0x1234)
  m.u.emu_start(0x420963,STOP,count=500000)
  self.assertEqual(m.u.reg_read(UC_X86_REG_EAX),1);self.assertEqual(m.u.reg_read(UC_X86_REG_ESP),STACK+20)
  self.assertEqual(sum(m.r(m.q(s)) for s in m.ships),140)
 def test_capacity_refresh_fragments_and_inventory_selection(self):
  m=Machine();ware=m.ports[0]+0x80;m.w(ware,100);m.w(m.q(ware),200)
  m.fragment(0x418048,0x41805c,{UC_X86_REG_ECX:ware})
  self.assertEqual(m.u.reg_read(UC_X86_REG_EAX),14700)
  m.fragment(0x42a3b7,0x42a3d7,{UC_X86_REG_ECX:ware,UC_X86_REG_ESI:0x200400})
  self.assertEqual(m.r(0x200430),14700)
  m.w(m.q(m.ships[0]),80);m.w(STACK+0x14,60)
  m.fragment(0x418165,0x41816d,{UC_X86_REG_EDI:MARKET,UC_X86_REG_EBX:0})
  self.assertEqual(m.u.reg_read(UC_X86_REG_EBX),80);self.assertEqual(m.r(STACK+0x14),140)
  m.fragment(0x42a4ab,0x42a4b1,{UC_X86_REG_EBX:10})
  self.assertEqual(m.u.reg_read(UC_X86_REG_EBX),90)
  m.call('rg_ui_refresh');control=m.controls[(m.windows['warehouse'],'rgw0')]
  self.assertEqual(m.texts[control],'80')
  m.u.mem_write(0x200428,b'\x01');m.call('rg_ui_refresh');self.assertEqual(m.texts[control],'200')
 def test_quantity_input_buy_and_sell(self):
  m=Machine();m.call('rg_ui_refresh');window=m.windows['marketplace']
  # Create the same edit control the XML names, then exercise native text getter.
  m.u.mem_write(0x218000,b'rga0\x00');m.string(0x219000,'rga0')
  m.native(0x40a580,m.r(0x219000),m.r(0x219004),owner=window)
  control=m.controls[(window,'rga0')];m.texts[control]='7'
  m.action('rg0b');self.assertEqual(sum(m.r(m.q(s)) for s in m.ships),7)
  m.texts[control]='3';m.action('rg0s');self.assertEqual(sum(m.r(m.q(s)) for s in m.ships),4)
  m.texts[control]='2147483648';before=m.gold();m.action('rg0b');self.assertEqual(m.gold(),before)
 def test_layout_and_command_bindings(self):
  import xml.etree.ElementTree as ET
  data=(OUT/'TW1_00.data').read_bytes();pos=8;assets={}
  for _ in range(struct.unpack_from('<I',data,4)[0]):
   end=data.index(0,pos);name=data[pos:end].decode();off,size=struct.unpack_from('<II',data,end+1);pos=end+9;assets[name]=data[off:off+size]
  key=b'klxd8794lkds87934poi';payload=assets['assets/xml/int_buildings.txt']
  ui=ET.fromstring(bytes((v-key[i%len(key)])%256 for i,v in enumerate(payload)))
  for i,tag in enumerate(['tea','spices','jade']):
   self.assertIn('assets/graphics/ui/popup/icon_'+tag+'.png',assets)
   self.assertEqual(ui.findtext(f'marketplace/children/rgb{i}/onlclick'),f'rg{i}b')
   self.assertEqual(ui.findtext(f'warehouse/children/rgl{i}/onlclick'),f'rg{i}L')

if __name__=='__main__':unittest.main(argv=[__file__]+remaining,verbosity=2)
