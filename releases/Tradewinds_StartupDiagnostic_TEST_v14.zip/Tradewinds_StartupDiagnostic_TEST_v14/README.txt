Tradewinds v14 startup diagnostic

V13 reached all 11 building-constructor entry points, then reported an access
violation at 778F0528. This does not establish which constructor completed or
which game/library call caused the failure. V14 corrects the exception-record
parameter offsets, records main/crashing thread IDs and mapped DLL names/base
addresses, and extends the readable-region stack capture from 32 to 256 words.
It retains every v11 gameplay feature and byte-identical TW1_00.data.
This is a diagnostic build, not a confirmed crash repair.

Extract this ZIP and copy BOTH the executable and TW1_00.data into your original
game folder alongside its original DLLs and TW1_01.data. Back up saves first.
Run once and send Tradewinds-startup.log; its first line should say v14.
No save-file replacement is required. The log can contain installation paths.

Validation: 94 existing regression checks and eight diagnostic checks passed.
Diagnostic checks exercise register/stack preservation, correct exception
parameters, thread IDs, module-name records, bounded stack capture and fallback
when log creation fails. Native Wine/QEMU startup was also exercised, subject
to the existing graphics-mode limitation. Windows crash remains unreproduced.
