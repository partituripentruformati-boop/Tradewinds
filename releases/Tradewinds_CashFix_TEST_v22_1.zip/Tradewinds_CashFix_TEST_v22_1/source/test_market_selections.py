import unittest
from test_tea_trade_row import TradeMachine
from test_regional_runtime import MARKET,PORTS,OUT
from unicorn.x86_const import UC_X86_REG_ESP
class SelectionMachine(TradeMachine):
 def __init__(self):self.selected=[];self.forwarded=[];super().__init__();self.input(0)
 def select_original(self,values):
  window=self.windows['trade_menu']
  for i,n in enumerate(values):
   self.string(0x219000,f'qty_edit{i+1}');p=self.native(0x40a580,self.r(0x219000),self.r(0x219004),owner=window);self.w(MARKET+0x40+i*4,p);self.texts[p]=str(n)
  self.selected=list(values)
 def hook(self,u,a,n,user):
  if a==0x418010:
   # Native 41813d..418158 sets qty_edit1..4 to the string "0".
   for i in range(4):
    p=self.r(MARKET+0x40+i*4)
    if p:self.texts[p]='0'
   self.refreshes+=1;self.ret()
  elif a in [0x4181a0,0x4184e0]:
   values=[int(self.texts.get(self.r(MARKET+0x40+i*4),'0'))for i in range(4)];self.forwarded.append(values);self.native_trades.append(a)
   ware=self.r(MARKET+0x99)&255;dest=self.ports[0]+0x80 if ware else self.ships[0]+0x18
   for i,v in enumerate(values):self.w(dest+i*4,self.r(dest+i*4)+(v if a==0x4181a0 else -v))
   self.ret()
  else:super().hook(u,a,n,user)
class MarketSelectionTests(unittest.TestCase):
 def test_original_buy_quantities_all_ports_fleet_and_warehouse(self):
  for portindex in range(4):
   for ware in [False,True]:
    m=SelectionMachine();m.w(PORTS+0x1c,m.ports[portindex]);m.u.mem_write(MARKET+0x99,bytes([ware,1]));m.select_original([1,2,3,4]);m.lower('trade');self.assertEqual(m.forwarded,[[1,2,3,4]])
 def test_mixed_tea_and_original_buy_preserves_selections(self):
  m=SelectionMachine();m.input(5);m.u.mem_write(MARKET+0x9a,b'\1');m.select_original([4,3,2,1]);m.lower('trade');self.assertEqual(m.forwarded,[[4,3,2,1]]);self.assertEqual(sum(m.r(m.q(s))for s in m.ships),5)
 def test_mixed_tea_and_original_sell_preserves_selections(self):
  m=SelectionMachine();m.w(m.q(m.ships[0]),5);m.input(2);m.u.mem_write(MARKET+0x9a,b'\0\1');m.select_original([1,2,3,4]);
  for i in range(4):m.w(m.ships[0]+0x18+i*4,10)
  m.lower('trade');self.assertEqual(m.forwarded,[[1,2,3,4]]);self.assertEqual(sum(m.r(m.q(s))for s in m.ships),3)
 def test_tea_only_purchase_still_works(self):
  m=SelectionMachine();m.input(7);m.select_original([0,0,0,0]);m.u.mem_write(MARKET+0x9a,b'\1');m.lower('trade');self.assertEqual(sum(m.r(m.q(s))for s in m.ships),7);self.assertEqual(m.forwarded,[[0,0,0,0]])
if __name__=='__main__':unittest.main(argv=[__file__],verbosity=2)
