Tradewinds v22.1 TEST — visible cash updates for Tea and Spices

CAUSE
The regional trade routine already subtracts/credits the wallet's real 64-bit
balance. Its subsequent call to native spending function 414760 with amount
zero was intended as a UI refresh, but that function returns immediately on
zero and does not update cash labels. Tea/Spices-only purchases appeared free;
the displayed value was stale. Ordinary trades could later refresh the display.

FIX
After a regional trade, format the current wallet balance using the game's
native formatter and update both cash display controls directly. This does
not debit/credit any additional gold. Applies to Tea and Spices buying, selling
and Sell All, whether inventory is in the fleet or warehouse. Large balances
and spending the exact available gold (displaying zero) are checked.

All v22 behavior remains: Tea buys only in Tanchon; Spices buys only in Lama
Sut; both sell elsewhere, fluctuate in price, transfer and save/load. Shared
alehouse tips, supplied art and all ship/warehouse upgrades remain. The confirmed
original-item quantity fix is retained. Jade remains disabled.
TW1_00.data is byte-identical to v22; save format and trade accounting unchanged.

INSTALL AND TEST
Close the game and back up saves/current patch files. Extract and replace BOTH
executable and TW1_00.data in the original folder. Data is unchanged, but copying
both avoids a mismatched installation. Buy a small Tea quantity in Tanchon or
Spices quantity in Lama Sut; confirm the cash display decreases by amount times
price. Sell some and confirm it increases. The log now begins v22.1.
If cash still fails to change, report price, quantity, destination and cash
before/after, and whether stock increased. Keep your prior files for rollback.

VALIDATION
Five cash display/accounting checks passed. Four fail on original v22 as
expected. Tests exercise the REAL native zero-spend early-return path and
check cash debits/credits alongside both visible cash fields. Formatting and
GUI setters are mocked, so actual Windows rendering requires user testing.
94 existing regressions, nine Spices/migration tests, four original-item
selection tests and eight diagnostic checks passed. Source rebuild reproduces
both files exactly. Real Wine/QEMU startup reached all 11 constructor entry
markers without a logged crash; its graphics-mode limitation remains.

REBUILD
source/build_spices_patch.py --base-v7 <working v7 folder> --output <folder>
Requires Python, pefile, capstone, Pillow, gcc -m32 and binutils; tests use Unicorn.
