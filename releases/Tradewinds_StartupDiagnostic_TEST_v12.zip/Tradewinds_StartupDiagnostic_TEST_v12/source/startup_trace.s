.intel_syntax noprefix
.section .text
.global startup_trace_hook
.extern startup_trace
startup_trace_hook:
 pushfd
 pushad
 mov eax,DWORD PTR [esp+12]
 push DWORD PTR [eax+8]
 call startup_trace
 add esp,4
 popad
 popfd
 push ebp
 mov ebp,esp
 and esp,-8
 jmp 0x401c46
