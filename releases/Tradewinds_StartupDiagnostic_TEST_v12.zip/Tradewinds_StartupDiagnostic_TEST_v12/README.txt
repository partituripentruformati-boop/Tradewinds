Tradewinds Classic v12 DIAGNOSTIC — building-loading investigation

This build records native window/control loading to Tradewinds-startup.log.
It also records an unhandled Windows exception code/address when available.
It is an investigation build, not a confirmed repair for the reported crash.
TW1_00.data is byte-for-byte identical to v11; all ship and economy features
remain included. The only executable change adds diagnostic logging.

INSTALL AND REPORT
Close the game and back up saves. Extract the ZIP. Copy BOTH the executable
and TW1_00.data into the original game folder alongside bass.dll, fmod.dll,
gd204.dll and TW1_01.data. Launch the patched executable from that folder.
After the game closes, send Tradewinds-startup.log from that same folder.
If no log is created, report that. Some termination paths do not invoke the
Windows exception handler; the last BEGIN record is still useful.
Do not launch the executable while it is inside the ZIP.

VALIDATION
94 gameplay/artwork/PE regression checks passed. Five diagnostic checks verify
native stack/register preservation, control paths, initialization, flushed
exception records and safe fallback when the folder is unwritable.
The real game ran under Wine 10 with QEMU i386 CPU emulation: all modified
building controls loaded, followed by port UI loading, with 586 trace records
and no crash record. That runner subsequently reached a graphics-mode failure;
full gameplay and the user's Windows crash remain unverified.

FEATURES RETAINED
Five shipyard tiers/restocking; maximum-cannon buying; 100 ships; doubled hull;
Black Dragon artwork and 450 cargo/45 cannons; Junk 50 cargo/5 cannons;
Fair Wind artwork and 250 cargo/25 cannons/60 engine maximum hull;
15,000-unit warehouses; Tea/Tanchon, Spices/Lama Sut, Jade & Gemstones/Edamame,
fluctuating regional prices and sale at other ports.
