from pathlib import Path
import unittest,struct,xml.etree.ElementTree as E
from test_warehouse_tea import WareMachine
from test_market_selections import SelectionMachine
from test_regional_runtime import OUT,SYMS,MARKET,PORTS
from fix_xml_format import entries,decode
class SpiceMachine(WareMachine):
 def setinput(self,i,n,ware=False):
  self.lower('trade_inc',f'rw{i}+' if ware else f'rg{i}+')
  window=self.windows['warehouse' if ware else 'trade_menu'];self.texts[self.controls[(window,f'rga{i}')]]=str(n)
class SpicesTests(unittest.TestCase):
 def test_source_exclusivity_and_varying_prices(self):
  m=SpiceMachine();prices=set()
  for p in m.ports:
   m.w(PORTS+0x1c,p);m.call('rg_reset');m.call('rg_prices_refresh');m.action('rg1B');self.assertEqual(sum(m.r(m.q(s)+4)for s in m.ships),140 if p==m.ports[1]else 0)
  m.w(PORTS+0x1c,m.ports[1])
  for _ in range(10):m.call('rg_prices_refresh');prices.add(m.r(SYMS['rg_prices']+4))
  self.assertGreater(len(prices),1);self.assertEqual(m.action('rg2B'),0)
 def test_native_lower_buy_sell_and_sell_all(self):
  m=SpiceMachine();m.w(PORTS+0x1c,m.ports[1]);m.u.mem_write(MARKET+0x9a,b'\1');m.setinput(1,12);gold=m.gold();m.lower('trade');price=m.r(SYMS['rg_prices']+4);self.assertEqual(sum(m.r(m.q(s)+4)for s in m.ships),12);self.assertEqual(m.gold(),gold-12*price);self.assertEqual(m.native_trades[-1],0x4181a0)
  m.u.mem_write(MARKET+0x9a,b'\0\1');m.setinput(1,2);m.lower('trade');self.assertEqual(sum(m.r(m.q(s)+4)for s in m.ships),10);m.w(PORTS+0x1c,m.ports[3]);m.call('rg_prices_refresh');before=m.gold();price=m.r(SYMS['rg_prices']+4);m.lower('sell_all');self.assertEqual(sum(m.r(m.q(s)+4)for s in m.ships),0);self.assertEqual(m.gold(),before+10*price)
 def test_combined_stock_transfer_and_single_native_transfer(self):
  m=SpiceMachine();m.w(m.q(m.ships[0]),6);m.w(m.q(m.ships[0])+4,7);m.setinput(0,3,True);m.setinput(1,4,True);m.lower('trade_inc','rw0t');w=m.ports[0]+0x80;self.assertEqual([m.r(m.q(w)+i*4)for i in range(2)],[3,4]);self.assertEqual(m.transfers,[0x42ab60]);m.u.mem_write(0x200428,b'\1');m.lower('trade_inc','rw0M');m.lower('trade_inc','rw1M');m.lower('trade_inc','rw0t');self.assertEqual([m.r(m.q(w)+i*4)for i in range(2)],[0,0]);self.assertEqual(m.transfers[-1],0x42a780)
 def test_shared_capacity_and_spices_max_gold(self):
  m=SpiceMachine();m.w(PORTS+0x1c,m.ports[1]);m.u.mem_write(MARKET+0x9a,b'\1');m.w(m.q(m.ships[0]),130);m.call('rg_prices_refresh');price=m.r(SYMS['rg_prices']+4);m.setgold(5*price);m.lower('trade_inc','rg1M');v=m.texts[m.controls[(m.windows['trade_menu'],'rga1')]];self.assertEqual(v,'5');m.lower('trade');self.assertEqual(sum(m.r(m.q(s)+4)for s in m.ships),5);self.assertEqual(m.gold(),0)
 def test_v21_save_migration_preserves_tea_and_initializes_spices_price(self):
  m=SpiceMachine();m.stream=(Path(__file__).parent/'fixtures/v21-save-extension.bin').read_bytes();m.collect();self.assertEqual(m.call('rg_load',0x1234),1);self.assertEqual(sum(m.r(m.q(s))for s in m.ships),140);self.assertEqual(sum(m.r(m.q(s)+4)for s in m.ships),0);oldprice=m.r(SYMS['rg_prices']);self.assertEqual(m.r(SYMS['rg_prices']+4),0);m.call('rg_ui_refresh');self.assertGreater(m.r(SYMS['rg_prices']+4),0);self.assertEqual(m.r(SYMS['rg_prices']),oldprice)
 def test_both_goods_save_reload_roundtrip(self):
  m=SpiceMachine();m.w(m.q(m.ships[0]),12);m.w(m.q(m.ships[0])+4,34);m.w(m.q(m.ports[1]+0x80)+4,567);m.collect();m.call('rg_save',0x1234);m.call('rg_reset');m.position=0;m.collect();self.assertEqual(m.call('rg_load',0x1234),1);self.assertEqual(m.r(m.q(m.ships[0])),12);self.assertEqual(m.r(m.q(m.ships[0])+4),34);self.assertEqual(m.r(m.q(m.ports[1]+0x80)+4),567)
 def test_spices_purchase_preserves_original_goods_selections(self):
  m=SelectionMachine();m.w(PORTS+0x1c,m.ports[1]);m.u.mem_write(MARKET+0x9a,b'\1');m.lower('trade_inc','rg1+');m.texts[m.controls[(m.windows['trade_menu'],'rga1')]]='3';m.select_original([1,2,3,4]);m.lower('trade');self.assertEqual(m.forwarded,[[1,2,3,4]]);self.assertEqual(sum(m.r(m.q(s)+4)for s in m.ships),3)
 def test_two_regional_goods_sale_preserves_original_selections(self):
  m=SelectionMachine();m.w(m.q(m.ships[0]),6);m.w(m.q(m.ships[0])+4,7);m.input(2);m.lower('trade_inc','rg1+');m.texts[m.controls[(m.windows['trade_menu'],'rga1')]]='3';m.u.mem_write(MARKET+0x9a,b'\0\1');m.select_original([1,2,3,4]);
  for i in range(4):m.w(m.ships[0]+0x18+i*4,10)
  m.lower('trade');self.assertEqual(m.forwarded,[[1,2,3,4]]);self.assertEqual(sum(m.r(m.q(s))for s in m.ships),4);self.assertEqual(sum(m.r(m.q(s)+4)for s in m.ships),4)
 def test_ui_source_icon_tip_and_bounds(self):
  assets=dict(entries((OUT/'TW1_00.data').read_bytes()));u=E.fromstring(decode(assets['assets/xml/int_buildings.txt']));p=E.fromstring(decode(assets['assets/xml/alehouse.txt']));self.assertTrue(any('Only Lama Sut' in (t.text or '')for t in p.findall('tip')));self.assertEqual(len(p.findall('tip')),20);self.assertEqual(assets['assets/graphics/ui/popup/icon_spices.png'],(Path(__file__).parent/'regional-goods-assets/icon_spices.png').read_bytes())
  for parent,tags in [('marketplace',['item1','rgn0','rgn1','item2','item3','item4']),('trade_menu',['item1','rtname0','rtname1','item2','item3','item4']),('warehouse',['prod1','rgn0','rgn1','prod2','prod3','prod4'])]:ys=[int(u.findtext(parent+'/children/'+t+'/y'))for t in tags];self.assertEqual(ys,sorted(ys));self.assertEqual(len(set(ys)),6)
  self.assertLessEqual(int(u.findtext('trade_menu/y'))+int(u.findtext('trade_menu/height')),485);self.assertLessEqual(int(u.findtext('warehouse/y'))+int(u.findtext('warehouse/height')),485)
if __name__=='__main__':unittest.main(argv=[__file__],verbosity=2)
