Tradewinds v21 TEST — alehouse Tea tip, larger icon and cleaner warehouses

ALEHOUSE
The marketplace label "Buy Tea in Tanchon" is removed everywhere. A new tip
in the shared paid-round dialogue pool says:
"Looking for Tea, my friend? Only Tanchon's market sells it, but you can sell
your cargo in any port."
It can be selected after buying a round at ANY alehouse, alongside the other
18 existing paid-round tips. It is random, not guaranteed after every round.
The free bartender hint list and all original paid-round tips are preserved.
Native selection uses the pool's dynamic count, now 19; no new EXE hook is
needed for the dialogue. Tea's Tanchon-only buying rule is unchanged.

ICON
Tea's icon is increased from 20x20 to 24x24 pixels, using the same tea crate,
porcelain jar and bowl design. The generated artwork is converted to indexed
P8 PNG with transparent index zero for the original graphics engine. Alignment
is adjusted in the market, lower trading row and both warehouse panels.

WAREHOUSE, EVERY PORT
Tea sits between General Merchandise and Arms in upper inventory and lower
transfer lists. The upper panel has aligned Tea Value and Qty columns and no
Load All/Store All shortcuts crowding the row. The lower panel now includes
Tea quantity with minus/plus/Max. Select the Warehouse/Fleet direction, set
quantities and use the existing Transfer button; Tea transfers first, then the
native four-item transfer continues. Max respects source stock and destination
capacity. Tea input clears after transfer. Sell Cargo still opens the normal
market flow, where Tea participates in Buy/Sell and Sell All.
The panel is enlarged within the area above the game log.

All prior ship, shipyard, Tea market, save, price and 15,000-unit warehouse
features remain. Spices and Jade stay disabled. No new command registrations
are added. This update changes both executable and resource archive.

INSTALL AND TEST
Close Tradewinds and back up saves and current patch files. Extract this ZIP;
replace BOTH executable and TW1_00.data in the original folder alongside its
original DLLs and TW1_01.data. Startup logs now say v21.
Check warehouse appearance in several ports, store/retrieve a small amount of
Tea, then save/reload. Buy a round at an alehouse to sample the shared tips;
several rounds may be needed to hear Tea information. If the game closes,
send Tradewinds-startup.log. Keep pre-Tea saves and v15 files for rollback.

VALIDATION
94 existing regressions, 18 Tea integration tests, eight Fair Wind tests,
eight startup diagnostic checks, five market-row tests and four warehouse
Tea tests passed. Warehouse checks cover selected transfers in both directions,
original-handler invocation, capacity limits, quantity controls, aligned values
and 24px indexed transparency. Native original transfer services are mocked;
Windows gameplay/rendering remains to test.
The native paid-round selector reaches the new 19th entry in all four port
fixtures, and all old dialogue/resource content is preserved except the three
intended UI/alehouse/icon resources. A clean source rebuild reproduced both
release files exactly. Wine/QEMU startup reached all 11 constructor entry
markers without a logged crash; existing graphics-mode limitation remains.

REBUILD
source/build_warehouse_tea_patch.py --base-v7 <working v7 folder> --output <folder>
Requires Python, pefile, capstone, Pillow, gcc -m32 and GNU binutils; tests use
Unicorn. The generated Tea art source and indexed game icon are included.
