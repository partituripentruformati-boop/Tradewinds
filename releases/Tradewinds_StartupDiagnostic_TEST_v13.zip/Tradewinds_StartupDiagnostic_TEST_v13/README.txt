Tradewinds Classic v13 DIAGNOSTIC — building constructors and exception context

The supplied v12 log shows all UI controls loaded, followed by an access
violation at 778F4EC6, a Windows library address. The v12 log did not contain
the caller stack, so it does not identify a confirmed defective control.
This build adds 11 native building-constructor markers and exception details:
access kind, fault address, x86 registers and up to 32 stack words. Stack reads
are restricted to a committed, readable memory region using VirtualQuery.
This is an investigation build, NOT a confirmed fix for the Windows crash.

INSTALL AND REPORT
Close the game and back up saves. Extract this ZIP. Copy BOTH the executable
and TW1_00.data into the original game folder alongside bass.dll, fmod.dll,
gd204.dll and TW1_01.data. Launch the patched executable from that folder.
After the game closes, send the new Tradewinds-startup.log from that folder.
Check that its first line says v13. No change to saved games is required.
A termination that bypasses Windows exception handling may only record stages.

FEATURES
All v11 ship, shipyard, warehouse, artwork and regional-economy features are
retained. TW1_00.data is byte-for-byte identical to v11 and v12. EXE changes
are limited to diagnostic logging and constructor-stage markers.

VALIDATION
94 gameplay/artwork/PE regression checks passed. Eight diagnostic checks
exercise native stack/register preservation, control paths, initialization,
flushed exception records, safe fallback on an unwritable folder, fault and
register details, readable-region stack capture, and all 11 constructor hooks.
Real Wine 10/QEMU startup loaded all modified UI controls and completed the
11 building constructor entries, including market, warehouse and shipyard.
The runner subsequently encountered its existing graphics-mode limitation.
The user's Windows crash remains unreproduced; caller evidence is required.
