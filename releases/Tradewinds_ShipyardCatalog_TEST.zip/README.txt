Tradewinds Classic - Shipyard Catalog TEST patch

WHAT CHANGES
The shipyard menu offers all five types defined in your supplied game data:
Junk, One-Masted Sloop, Two-Masted Sloop, Brigantine, and Juggernaut.
Select a type to open the existing ship preview and purchase confirmation.
A successful purchase generates a new offer of the same type immediately.
The random check for whether a ship appears is removed. Gold checks and the
existing 100-ship limit remain. Other executable changes in the supplied
100Ships_2xHull_TEST build are retained.

INSTALL
1. Close the game. Back up the entire game folder, including save.tw0,
   save.tw1 and save.tw2, and keep the original TW1_00.data.
2. Copy this package's TW1_00.data and
   TradewindsClassic_100Ships_2xHull_ShipyardCatalog_TEST.exe into your existing
   game folder. The new TW1_00.data replaces the original data file.
3. Launch the new executable from that folder. It requires the other original
   game files, including TW1_01.data and the DLLs already in the game folder.
   Do not rename or overwrite your original executable.
4. Enter a shipyard. Each ship type should have its own Buy entry.
   Choose a type, inspect the preview and price, then confirm or cancel.

IN-GAME CHECKS STILL REQUIRED
Use a backed-up save or a test game. Verify all five choices display the
correct type; buy the same type twice without travelling; try insufficient
gold; leave and revisit; save, exit and reload. Check repairs still work.
At 100 ships further catalog purchases are blocked; after selling a ship,
select a catalog type again to obtain a new offer.

VALIDATION AND LIMITS
34 automated checks passed using x86 emulation with engine and Windows calls
stubbed, plus PE and encoded-archive integrity checks. These validate injected
control flow, catalog selections, restock hooks, stack balance, the native
purchase affordability checks and fleet limit. They do not establish full
gameplay correctness. No Windows runtime is installed here, so game startup,
menu rendering, complete purchases and save/load have not been tested.
This is a TEST build, not a gameplay-verified release. No save files or
registry settings were modified.

ROLLBACK
Close the game, restore the original TW1_00.data from your backup, and launch
your original executable. Restore your backed-up saves if needed. The patched
executable and patched data file must be used together.

REPRODUCING
The source/ folder includes the x86 assembly, patch builder and tests.
Requires Python 3, GNU binutils (as, ld, objcopy, nm), pefile and unicorn.
Install the pinned Python dependencies from source/requirements-dev.txt.
Run:
python source/build_patch.py ORIGINAL_EXE ORIGINAL_TW1_00.data --output output
python source/test_patch.py --output output --original-data ORIGINAL_TW1_00.data
The builder checks the executable's SHA-256 and expected bytes before patching.
