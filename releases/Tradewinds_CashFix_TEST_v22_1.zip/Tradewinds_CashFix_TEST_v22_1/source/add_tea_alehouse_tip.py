"""Data-only v20: replace market source note with a global paid-round tip."""
from pathlib import Path
import argparse,json,shutil,xml.etree.ElementTree as E
from fix_xml_format import entries,pack,decode,encode
TIP="Looking for Tea, my friend? Only Tanchon's market sells it, but you can sell your cargo in any port."
p=argparse.ArgumentParser();p.add_argument('--base',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args();shutil.copytree(a.base,a.output,dirs_exist_ok=True)
path=a.output/'TW1_00.data';before=entries(path.read_bytes());assets=dict(before);layout='assets/xml/int_buildings.txt';pool='assets/xml/alehouse.txt'
ui=E.fromstring(decode(assets[layout]));children=ui.find('marketplace/children');note=children.find('tea_source_note');assert note is not None;children.remove(note)
assets[layout]=encode(E.tostring(ui,encoding='ascii',xml_declaration=False))
old=decode(assets[pool]);tree=E.fromstring(old);assert tree.tag=='alehouse';oldtips=[n.text for n in tree.findall('tip')];oldhints=[n.text for n in tree.findall('hint')];assert TIP not in oldtips
assert old.count(b'</alehouse>')==1
assets[pool]=encode(old.replace(b'</alehouse>',b'\t<tip>'+TIP.encode('ascii')+b'</tip>\r\n</alehouse>'))
newtree=E.fromstring(decode(assets[pool]));assert [n.text for n in newtree.findall('tip')]==oldtips+[TIP];assert [n.text for n in newtree.findall('hint')]==oldhints
assert ui.find('marketplace/children/tea_source_note') is None
assert ui.find('trade_menu/children/rga0') is not None
path.write_bytes(pack([(n,assets[n])for n,_ in before]));after=dict(entries(path.read_bytes()));assert all(after[n]==data for n,data in before if n not in [layout,pool])
exe='TradewindsClassic_100Ships_2xHull_ShipyardCatalog_TEST.exe';assert (a.output/exe).read_bytes()==(a.base/exe).read_bytes()
(a.output/'tea-tip-manifest.json').write_text(json.dumps(dict(version='v20',tip=TIP,pool='alehouse/tip',trigger='buyaround paid-round generic tip selection',availability='shared pool in all ports; random selection',old_tip_count=len(oldtips),new_tip_count=len(oldtips)+1,removed_control='marketplace/children/tea_source_note',changed_resources=[layout,pool],executable_unchanged=True,startup_log_version='v18 (unchanged executable)',native_evidence=dict(loader_tip_list='0x40ab21 -> alehouse+0x2c',buyaround_dispatch='0x40bf93 -> 0x40b1c0',selector='0x40bb2d reads dynamic list count and indexes random modulo count')),indent=2)+'\n');print('Marketplace note removed; global paid-round pool expanded',len(oldtips),'->',len(oldtips)+1)
