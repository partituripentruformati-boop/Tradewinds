Tradewinds v15 TEST — new commodities disabled

PURPOSE
Isolate the startup crash by removing Tea, Spices, and Jade & Gemstones and
all their market, warehouse, inventory, pricing, command and save hooks.
Thirty executable hook sites are restored. Original section payloads match
v7 byte-for-byte except the three Fair Wind selector redirects. The disabled
regional code/data payload is zeroed; Fair Wind and startup logging remain.
Market and warehouse UI are restored byte-for-byte from v7.
This is an isolation test, not a confirmed repair.

RETAINED
Black Dragon custom artwork, enlarged combat sprite, 450 cargo/45 cannons;
Fair Wind artwork, combat size, 250 cargo/25 cannons and doubled original hull;
Junk 50 cargo/5 cannons; five shipyard types and automatic availability;
max-affordable cannon buying; short repair label; warehouse 15,000 units;
existing 100-ship and doubled-hull executable modifications.

INSTALL
Close Tradewinds. Back up your saves and current executable/data file.
Extract the ZIP and replace BOTH the executable and TW1_00.data in the original
game folder alongside its original DLLs and TW1_01.data. Launch the patched EXE.
Tell us whether it gets past Constructing buildings. If it still closes, send
Tradewinds-startup.log (first line must say v15).
Use a backup save for testing. This build does not preserve inventories of the
three disabled commodities when saving; keep your existing saves backed up.
It does not require a save replacement or DLL replacement.

VALIDATION
94 existing ship/shipyard/artwork/warehouse/PE checks, eight startup diagnostic
checks and four Fair Wind migration/grouping/artwork checks passed. No disabled
regional gameplay or save tests are claimed. Windows startup remains to test.
