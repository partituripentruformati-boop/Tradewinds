Tradewinds Classic TEST patch v6

CHANGES
Black Dragon combat sprites are about 35 percent larger than a Brigantine
(160x111 per player/ally frame, versus 119x82). Animation, damage states
and bottom-center anchors are updated together. Sidebar icon size is unchanged.

Black Dragon's cargo space increases to 450, permitting 45 cannons in an
empty hold. This applies only to the named Black Dragon Juggernaut and its
registered variant. Ordinary Juggernauts retain 350 cargo / 35 cannons.
Existing saves acquire the variant when the ship display initializes.
The variant is a real, manager-registered type, so native fleet regrouping
recognizes it. There is no unregistered shadow type as in the faulty v4.

Junk class cargo space increases to 50, permitting five cannons in an empty
hold. Existing and newly purchased Junks benefit. The shipyard catalog shows
50 cargo for Junk. Other ship types retain their original capacities.

Cannons still use 10 cargo units each; commodities occupying the hold and
available gold can reduce how many cannons you can purchase. The maximum-
cannon button, five-tier shipyard catalog, automatic restocking, 100-ship
limit and doubled hull from the earlier patches are retained.
Indexed PNG transparency masks from the v5 correction are retained.

INSTALL
1. Close the game and back up the entire game folder and all save.tw* files.
2. Replace BOTH TW1_00.data and
   TradewindsClassic_100Ships_2xHull_ShipyardCatalog_TEST.exe with this package.
   Keep TW1_01.data and the original game DLLs in that same folder.
3. Launch the patched executable and reload your save.
4. Check Black Dragon remains in the fleet after entering/leaving/re-entering
   the shipyard. Check its info shows 450 cargo, then buy up to 45 cannons
   with sufficient gold and an empty hold. Check combat visibility, size,
   sail animation and damage frames. Check a Junk shows 50 cargo and fits five
   cannons; an ordinary Juggernaut should still show 350 cargo and fit 35.

SAVES AND ROLLBACK
Black Dragon uses the registered blackdragon_visual type in new saves.
Keep this matching data file when loading saves made with v6. To roll back
to v5 or the original game, restore that version's EXE/data and a save from
before installing v6. Renaming an already upgraded Black Dragon retains its
capacity and artwork. This package does not directly edit save files.
If your Black Dragon is missing after loading, try a save from before the
v4 disappearance. No ship is recreated automatically.

VALIDATION
88 x86 emulation, archive, layout and graphics checks passed. This includes
native fleet regrouping after repeated capacity initialization, Black Dragon
45-cannon purchases, ordinary Juggernaut 35-cannon purchases, Junk five-cannon
purchases, cargo/gold constraints and enlarged sprite rectangles/anchors.
Windows engine calls are stubbed; full Windows gameplay, rendering and
save/reload still need in-game verification. This remains a TEST release.

SOURCE
source/ includes assembly, builder, tests, artwork and pinned Python
requirements. Requires Python 3 and GNU binutils (as/ld/objcopy/nm).
Install source/requirements-dev.txt, then run:
python source/build_patch.py ORIGINAL_EXE ORIGINAL_TW1_00.data --output output
python source/test_patch.py --output output --original-data ORIGINAL_TW1_00.data
The input EXE must be the uploaded 100Ships_2xHull_TEST build, not an earlier
patched EXE. Original uploads have not been changed.
