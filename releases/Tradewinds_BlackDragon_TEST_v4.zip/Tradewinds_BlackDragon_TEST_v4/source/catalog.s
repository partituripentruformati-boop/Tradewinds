.intel_syntax noprefix
.section .text
.global make_offer, dispatch, restock
# Same thiscall signature as the original random offer factory.
make_offer:
 push esi
 mov esi,ecx
 push 0
 push 1
 sub esp,12
 mov DWORD PTR [esp+8],0x3f800000
 mov ecx,esp
 push DWORD PTR [selected]
 mov eax,0x42d0e0
 call eax
 mov ecx,esi
 mov eax,0x424480
 call eax
 test eax,eax
 jz make_done
 mov BYTE PTR [eax+0x31],0
make_done:
 pop esi
 ret

# Enter with the original dispatch frame intact, ESI = Shipyards.
dispatch:
 push OFFSET FLAT:action_junk
 lea ecx,[esp+0x24]
 mov eax,0x42d390
 call eax
 test al,al
 jnz choose_junk
 push OFFSET FLAT:action_onemast
 lea ecx,[esp+0x24]
 mov eax,0x42d390
 call eax
 test al,al
 jnz choose_onemast
 push OFFSET FLAT:action_twomast
 lea ecx,[esp+0x24]
 mov eax,0x42d390
 call eax
 test al,al
 jnz choose_twomast
 push OFFSET FLAT:action_brigantine
 lea ecx,[esp+0x24]
 mov eax,0x42d390
 call eax
 test al,al
 jnz choose_brigantine
 push OFFSET FLAT:action_megaship
 lea ecx,[esp+0x24]
 mov eax,0x42d390
 call eax
 test al,al
 jnz choose_megaship
 push OFFSET FLAT:action_max_cannons
 lea ecx,[esp+0x24]
 mov eax,0x42d390
 call eax
 test al,al
 jz original_dispatch
 mov ecx,esi
 call buy_max_cannons
 jmp dispatch_done
original_dispatch:
 # Replay overwritten push and resume original dispatcher.
 push 0x456288
 mov eax,0x42754a
 jmp eax
choose_junk:
 mov eax,OFFSET FLAT:type_junk
 jmp choose
choose_onemast:
 mov eax,OFFSET FLAT:type_onemast
 jmp choose
choose_twomast:
 mov eax,OFFSET FLAT:type_twomast
 jmp choose
choose_brigantine:
 mov eax,OFFSET FLAT:type_brigantine
 jmp choose
choose_megaship:
 mov eax,OFFSET FLAT:type_megaship
choose:
 mov DWORD PTR [selected],eax
 mov ecx,DWORD PTR ds:0x465dac
 mov eax,0x4232f0
 call eax
 cmp DWORD PTR [eax],100
 jge dispatch_done
 # Only the unpurchased offer belongs to Shipyards.
 mov edi,DWORD PTR [esi+0x10]
 test edi,edi
 jz new_offer
 lea ecx,[edi+4]
 mov eax,0x42d1a0
 call eax
 push edi
 mov eax,0x4373ff
 call eax
 add esp,4
new_offer:
 mov ecx,DWORD PTR ds:0x465dac
 call make_offer
 mov DWORD PTR [esi+0x10],eax
 mov BYTE PTR [esi+0x7c],1
 mov ecx,esi
 mov eax,0x427240
 call eax
 dispatch_done:
 mov eax,0x4277a3
 jmp eax

# Enter in place of the post-purchase notification call. Its arguments
# remain on the original stack for the original callee to consume.
restock:
 mov eax,0x4137b0
 call eax
 mov DWORD PTR [esi+0x10],0
 mov ecx,DWORD PTR ds:0x465dac
 mov eax,0x4232f0
 call eax
 cmp DWORD PTR [eax],100
 jge restock_done
 mov ecx,DWORD PTR ds:0x465dac
 call make_offer
 mov DWORD PTR [esi+0x10],eax
 mov BYTE PTR [esi+0x7c],1
restock_done:
 mov eax,0x425739
 jmp eax
# Register each XML command with the game's native command router.
# The first version handled these commands but omitted this registration.
register_catalog:
 mov DWORD PTR [esi+0x2c],eax
 push esi
 sub esp,8
 mov ecx,esp
 push OFFSET FLAT:action_junk
 mov eax,0x42d0e0
 call eax
 mov ecx,DWORD PTR ds:0x465d68
 mov eax,0x412a00
 call eax
 push esi
 sub esp,8
 mov ecx,esp
 push OFFSET FLAT:action_onemast
 mov eax,0x42d0e0
 call eax
 mov ecx,DWORD PTR ds:0x465d68
 mov eax,0x412a00
 call eax
 push esi
 sub esp,8
 mov ecx,esp
 push OFFSET FLAT:action_twomast
 mov eax,0x42d0e0
 call eax
 mov ecx,DWORD PTR ds:0x465d68
 mov eax,0x412a00
 call eax
 push esi
 sub esp,8
 mov ecx,esp
 push OFFSET FLAT:action_brigantine
 mov eax,0x42d0e0
 call eax
 mov ecx,DWORD PTR ds:0x465d68
 mov eax,0x412a00
 call eax
 push esi
 sub esp,8
 mov ecx,esp
 push OFFSET FLAT:action_megaship
 mov eax,0x42d0e0
 call eax
 mov ecx,DWORD PTR ds:0x465d68
 mov eax,0x412a00
 call eax
 push esi
 sub esp,8
 mov ecx,esp
 push OFFSET FLAT:action_max_cannons
 mov eax,0x42d0e0
 call eax
 mov ecx,DWORD PTR ds:0x465d68
 mov eax,0x412a00
 call eax
 pop edi
 mov BYTE PTR [esi+9],bl
 mov eax,0x4251df
 jmp eax
# Reuse the native single-cannon purchase, including its UI refresh and
# model recalculation. A cannon consumes 10 cargo units, as in 0x425af7.
buy_max_cannons:
 push esi
 push edi
 push ebx
 mov esi,ecx
max_cannon_loop:
 mov eax,DWORD PTR [esi+0x0c]
 test eax,eax
 jz max_cannon_done
 mov edi,DWORD PTR [eax]
 test edi,edi
 jz max_cannon_done
 cmp BYTE PTR [edi+0x31],0
 je max_cannon_done
 mov eax,DWORD PTR [edi]
 mov eax,DWORD PTR [eax+0x18]
 mov ebx,DWORD PTR [edi+0x14]
 imul edx,ebx,10
 sub eax,edx
 sub eax,DWORD PTR [edi+0x18]
 sub eax,DWORD PTR [edi+0x1c]
 sub eax,DWORD PTR [edi+0x20]
 sub eax,DWORD PTR [edi+0x24]
 cmp eax,10
 jl max_cannon_done
 mov edx,DWORD PTR [esi+0x24]
 test edx,edx
 jle max_cannon_done
 mov eax,DWORD PTR ds:0x465d74
 cmp DWORD PTR [eax+0x14],0
 jl max_cannon_done
 jg max_cannon_purchase
 cmp DWORD PTR [eax+0x10],edx
 jb max_cannon_done
max_cannon_purchase:
 mov ecx,esi
 mov eax,0x4260c0
 call eax
 cmp DWORD PTR [edi+0x14],ebx
 jle max_cannon_done
 jmp max_cannon_loop
max_cannon_done:
 pop ebx
 pop edi
 pop esi
 ret
.balign 4
selected: .long type_junk
type_junk: .asciz "junk"
type_onemast: .asciz "onemast"
type_twomast: .asciz "twomast"
type_brigantine: .asciz "brigantine"
type_megaship: .asciz "megaship"
action_junk: .asciz "yard_junk"
action_onemast: .asciz "yard_onemast"
action_twomast: .asciz "yard_twomast"
action_brigantine: .asciz "yard_brigantine"
action_megaship: .asciz "yard_megaship"

action_max_cannons: .asciz "buy_max_cannons"

# Visual-only per-ship variant. Keep original type name and all game stats,
# so saves still identify this ship as megaship. No manager-owned type changes.
dragon_value:
 push esi
 mov esi,DWORD PTR [esp+8]
 mov eax,esi
 call dragon_apply
 mov eax,0x423095
 jmp eax
dragon_info:
 mov eax,DWORD PTR [esi]
 call dragon_apply
 mov eax,DWORD PTR [esi]
 mov DWORD PTR [esi+0x1c],ebx
 push 0x424c22
 ret
dragon_apply:
 pushfd
 pushad
 mov ebx,eax
 test ebx,ebx
 jz dragon_done
 mov edi,DWORD PTR [ebx]
 test edi,edi
 jz dragon_done
 cmp edi,OFFSET FLAT:dragon_shadow
 je dragon_done
 lea ecx,[ebx+4]
 push OFFSET FLAT:dragon_name
 mov eax,0x42d390
 call eax
 test al,al
 jz dragon_done
 mov ecx,edi
 push OFFSET FLAT:type_megaship
 mov eax,0x42d390
 call eax
 test al,al
 jz dragon_done
 sub esp,8
 mov ecx,esp
 push OFFSET FLAT:dragon_template
 mov eax,0x42d0e0
 call eax
 mov ecx,DWORD PTR ds:0x465dac
 mov eax,0x423210
 call eax
 test eax,eax
 jz dragon_done
 mov edx,eax
 mov esi,edi
 mov edi,OFFSET FLAT:dragon_shadow
 mov ecx,32
 cld
 rep movsd
 lea esi,[edx+0x30]
 mov edi,OFFSET FLAT:dragon_shadow+0x30
 mov ecx,13
 rep movsd
 mov DWORD PTR [ebx],OFFSET FLAT:dragon_shadow
dragon_done:
 popad
 popfd
 ret
dragon_name: .asciz "Black Dragon"
dragon_template: .asciz "blackdragon_visual"
.balign 4
dragon_shadow: .space 128
