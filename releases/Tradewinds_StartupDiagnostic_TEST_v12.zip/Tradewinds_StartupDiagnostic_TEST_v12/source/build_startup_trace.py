"""Add diagnostic UI/crash logging without modifying v11 resources or gameplay."""
from pathlib import Path
import argparse,hashlib,json,shutil,struct,subprocess,tempfile
import pefile
from fix_pe_layout import validate
p=argparse.ArgumentParser();p.add_argument('--base',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
shutil.copytree(a.base,a.output,dirs_exist_ok=True)
exe=a.output/'TradewindsClassic_100Ships_2xHull_ShipyardCatalog_TEST.exe';b=bytearray(exe.read_bytes());pe=pefile.PE(data=b);s=pe.sections[-1];base=(0x400000+s.VirtualAddress+s.Misc_VirtualSize+15)&~15
root=Path(__file__).resolve().parent
with tempfile.TemporaryDirectory() as td:
 d=Path(td)
 subprocess.run(['gcc','-m32','-Os','-ffreestanding','-fno-pic','-fno-pie','-fno-stack-protector','-fno-asynchronous-unwind-tables','-Wall','-Wextra','-Werror','-c',str(root/'startup_trace.c'),'-o',str(d/'c.o')],check=True)
 subprocess.run(['as','--32',str(root/'startup_trace.s'),'-o',str(d/'s.o')],check=True)
 (d/'link.ld').write_text('SECTIONS { . = '+hex(base)+'; .trace : { *(.text*) *(.rodata*) *(.data*) *(.bss*) } /DISCARD/ : { *(.comment) *(.note*) *(.eh_frame*) } }')
 subprocess.run(['ld','-m','elf_i386','-T',str(d/'link.ld'),'-o',str(d/'trace.elf'),str(d/'s.o'),str(d/'c.o')],check=True)
 subprocess.run(['objcopy','-O','binary','--only-section=.trace',str(d/'trace.elf'),str(d/'trace.bin')],check=True)
 code=(d/'trace.bin').read_bytes();symbols={l.split()[2]:int(l.split()[0],16) for l in subprocess.check_output(['nm','-n',str(d/'trace.elf')],text=True).splitlines()}
assert base+len(code)<=0x400000+s.VirtualAddress+s.SizeOfRawData
pos=pe.get_offset_from_rva(base-0x400000);assert b[pos:pos+len(code)]==bytes(len(code));b[pos:pos+len(code)]=code
at=pe.get_offset_from_rva(0x1c40);assert b[at:at+6]==bytes.fromhex('558bec83e4f8');b[at:at+6]=b'\xe9'+struct.pack('<i',symbols['startup_trace_hook']-0x401c45)+b'\x90'
struct.pack_into('<I',b,s.get_field_absolute_offset('Misc_VirtualSize'),base+len(code)-0x400000-s.VirtualAddress)
p=pefile.PE(data=b);struct.pack_into('<I',b,p.OPTIONAL_HEADER.get_field_absolute_offset('CheckSum'),p.generate_checksum());validate(bytes(b));exe.write_bytes(b)
assert (a.output/'TW1_00.data').read_bytes()==(a.base/'TW1_00.data').read_bytes()
(a.output/'startup-trace-manifest.json').write_text(json.dumps(dict(version='v12 diagnostic',symbols=symbols,bytes=len(code),resource_data_unchanged=True,exe_sha256=hashlib.sha256(b).hexdigest()),indent=2)+'\n')
print('Diagnostic built:',len(code),'bytes',a.output)
