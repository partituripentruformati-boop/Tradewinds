"""Rebuild the two-commodity patch with v21.1 selection fix retained."""
from pathlib import Path
import argparse,subprocess,sys,tempfile
p=argparse.ArgumentParser();p.add_argument('--base-v7',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args();root=Path(__file__).resolve().parent
with tempfile.TemporaryDirectory()as td:
 folders=[Path(td)/str(i)for i in range(4)]
 tasks=[('build_fairwind_patch.py',['--base-v7',a.base_v7,'--output',folders[0]]),('build_market_layout.py',['--base',folders[0],'--output',folders[1]]),('add_tea_trade_row.py',['--output',folders[1]]),('remove_tea_shortcuts.py',['--base',folders[1],'--output',folders[2]]),('add_tea_alehouse_tip.py',['--base',folders[2],'--output',folders[3]]),('update_warehouse_layout.py',['--output',folders[3],'--icon-source',root/'regional-goods-assets/generated_tea_source.png']),('add_spices_layout.py',['--output',folders[3]]),('build_startup_trace.py',['--base',folders[3],'--output',a.output])]
 for script,args in tasks:subprocess.run([sys.executable,str(root/script),*map(str,args)],check=True)
