import unittest,xml.etree.ElementTree as E
from PIL import Image
from io import BytesIO
from test_tea_trade_row import TradeMachine
from test_regional_runtime import OUT,SYMS
from fix_xml_format import entries,decode
from unicorn.x86_const import UC_X86_REG_ESP
class WareMachine(TradeMachine):
 def __init__(self):self.transfers=[];super().__init__()
 def hook(self,u,a,n,user):
  if a in [0x42a780,0x42ab60]:self.transfers.append(a);self.ret()
  else:super().hook(u,a,n,user)
 def ware_input(self,n):
  self.lower('trade_inc','rw0+');self.texts[self.controls[(self.windows['warehouse'],'rga0')]]=str(n)
 def ware_qty(self):return self.texts[self.controls[(self.windows['warehouse'],'rga0')]]
class WarehouseTeaTests(unittest.TestCase):
 def test_selected_tea_transfer_both_directions_and_native_calls(self):
  m=WareMachine();m.input(10);m.action('rg0b');m.w(m.q(m.ships[0]),10);m.w(m.q(m.ships[1]),0);w=m.ports[0]+0x80
  m.w(0x200428,0);m.ware_input(6);m.lower('trade_inc','rw0t');self.assertEqual(m.r(m.q(w)),6);self.assertEqual(sum(m.r(m.q(s))for s in m.ships),4);self.assertEqual(m.ware_qty(),'0');self.assertEqual(m.transfers,[0x42ab60])
  m.u.mem_write(0x200428,b'\1');m.lower('trade_inc','rw0M');self.assertEqual(m.ware_qty(),'6');m.lower('trade_inc','rw0t');self.assertEqual(m.r(m.q(w)),0);self.assertEqual(sum(m.r(m.q(s))for s in m.ships),10);self.assertEqual(m.transfers[-1],0x42a780)
 def test_max_and_store_respect_warehouse_capacity(self):
  m=WareMachine();w=m.ports[0]+0x80;m.w(w,14999);m.w(m.q(m.ships[0]),10);m.ware_input(0);m.lower('trade_inc','rw0M');self.assertEqual(m.ware_qty(),'1');m.ware_input(10);m.lower('trade_inc','rw0t');self.assertEqual(m.r(m.q(w)),1);self.assertEqual(sum(m.r(m.q(s))for s in m.ships),9)
 def test_plus_minus_and_value_column(self):
  m=WareMachine();m.ware_input(0);m.lower('trade_inc','rw0-');self.assertEqual(m.ware_qty(),'0');m.lower('trade_inc','rw0+');self.assertEqual(m.ware_qty(),'1');m.call('rg_ui_refresh');self.assertEqual(m.texts[m.controls[(m.windows['warehouse'],'rgv0')]],str(m.r(SYMS['rg_prices'])))
 def test_ui_order_bounds_and_indexed_icon(self):
  assets=dict(entries((OUT/'TW1_00.data').read_bytes()));u=E.fromstring(decode(assets['assets/xml/int_buildings.txt']));w=u.find('warehouse');c=w.find('children')
  self.assertEqual([int(c.findtext(t+'/y'))for t in ['prod1','rgn0','prod2','prod3','prod4']],[70,94,142,166,190]);self.assertEqual([int(c.findtext(t+'/y'))for t in ['prodb1','rwname0','prodb2','prodb3','prodb4']],[240,264,312,336,360]);self.assertEqual(c.findtext('rgw0/x'),c.findtext('qty1/x'));self.assertEqual(c.findtext('rgv0/x'),c.findtext('value1/x'));self.assertLessEqual(int(w.findtext('y'))+int(w.findtext('height')),485);self.assertIsNone(c.find('rgl0'));self.assertIsNone(c.find('rgd0'))
  im=Image.open(BytesIO(assets['assets/graphics/ui/popup/icon_tea.png']));self.assertEqual(im.size,(24,24));self.assertEqual(im.mode,'P');self.assertEqual(im.info.get('transparency'),0);self.assertEqual(im.getpixel((0,0)),0)
if __name__=='__main__':unittest.main(argv=[__file__],verbosity=2)
