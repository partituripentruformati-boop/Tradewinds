.intel_syntax noprefix
.section .text
.global fairwind_visual_type
# EAX ship; return manager-owned variant, preserving registers and flags.
# Old Black Dragon selector remains the fallback for all other ships.
fairwind_visual_type:
 pushfd
 pushad
 mov ebx,eax
 mov edi,[ebx]
 mov [esp+28],edi
 lea ecx,[ebx+4]
 push OFFSET FLAT:fairwind_name
 mov eax,0x42d390
 call eax
 test al,al
 jz fallback
 mov ecx,edi
 push OFFSET FLAT:fairwind_type
 mov eax,0x42d390
 call eax
 test al,al
 jz fallback
 sub esp,8
 mov ecx,esp
 push OFFSET FLAT:fairwind_template
 mov eax,0x42d0e0
 call eax
 mov ecx,dword ptr ds:0x465dac
 mov eax,DRAGON_LOOKUP
 call eax
 test eax,eax
 jz finish
 cmp dword ptr [eax+0x30],0
 je finish
 cmp dword ptr [eax+0x34],0
 je finish
 cmp dword ptr [eax+0x38],0
 je finish
 cmp dword ptr [eax+0x3c],0
 je finish
 cmp dword ptr [eax+0x40],0
 je finish
 # Preserve damage proportion exactly once when upgrading an old save.
 shl dword ptr [ebx+0x10],1
 mov [ebx],eax
 mov [esp+28],eax
 jmp finish
fallback:
 mov eax,ebx
 mov ecx,DRAGON_SELECTOR
 call ecx
 mov [esp+28],eax
finish:
 popad
 popfd
 ret
fairwind_name: .asciz "Fair Wind"
fairwind_type: .asciz "onemast"
fairwind_template: .asciz "fairwind_visual"
.section .note.GNU-stack,"",@progbits
