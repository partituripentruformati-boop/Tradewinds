import unittest
from test_cash_display import CashMachine
from test_regional_runtime import MARKET,PORTS,SYMS
from unicorn.x86_const import UC_X86_REG_ESP
class LogMachine(CashMachine):
 def __init__(self):
  super().__init__();self.logs=[];self.w(0x465d70,0x239000)
 def hook(self,u,a,n,user):
  if a==0x4137b0:
   sp=u.reg_read(UC_X86_REG_ESP);self.logs.append(self.cstr(self.r(sp+8)));assert self.r(sp+12)==0;self.ret(12)
  else:super().hook(u,a,n,user)
class TradeLogTests(unittest.TestCase):
 def test_both_goods_buy_sell_fleet_warehouse(self):
  for i,name in enumerate(['Tea','Spices']):
   for ware in [False,True]:
    m=LogMachine();m.w(PORTS+0x1c,m.ports[i]);m.u.mem_write(MARKET+0x99,bytes([ware,1]));m.setinput(i,7);m.lower('trade');price=m.r(SYMS['rg_prices']+i*4);self.assertEqual(m.logs,[f'Bought 7 crates of {name} for {7*price:,} gold.']);m.u.mem_write(MARKET+0x9a,b'\0\1');m.setinput(i,3);m.lower('trade');self.assertEqual(m.logs[-1],f'Sold 3 crates of {name} for {3*price:,} gold.')
 def test_actual_affordable_quantity(self):
  m=LogMachine();m.call('rg_prices_refresh');price=m.r(SYMS['rg_prices']);m.setgold(price*2);m.u.mem_write(MARKET+0x9a,b'\1');m.setinput(0,7);m.lower('trade');self.assertEqual(m.logs,[f'Bought 2 crates of Tea for {2*price:,} gold.'])
 def test_sell_all_each_good(self):
  m=LogMachine();m.w(m.q(m.ships[0]),5);m.w(m.q(m.ships[0])+4,7);m.lower('sell_all');self.assertEqual(len(m.logs),2);self.assertTrue(m.logs[0].startswith('Sold 5 crates of Tea'));self.assertTrue(m.logs[1].startswith('Sold 7 crates of Spices'))
 def test_large_total_uses_64_bits(self):
  m=LogMachine();m.u.mem_write(MARKET+0x99,b'\1\0\1');m.w(m.q(m.ports[0]+0x80),10000000);m.call('rg_prices_refresh');m.w(SYMS['rg_prices'],1000);m.lower('sell_all');self.assertEqual(m.logs[0],'Sold 10000000 crates of Tea for 10,000,000,000 gold.')
 def test_no_trade_no_message(self):
  m=LogMachine();m.w(PORTS+0x1c,m.ports[2]);m.u.mem_write(MARKET+0x9a,b'\1');m.setinput(0,7);m.lower('trade');m.lower('sell_all');self.assertEqual(m.logs,[])
if __name__=='__main__':unittest.main(argv=[__file__],verbosity=2)
