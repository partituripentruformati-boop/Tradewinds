"""Build an experimental candidate on top of the verified v7 package."""
from pathlib import Path
import argparse
import hashlib
import json
import struct
import subprocess
import tempfile
import xml.etree.ElementTree as ET

import pefile
from capstone import Cs, CS_ARCH_X86, CS_MODE_32

ROOT = Path(__file__).resolve().parent
parser = argparse.ArgumentParser()
parser.add_argument('--base', type=Path, required=True)
parser.add_argument('--output', type=Path, required=True)
args = parser.parse_args()
args.output.mkdir(parents=True, exist_ok=True)
exe = args.base/'TradewindsClassic_100Ships_2xHull_ShipyardCatalog_TEST.exe'
original = exe.read_bytes()
manifest = json.loads((args.base/'patch-manifest.json').read_text())
assert hashlib.sha256(original).hexdigest() == 'ef7f32a0b45c04ebf5433fcc643c1e970a47dcddebb7492b3409798bb995e404', 'Requires the exact v7 executable'
pe = pefile.PE(data=original)
with tempfile.TemporaryDirectory(prefix='tradewinds-regional-build-') as temporary:
    build = Path(temporary)
    for source in ['regional_goods.s', 'regional_hooks.s']:
        subprocess.run(['as', '--32', str(ROOT/source), '-o', str(build/(source+'.o'))], check=True)
    subprocess.run(['gcc', '-m32', '-Os', '-ffreestanding', '-fno-pic', '-fno-pie',
                    '-fno-stack-protector', '-fno-asynchronous-unwind-tables', '-Wall', '-Wextra',
                    '-Werror', '-c', str(ROOT/'regional_runtime.c'), '-o', str(build/'runtime.o')], check=True)
    (build/'link.ld').write_text('SECTIONS { . = 0x480000; .goods : { *(.text*) *(.rodata*) *(.data*) *(.bss*) *(COMMON) } /DISCARD/ : { *(.comment) *(.note*) *(.eh_frame*) } }')
    subprocess.run(['ld', '-m', 'elf_i386', '-T', str(build/'link.ld'), '-o', str(build/'goods.elf'),
                    str(build/'regional_goods.s.o'), str(build/'regional_hooks.s.o'),
                    str(build/'runtime.o')], check=True)
    subprocess.run(['objcopy', '-O', 'binary', '--only-section=.goods', str(build/'goods.elf'),
                    str(build/'goods.bin')], check=True)
    code = (build/'goods.bin').read_bytes()
    symbols = {line.split()[2]: int(line.split()[0], 16) for line in subprocess.check_output(
        ['nm', '-n', str(build/'goods.elf')], text=True).splitlines()}
    subprocess.run(['objdump', '-d', '-Mintel', str(build/'goods.elf')], check=True,
                    stdout=(args.output/'regional-disassembly.txt').open('w'))

b = bytearray(original)
changes = []
def hook(address, length, name):
    offset = pe.get_offset_from_rva(address-0x400000)
    before = original[offset:offset+length]
    assert sum(i.size for i in Cs(CS_ARCH_X86,CS_MODE_32).disasm(before,address)) == length, (hex(address),'split instruction')
    after = b'\xe9'+struct.pack('<i', symbols[name]-address-5)+b'\x90'*(length-5)
    b[offset:offset+length] = after
    changes.append(dict(address=hex(address), before=before.hex(), after=after.hex(), symbol=name))

for address, length, name in [
    (0x420970,8,'rg_save_begin_hook'), (0x420810,5,'rg_load_begin_hook'),
    (0x420a21,6,'rg_save_end_hook'), (0x420963,8,'rg_load_end_hook'),
    (0x422f47,8,'rg_collect_save_hook'), (0x42432e,6,'rg_collect_load_hook'),
    (0x423da0,8,'rg_release_hook'), (0x423db0,7,'rg_reset_hook'),
    (0x423100,5,'rg_speed_hook'), (0x4236eb,5,'rg_fleet_free_hook'),
    (0x418048,20,'rg_market_free_hook'), (0x42a3b7,32,'rg_warehouse_free_hook'),
    (0x417e33,12,'rg_price_hook'), (0x418185,11,'rg_market_refresh_hook'),
    (0x42a550,12,'rg_warehouse_refresh_hook'), 
    (0x418a19,5,'rg_dispatch_hook'),
    (0x423989,6,'rg_buy_free_hook'),(0x42390f,6,'rg_dust_free_hook'),
    (0x423a8d,6,'rg_move_free_hook'),(0x425b1f,8,'rg_cannon_free_hook'),
    (0x423a20,7,'rg_redistribute_hook'),(0x42a0df,6,'rg_theft_empty_hook'),
    (0x42a158,6,'rg_theft_target_hook'),
    (0x418165,8,'rg_market_percent_hook'),(0x42a4ab,6,'rg_warehouse_percent_hook'),
    (manifest['symbols']['buy_max_cannons'],5,'rg_max_cannons')]:
    hook(address,length,name)
for address in [0x4241e9,0x424379,0x4244e9]:
    offset=pe.get_offset_from_rva(address-0x400000)
    assert original[offset]==0xe8
    assert address+5+struct.unpack_from('<i',original,offset+1)[0]==0x4240d0
    b[offset:offset+5]=b'\xe8'+struct.pack('<i',symbols['rg_allocate_hook']-address-5)

# Windows PE image sections must be adjacent in virtual memory. Reserve
# zero-filled padding in .yard up to .goods, preserving all absolute addresses.
struct.pack_into('<I',b,pe.sections[-1].get_field_absolute_offset('Misc_VirtualSize'),0x80000-pe.sections[-1].VirtualAddress)
header=pe.sections[-1].get_file_offset()+40
assert b[header:header+40]==bytes(40)
size=(len(code)+4095)//4096*4096
assert len(b)%4096==0
b[header:header+40]=struct.pack('<8sIIIIIIHHI',b'.goods\0\0',len(code),0x80000,size,len(b),0,0,0,0,0xe0000060)
struct.pack_into('<H',b,pe.FILE_HEADER.get_field_absolute_offset('NumberOfSections'),len(pe.sections)+1)
struct.pack_into('<I',b,pe.OPTIONAL_HEADER.get_field_absolute_offset('SizeOfImage'),0x80000+size)
struct.pack_into('<I',b,pe.OPTIONAL_HEADER.get_field_absolute_offset('SizeOfCode'),pe.OPTIONAL_HEADER.SizeOfCode+size)
b.extend(code+bytes(size-len(code)))
new_pe=pefile.PE(data=bytes(b))
struct.pack_into('<I',b,new_pe.OPTIONAL_HEADER.get_field_absolute_offset('CheckSum'),new_pe.generate_checksum())
from fix_pe_layout import validate
validate(bytes(b))
(args.output/exe.name).write_bytes(b)

data=(args.base/'TW1_00.data').read_bytes()
assert hashlib.sha256(data).hexdigest()=='9038728242cb46a674dac1b0aacd1a8d5557613feeef5e53e422b32eed0e3884', 'Requires matching v7 data'
pos=8;entries=[]
for _ in range(struct.unpack_from('<I',data,4)[0]):
    end=data.index(0,pos);name=data[pos:end].decode();off,n=struct.unpack_from('<II',data,end+1);pos=end+9
    entries.append((name,data[off:off+n]))
key=b'klxd8794lkds87934poi'
def decode(p):return bytes((v-key[i%len(key)])%256 for i,v in enumerate(p))
def encode(p):return bytes((v+key[i%len(key)])%256 for i,v in enumerate(p))
ui=ET.fromstring(decode(dict(entries)['assets/xml/int_buildings.txt']))
def put(parent,name,extends,x,y,text=None,width=None,command=None):
    node=ET.SubElement(parent,name,{'_extends':'/controldefs/'+extends})
    for tag,value in [('x',x),('y',y),('text',text),('width',width),('onlclick',command)]:
        if value is not None:ET.SubElement(node,tag).text=str(value)
    if extends=='menutext':
        for tag in ['font','hifont','disabledfont']:ET.SubElement(node,tag).text='duvall_10'
    return node
items=json.loads((ROOT/'regional-goods-assets/manifest.json').read_text())['items'][:1]
market=ui.find('marketplace');market.find('width').text='600';market.find('height').text='184'
market.find('children/frame/width').text='600';market.find('children/frame/height').text='184'
for name in ['market_menu','trade_menu']:ui.find(name+'/y').text='240'
market.find('children/title_text/x').text='300'
for control,y in [('xfertext',30),('tofleet',50),('towarehouse',70),('spacetext',95),('spacepercent',115)]:
    market.find('children/'+control+'/y').text=str(y)
    market.find('children/'+control+'/x').text='450'
put(market.find('children'),'rgamountheader','smalltext',330,30,'Amount')
ware=ui.find('warehouse');ware.find('children/warehouseframe/height').text='190'
for i,item in enumerate(items):
    for window, y in [(market,145+i*29),(ware,166+i*20)]:
        children=window.find('children')
        icon=ET.SubElement(children,'rgicon'+str(i),{'_class':'UIBitmap'})
        ET.SubElement(icon,'x').text='10';ET.SubElement(icon,'y').text=str(y)
        ET.SubElement(icon,'bitmap',{'bitmap':item['icon_path']})
        put(children,'rgn'+str(i),'smalltext',34,y+4,item['label'])
        if window is market:
            put(children,'rgp'+str(i),'quantity',255,y+4,'0')
            put(children,'rgq'+str(i),'quantity',320,y+4,'0')
            put(children,'rga'+str(i),'enternumber',330,y,'1',55)
            put(children,'rgb'+str(i),'menutext',420,y,'Buy',50,'trade_inc(rg'+str(i)+'b)')
            put(children,'rgb'+str(i)+'m','menutext',462,y,'Max',32,'trade_inc(rg'+str(i)+'B)')
            put(children,'rgs'+str(i),'menutext',515,y,'Sell',50,'trade_inc(rg'+str(i)+'s)')
            put(children,'rgs'+str(i)+'m','menutext',557,y,'Max',32,'trade_inc(rg'+str(i)+'S)')
        else:
            put(children,'rgw'+str(i),'quantity',280,y+4,'0')
            put(children,'rgl'+str(i),'menutext',335,y,'Load all',65,'trade_inc(rg'+str(i)+'L)')
            put(children,'rgd'+str(i),'menutext',420,y,'Store all',65,'trade_inc(rg'+str(i)+'D)')
plain=ET.tostring(ui,encoding='ascii',xml_declaration=False)
entries=[(name,encode(plain) if name=='assets/xml/int_buildings.txt' else payload) for name,payload in entries]
for item in items:entries.append((item['icon_path'],(ROOT/'regional-goods-assets'/item['icon_file']).read_bytes()))
offset=8+sum(len(name.encode())+9 for name,_ in entries)
directory=bytearray(struct.pack('<II',0xdcac,len(entries)));payloads=bytearray()
for name,payload in entries:
    directory+=name.encode()+b'\0'+struct.pack('<II',offset,len(payload));payloads+=payload;offset+=len(payload)
(args.output/'TW1_00.data').write_bytes(directory+payloads)
(args.output/'regional-manifest.json').write_text(json.dumps(dict(
    status='experimental_candidate_validation_pending',base_sha256=hashlib.sha256(original).hexdigest(),
    symbols=symbols,hooks=changes,code_bytes=len(code)),indent=2)+'\n')
print('Experimental candidate built:',args.output,'module bytes:',len(code))
