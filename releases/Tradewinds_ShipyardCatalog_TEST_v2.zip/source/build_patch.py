from pathlib import Path
import sys, struct, subprocess, hashlib, json, argparse
sys.path.insert(0,str(Path(__file__).parent/'python-libs'))
import pefile
ROOT=Path(__file__).parent
parser=argparse.ArgumentParser(description='Build the Tradewinds shipyard catalog test patch from the original uploaded files.')
parser.add_argument('exe',type=Path)
parser.add_argument('data',type=Path)
parser.add_argument('--output',type=Path,default=ROOT.parent/'dist')
args=parser.parse_args()
EXE=args.exe;DATA=args.data;OUT=args.output;OUT.mkdir(parents=True,exist_ok=True)
original=EXE.read_bytes(); pe=pefile.PE(data=original)
assert hashlib.sha256(original).hexdigest()=='82a5f8d6bf132c827a5d0b574e247c3122860156fb278f4d8e22fff4cd0ebcf1', 'Wrong input executable; use the uploaded 100Ships_2xHull_TEST build.'
subprocess.run(['as','--32',str(ROOT/'catalog.s'),'-o',str(ROOT/'catalog.o')],check=True)
subprocess.run(['ld','-m','elf_i386','-Ttext','0x470000','--entry','make_offer',str(ROOT/'catalog.o'),'-o',str(ROOT/'catalog.elf')],check=True)
subprocess.run(['objcopy','-O','binary','--only-section=.text',str(ROOT/'catalog.elf'),str(ROOT/'catalog.bin')],check=True)
syms={line.split()[2]:int(line.split()[0],16) for line in subprocess.check_output(['nm','-n',str(ROOT/'catalog.elf')],text=True).splitlines()}
b=bytearray(original);changes=[]
def patch(va,expected,replacement,label):
 off=pe.get_offset_from_rva(va-0x400000)
 assert bytes(b[off:off+len(expected)])==expected,(hex(va),label)
 assert len(expected)==len(replacement)
 b[off:off+len(expected)]=replacement
 changes.append({'address':hex(va),'before':expected.hex(),'after':replacement.hex(),'purpose':label})
def branch(op,va,dest):return bytes([op])+struct.pack('<i',dest-va-5)
patch(0x427446,original[0x27446:0x27466],b'\x90'*32,'Remove random ship availability gate')
patch(0x42746c,bytes.fromhex('e84fd1ffff'),branch(0xe8,0x42746c,syms['make_offer']),'Generate selected catalog type')
patch(0x427474,original[0x27474:0x2749e],b'\x90'*42,'Remove random special offer flag')
patch(0x427545,bytes.fromhex('6888624500'),branch(0xe9,0x427545,syms['dispatch']),'Handle five catalog menu actions')
patch(0x425731,bytes.fromhex('e87ae0feff'),branch(0xe9,0x425731,syms['restock']),'Restock following completed purchase')
patch(0x425736,bytes.fromhex('895e10'),b'\x90'*3,'Replace consumed-offer clearing with restock hook')
patch(0x4251d8,bytes.fromhex('89462c5f885e09'),branch(0xe9,0x4251d8,syms['register_catalog'])+b'\x90'*2,'Register five catalog commands with native command router')
# New section: image is fixed-base, relocations stripped in original.
code=(ROOT/'catalog.bin').read_bytes(); assert len(code)<4096
hdr=pe.sections[-1].get_file_offset()+40
assert b[hdr:hdr+40]==bytes(40)
b[hdr:hdr+40]=struct.pack('<8sIIIIIIHHI',b'.yard\0\0\0',len(code),0x70000,4096,len(original),0,0,0,0,0xe0000060)
struct.pack_into('<H',b,pe.FILE_HEADER.get_field_absolute_offset('NumberOfSections'),5)
struct.pack_into('<I',b,pe.OPTIONAL_HEADER.get_field_absolute_offset('SizeOfImage'),0x71000)
struct.pack_into('<I',b,pe.OPTIONAL_HEADER.get_field_absolute_offset('SizeOfCode'),pe.OPTIONAL_HEADER.SizeOfCode+4096)
b.extend(code+bytes(4096-len(code)))
p=pefile.PE(data=bytes(b));struct.pack_into('<I',b,p.OPTIONAL_HEADER.get_field_absolute_offset('CheckSum'),p.generate_checksum())
(OUT/'TradewindsClassic_100Ships_2xHull_ShipyardCatalog_TEST.exe').write_bytes(b)
# Replace only the shipyard menu in the encoded asset archive.
key=original[0x57110:original.index(0,0x57110)]
data=DATA.read_bytes();pos=8;entries=[]
for _ in range(struct.unpack_from('<I',data,4)[0]):
 end=data.index(0,pos);name=data[pos:end].decode();off,n=struct.unpack_from('<II',data,end+1);pos=end+9
 entries.append((name,data[off:off+n]))
new=[]
for name,payload in entries:
 if name=='assets/xml/int_buildings.txt':
  text=bytes((v-key[i%len(key)])%256 for i,v in enumerate(payload)).decode('ascii')
  start=text.index('\t<shipyard_menu ');end=text.index('</shipyard_menu>',start)+len('</shipyard_menu>')
  # Preserve the native buyship control binding out of view; visible catalog
  # choices remain selectable independently of the current offer's price.
  menu='''\t<shipyard_menu _class="UIWindow">
\t\t<x>473</x><y>300</y><width>400</width><height>174</height>
\t\t<halign>center</halign><valign>top</valign>
\t\t<children>
\t\t\t<bottomframe _extends="/controldefs/popupframe"><x>0</x><y>0</y><width>400</width><height>174</height><halign>left</halign><valign>top</valign></bottomframe>
\t\t\t<buyship _extends="/controldefs/menutext"><text></text><x>1000</x><y>0</y><width>0</width><onlclick>buy_ship</onlclick></buyship>
\t\t\t<typeheader _extends="/controldefs/smalltext"><font>duvall_10_em</font><text>Ship type</text><x>18</x><y>8</y></typeheader>
\t\t\t<cargoheader _extends="/controldefs/smalltext"><font>duvall_10_em</font><text>Cargo</text><x>270</x><y>8</y><halign>right</halign></cargoheader>
\t\t\t<buyheader _extends="/controldefs/smalltext"><font>duvall_10_em</font><text>Purchase</text><x>340</x><y>8</y><halign>center</halign></buyheader>
'''
  import xml.etree.ElementTree as ET
  ship_entry=dict(new).get('assets/xml/ships.txt',dict(entries)['assets/xml/ships.txt'])
  ships=ET.fromstring(bytes((v-key[i%len(key)])%256 for i,v in enumerate(ship_entry)))
  for i,(tag,label) in enumerate([('junk','Junk'),('onemast','One-Masted Sloop'),('twomast','Two-Masted Sloop'),('brigantine','Brigantine'),('megaship','Juggernaut')]):
   y=26+i*23
   cargo=ships.findtext('types/'+tag+'/cargo')
   menu+=f'\t\t\t<label_{tag} _extends="/controldefs/basictext"><text>{label}</text><x>18</x><y>{y+3}</y></label_{tag}>\n'
   menu+=f'\t\t\t<cargo_{tag} _extends="/controldefs/basictext"><text>{cargo}</text><x>270</x><y>{y+3}</y><halign>right</halign></cargo_{tag}>\n'
   menu+=f'\t\t\t<catalog_{tag} _extends="/controldefs/menutext"><text>Buy</text><x>340</x><y>{y}</y><width>64</width><onlclick>yard_{tag}</onlclick></catalog_{tag}>\n'
  menu+='''\t\t\t<fixall _extends="/controldefs/menutext"><text>Repair all Ships</text><x>120</x><y>148</y><width>176</width><onlclick>repair_all</onlclick></fixall>
\t\t\t<ok _extends="/controldefs/menutext"><text>Leave</text><x>320</x><y>148</y><width>88</width><onlclick>endshipyards</onlclick></ok>
\t\t</children>
\t</shipyard_menu>'''
  menu=menu.replace('\n','\r\n');text=text[:start]+menu+text[end:];plain=text.encode('ascii')
  payload=bytes((v+key[i%len(key)])%256 for i,v in enumerate(plain))
 new.append((name,payload))
header_size=8+sum(len(n.encode())+1+8 for n,_ in new);offset=header_size
archive=bytearray(data[:8]);bodies=bytearray()
for name,payload in new:
 archive+=name.encode()+b'\0'+struct.pack('<II',offset,len(payload));bodies+=payload;offset+=len(payload)
archive+=bodies;(OUT/'TW1_00.data').write_bytes(archive)
report={'input_exe_sha256':hashlib.sha256(original).hexdigest(),'input_data_sha256':hashlib.sha256(data).hexdigest(),'output_exe_sha256':hashlib.sha256(b).hexdigest(),'output_data_sha256':hashlib.sha256(archive).hexdigest(),'patches':changes,'symbols':syms,'validation':'Emulation with engine calls stubbed; Windows gameplay not tested.'}
(OUT/'patch-manifest.json').write_text(json.dumps(report,indent=2)+'\n')
print('Built patched executable and asset archive:',OUT)
