.intel_syntax noprefix
.section .text
.global rg_save_begin_hook, rg_load_begin_hook, rg_save_end_hook, rg_load_end_hook
.global rg_collect_save_hook, rg_collect_load_hook, rg_allocate_hook, rg_release_hook
.global rg_reset_hook, rg_speed_hook, rg_fleet_free_hook, rg_market_free_hook
.global rg_warehouse_free_hook, rg_price_hook, rg_market_refresh_hook
.global rg_warehouse_refresh_hook, rg_register_hook, rg_dispatch_hook

rg_save_begin_hook:
 pushad
 call rg_io_begin
 popad
 mov eax,[ecx+8]
 push esi
 mov esi,[esp+8]
 push 0x420978
 ret
rg_load_begin_hook:
 pushad
 call rg_io_begin
 popad
 mov eax,[ecx+8]
 push ebx
 push esi
 push 0x420815
 ret
rg_save_end_hook:
 push esi
 call rg_save
 add esp,4
 pop esi
 ret 4
rg_load_end_hook:
 push edi
 call rg_load
 add esp,4
 pop edi
 pop esi
 pop ebx
 ret 4
rg_collect_save_hook:
 pushad
 push edi
 call rg_collect_ship
 add esp,4
 popad
 lea ebx,[edi+0x18]
 mov ebp,4
 push 0x422f4f
 ret
rg_collect_load_hook:
 pushad
 push esi
 call rg_collect_ship
 add esp,4
 popad
 mov eax,esi
 mov ecx,[esp+0x24]
 push 0x424334
 ret
rg_allocate_hook:
 mov eax,0x4240d0
 call eax
 pushad
 push eax
 call regional_clear
 add esp,4
 popad
 ret
rg_release_hook:
 pushad
 push dword ptr [esp+36]
 call regional_clear
 add esp,4
 popad
 mov eax,[esp+4]
 mov byte ptr [eax+0x35],0
 ret 4
rg_reset_hook:
 pushad
 call rg_reset
 popad
 push -1
 push 0x44f3d3
 push 0x423db7
 ret
rg_speed_hook:
 push dword ptr [esp+4]
 call rg_speed
 add esp,4
 ret 4
rg_fleet_free_hook:
 push eax
 call regional_ship_free
 add esp,4
 add esi,eax
 lea ecx,[esp+8]
 push 0x42370c
 ret
rg_market_free_hook:
 push ecx
 push ecx
 call regional_warehouse_free
 add esp,8
 push 0x41805c
 ret
rg_warehouse_free_hook:
 push ecx
 push ecx
 call regional_warehouse_free
 add esp,8
 mov [esi+0x30],eax
 lea ecx,[esp+0x34]
 push 0x42a3d7
 ret
rg_price_hook:
 pushad
 call rg_prices_refresh
 popad
 lea ecx,[esp+0x18]
 mov dword ptr [esp+0x30],-1
 push 0x417e3f
 ret
rg_market_refresh_hook:
 pushad
 call rg_ui_refresh
 popad
 mov ecx,[esp+0x30]
 mov fs:0,ecx
 push 0x418190
 ret
rg_warehouse_refresh_hook:
 pushad
 call rg_ui_refresh
 popad
 lea ecx,[esp+0x2c]
 mov dword ptr [esp+0x48],-1
 push 0x42a55c
 ret
rg_register_hook:
 pushad
 push esi
 call rg_register
 add esp,4
 popad
 mov ecx,[esp+0x38]
 mov fs:0,ecx
 push 0x417b62
 ret
rg_dispatch_hook:
 pushad
 mov eax,[esp+12]
 push dword ptr [eax+0x48]
 push dword ptr [eax+0x40]
 call rg_market_action
 add esp,8
 mov [esp+28],eax
 popad
 test eax,eax
 jnz .handled
 push 0x454eac
 push 0x418a1e
 ret
.handled:
 push 0x41905a
 ret
.section .note.GNU-stack,"",@progbits
.section .text
.global rg_buy_free_hook,rg_dust_free_hook,rg_move_free_hook,rg_cannon_free_hook
.global rg_redistribute_hook,rg_theft_empty_hook,rg_theft_target_hook
rg_buy_free_hook:
 pushad
 push eax
 call regional_ship_free
 add esp,4
 mov [esp+24],eax
 popad
 push 0x4239a4
 ret
rg_dust_free_hook:
 pushad
 mov edx,[eax+0x24]
 mov [esp+20],edx
 push eax
 call regional_ship_free
 add esp,4
 mov [esp+24],eax
 popad
 push 0x42392e
 ret
rg_move_free_hook:
 pushad
 push eax
 call regional_ship_free
 add esp,4
 mov [esp+24],eax
 popad
 mov ebx,3
 lea edx,[ebp+0x24]
 sub eax,ebp
 push 0x423ab4
 ret
rg_cannon_free_hook:
 pushad
 push ebx
 call regional_ship_free
 add esp,4
 mov [esp],eax
 popad
 mov eax,0x42d0e0
 call eax
 push 0x425b27
 ret
rg_redistribute_hook:
 pushad
 push dword ptr [esp+36]
 call rg_redistribute
 add esp,4
 popad
 push -1
 push 0x44f2f8
 push 0x423a27
 ret
rg_theft_empty_hook:
 pushad
 push dword ptr [edi+0x2c]
 call rg_extra_total
 add esp,4
 test eax,eax
 popad
 jnz .has_extra
 mov ecx,[edi+0x2c]
 cmp dword ptr [ecx],0
 push 0x42a0e5
 ret
.has_extra:
 push 0x42a11b
 ret
rg_theft_target_hook:
 pushad
 push dword ptr [edi+0x2c]
 call rg_theft_target
 add esp,4
 mov [esp+4],eax
 popad
 push 0x42a15e
 ret
.global rg_market_percent_hook,rg_warehouse_percent_hook
rg_market_percent_hook:
 pushad
 call rg_market_extra_total
 add [esp+16],eax
 cmp byte ptr [edi+0x99],0
 jnz .percent_ware
 mov edx,[esp+12]
 add [edx+0x14],eax
.percent_ware:
 popad
 mov [esp+0x18],ebx
 fild dword ptr [esp+0x18]
 push 0x41816d
 ret
rg_warehouse_percent_hook:
 pushad
 call rg_fleet_extra_total
 add [esp+16],eax
 popad
 mov ecx,dword ptr ds:0x465dac
 push 0x42a4b1
 ret
