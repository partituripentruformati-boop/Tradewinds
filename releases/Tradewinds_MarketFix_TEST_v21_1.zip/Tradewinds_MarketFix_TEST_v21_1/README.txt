Tradewinds v21.1 TEST — restore original commodity purchases

BUG
V21's Tea handler refreshed the market before the original four-item trade
handler ran. The native refresh at 41813D..418158 resets qty_edit1..4 to "0".
That discarded selected General Merchandise, Arms, Silk and Dream Dust
quantities, even when no Tea was selected. Cargo and warehouses stayed empty.
Earlier integration tests stubbed refresh without modeling this reset.

FIX
When Tea quantity is zero, the extra trade/refresh is skipped entirely.
For a mixed Tea/original trade, the original four quantity selections are read
before the Tea trade and restored after its refresh, so the native Buy/Sell
handler receives the requested quantities. Tea still trades first; original
buying is bounded by the remaining cash/space using the native rules.
No new command registrations are added.

All v21 features remain: Tea's Tanchon-only purchase rule, fluctuating prices,
alehouse hint, larger icon, clean markets/warehouses, warehouse Tea transfers,
all ship artwork/stat upgrades, shipyard catalog and warehouse capacity.
TW1_00.data is byte-identical to v21. Save format is unchanged.
Spices remains paused and is NOT included.

INSTALL AND TEST
Close the game. Back up saves and current patch files. Extract the ZIP and
replace BOTH the executable and TW1_00.data in the original game folder.
The data file is unchanged, but copying both prevents mismatched packages.
First buy a small quantity of General Merchandise into a warehouse and/or
fleet. Then test a mixed Tea/original purchase in Tanchon and normal selling.
If it fails, describe the selected quantities and destination and send the
startup log if it crashes. The new log begins "Tradewinds v21.1 market fix".

VALIDATION
The new selection regression reproduces three failures on the unmodified v21
EXE (native handler receives zeros) and passes all four checks on the fix:
original buying to fleet/warehouse across four port fixtures, mixed Tea/original
buying, mixed selling and Tea-only buying. The regression models the native
refresh reset; the original four-item execution handler is mocked.
94 existing regressions, 18 Tea integration tests, five lower-trade tests,
four warehouse tests and eight diagnostic checks also passed.
Clean source rebuild reproduces both package files exactly. Real Wine/QEMU
startup reached all 11 constructor entry markers with no logged crash, subject
to its existing graphics-mode limitation. Actual Windows trading needs user
confirmation.

REBUILD
source/build_warehouse_tea_patch.py --base-v7 <working v7 folder> --output <folder>
Requires Python, pefile, capstone, Pillow, gcc -m32 and binutils; tests use Unicorn.
