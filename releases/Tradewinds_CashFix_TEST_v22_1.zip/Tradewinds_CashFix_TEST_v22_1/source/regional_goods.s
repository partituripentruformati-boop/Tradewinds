# Experimental regional-goods core. Not linked into the released game yet.
# cdecl API; preserve EBX, ESI, EDI, EBP. Port names are native XML tags.
.intel_syntax noprefix
.section .text
.global regional_can_buy, regional_quote, regional_slot, regional_clear
.global regional_trade, regional_slots
.global regional_ship_free, regional_warehouse_free

# int regional_ship_free(ship*) -- includes guns and all seven goods.
# Native ship layout remains untouched, including its registered type pointer.
regional_ship_free:
 push esi
 push ebx
 mov esi, [esp+12]
 test esi, esi
 jz .ship_free_no
 mov eax, [esi]
 test eax, eax
 jz .ship_free_no
 mov ebx, [eax+0x18]
 imul eax, [esi+0x14], 10
 sub ebx, eax
 sub ebx, [esi+0x18]
 sub ebx, [esi+0x1c]
 sub ebx, [esi+0x20]
 sub ebx, [esi+0x24]
 push 0
 push esi
 call regional_slot
 add esp, 8
 test eax, eax
 jz .ship_free_done
 sub ebx, [eax]
 sub ebx, [eax+4]
 sub ebx, [eax+8]
.ship_free_done:
 mov eax, ebx
 jmp .ship_free_exit
.ship_free_no:
 xor eax, eax
.ship_free_exit:
 pop ebx
 pop esi
 ret

# int regional_warehouse_free(owner*, native_four_qty*)
regional_warehouse_free:
 push ebx
 mov eax, [esp+12]
 test eax, eax
 jz .warehouse_no
 mov ebx, 15000
 sub ebx, [eax]
 sub ebx, [eax+4]
 sub ebx, [eax+8]
 sub ebx, [eax+12]
 push 0
 push dword ptr [esp+12]
 call regional_slot
 add esp, 8
 test eax, eax
 jz .warehouse_done
 sub ebx, [eax]
 sub ebx, [eax+4]
 sub ebx, [eax+8]
.warehouse_done:
 mov eax, ebx
 pop ebx
 ret
.warehouse_no:
 xor eax, eax
 pop ebx
 ret

# bool regional_can_buy(unsigned item, const char *port_tag)
regional_can_buy:
 push esi
 push edi
 mov eax, [esp+12]
 cmp eax, 2
 ja .buy_no
 mov esi, [esp+16]
 test esi, esi
 jz .buy_no
 mov edi, [regional_ports+eax*4]
.port_next:
 mov al, [esi]
 cmp al, [edi]
 jne .buy_no
 inc esi
 inc edi
 test al, al
 jnz .port_next
 mov eax, 1
 jmp .buy_exit
.buy_no:
 xor eax, eax
.buy_exit:
 pop edi
 pop esi
 ret

# unsigned regional_quote(item, native_rand_roll, source_port)
# Source 75..125% of base; other ports 75..175%. Same quote for buy/sell.
# Runtime integration must call once per native market refresh, NOT per click.
regional_quote:
 mov ecx, [esp+4]
 cmp ecx, 2
 ja .quote_no
 mov eax, [esp+8]
 and eax, 0x7fff
 xor edx, edx
 cmp dword ptr [esp+12], 0
 mov ecx, 101
 je .quote_mod
 mov ecx, 51
.quote_mod:
 div ecx
 add edx, 75
 mov ecx, [esp+4]
 mov eax, [regional_bases+ecx*4]
 mul edx
 mov ecx, 100
 div ecx
 ret
.quote_no:
 xor eax, eax
 ret

# unsigned *regional_slot(native_object, create)
# Three extra quantities live outside the native four-slot structure.
# Returns NULL on invalid owner / exhausted table. Caller must reject trade.
regional_slot:
 push ebx
 push esi
 mov edx, [esp+12]
 test edx, edx
 jz .slot_no
 mov esi, offset regional_slots
 xor ebx, ebx
 mov ecx, 1024
.slot_scan:
 cmp [esi], edx
 je .slot_found
 cmp dword ptr [esi], 0
 jne .slot_next
 test ebx, ebx
 jnz .slot_next
 mov ebx, esi
.slot_next:
 add esi, 16
 loop .slot_scan
 cmp dword ptr [esp+16], 0
 je .slot_no
 test ebx, ebx
 jz .slot_no
 mov esi, ebx
 mov [esi], edx
 mov dword ptr [esi+4], 0
 mov dword ptr [esi+8], 0
 mov dword ptr [esi+12], 0
.slot_found:
 lea eax, [esi+4]
 jmp .slot_exit
.slot_no:
 xor eax, eax
.slot_exit:
 pop esi
 pop ebx
 ret

# Clear when native ship/warehouse object is destroyed or reused, and on load.
regional_clear:
 push 0
 push dword ptr [esp+8]
 call regional_slot
 add esp, 8
 test eax, eax
 jz .clear_exit
 mov dword ptr [eax-4], 0
 mov dword ptr [eax], 0
 mov dword ptr [eax+4], 0
 mov dword ptr [eax+8], 0
.clear_exit:
 ret

# unsigned regional_trade(wallet64*, qty*, requested, price, free_space, sell)
# Returns units completed; zero leaves all state unchanged. Buy permission,
# source/destination selection and distribution across ships are caller duties.
regional_trade:
 push ebp
 mov ebp, esp
 push ebx
 push esi
 push edi
 mov esi, [ebp+8]
 mov edi, [ebp+12]
 test esi, esi
 jz .trade_no
 test edi, edi
 jz .trade_no
 mov ebx, [ebp+16]
 test ebx, ebx
 jle .trade_no
 mov ecx, [ebp+20]
 test ecx, ecx
 jle .trade_no
 cmp dword ptr [edi], 0
 jl .trade_no
 cmp dword ptr [ebp+28], 1
 ja .trade_no
 je .trade_sell
 mov eax, [ebp+24]
 test eax, eax
 jle .trade_no
 cmp ebx, eax
 jbe .buy_quantity
 mov ebx, eax
.buy_quantity:
 mov eax, 0x7fffffff
 sub eax, [edi]
 cmp ebx, eax
 jbe .buy_money
 mov ebx, eax
.buy_money:
 mov eax, [esi]
 mov edx, [esi+4]
 cmp edx, ecx
 jae .buy_commit
 div ecx
 cmp ebx, eax
 jbe .buy_commit
 mov ebx, eax
.buy_commit:
 test ebx, ebx
 jz .trade_no
 mov eax, ebx
 mul ecx
 sub [esi], eax
 sbb [esi+4], edx
 add [edi], ebx
 mov eax, ebx
 jmp .trade_exit
.trade_sell:
 cmp ebx, [edi]
 jbe .sell_commit
 mov ebx, [edi]
.sell_commit:
 test ebx, ebx
 jz .trade_no
 mov eax, ebx
 mul ecx
 add eax, [esi]
 adc edx, [esi+4]
 jc .trade_no
 mov [esi], eax
 mov [esi+4], edx
 sub [edi], ebx
 mov eax, ebx
 jmp .trade_exit
.trade_no:
 xor eax, eax
.trade_exit:
 pop edi
 pop esi
 pop ebx
 pop ebp
 ret

.align 4
regional_bases: .long 90, 175, 2500
regional_ports: .long port_tea, port_spices, port_jade
port_tea: .asciz "tanchon"
port_spices: .asciz "lamasut"
port_jade: .asciz "edamame"
.align 4
regional_slots: .zero 16384
