Tradewinds Classic Fair Wind TEST patch v9

NEW IN V9
Douglas McGowan's Fair Wind receives the blue-and-gold ship design from your
reference in the fleet sidebar, ship information and animated combat artwork.
Combat frames are 95x72 pixels: bigger than a one-masted sloop (87x72), smaller
than a two-masted sloop (103x72). Transparency and damage frames are included.
Fair Wind has 250 cargo space, allowing up to 25 cannons in an empty hold.
Maximum hull is 60, double an ordinary one-master's 30 in the current patch.
Other stats stay the same. Purchase additional cannons normally; Douglas's
starting eight cannons are retained. Cargo and available gold can limit buying.
Existing Fair Wind ships upgrade when ship info/combat/value refreshes run.
Current hull doubles once, preserving its damage proportion rather than healing.
Ordinary one-masted sloops remain 150 cargo / 15 cannons / 30 maximum hull.
Fair Wind is exclusive to Douglas's starting fleet; it is not a catalog item.

ALL V8 FEATURES INCLUDED
Tea is purchased only in Tanchon, Spices only in Lama Sut, and Jade & Gemstones
only in Edamame. All three can be sold anywhere, with fluctuating prices and
the supplied designs. Quantity, Buy/Sell, Max, and warehouse transfer controls
are retained, along with their saved inventories and capacity checks.
Black Dragon retains its custom art, enlarged combat frames, 450 cargo and
45-cannon maximum. Junk retains 50 cargo / five cannons. Warehouses retain
15,000 capacity. Five shipyard tiers, automatic restocking, maximum-cannon
purchase, shortened repair labels and the earlier 100-ship limit remain.

INSTALL
1. Close the game. Back up the original game folder and every save.tw* file.
2. Copy BOTH TW1_00.data and
   TradewindsClassic_100Ships_2xHull_ShipyardCatalog_TEST.exe from this package
   into your ORIGINAL game folder, replacing the previous patch files.
3. Keep bass.dll, fmod.dll, gd204.dll, TW1_01.data and all other original game
   files in that folder. This ZIP is a patch, not a complete game installation.
4. Launch the patched executable. Load Douglas's save and select Fair Wind,
   or start a new Douglas game. Buy up to 25 cannons with sufficient gold.

SAVES AND ROLLBACK
V8 regional quantities remain associated with Fair Wind after its upgrade.
Saves written with v9 use the registered fairwind_visual type and need matching
v9 data. To roll back, restore older EXE/data AND a pre-v9 save backup.
The patch does not resurrect ships lost in older faulty builds.

PLEASE TEST ON WINDOWS
Check Fair Wind's sidebar/ship information artwork and 250 cargo / 60 maximum
hull. Buy 25 cannons with sufficient gold and an empty hold. Enter/leave the
shipyard repeatedly, sail to another port, test combat visibility and relative
size, and save/reload. Check its regional cargo stays intact. An ordinary
one-master and Black Dragon should retain their previous stats and artwork.

VALIDATION
The integrated build passed 94 earlier regression checks, 16 regional tests,
eight Fair Wind tests and nine x86 core tests. These exercise native hooks,
fleet grouping, repeat upgrades, hull damage, cannon/gold/cargo limits,
transparency, animation/damage frames and v8/v9 regional save association.
Engine services are stubbed; full Windows gameplay/rendering has not been run.
This remains a TEST build requiring your in-game verification.

SOURCE
Read source/FAIR_WIND.md and source/REGIONAL_GOODS.md. Both builders, native
assembly/C, tests and artwork are included. Dependencies include Python with
source/requirements-dev.txt, GCC with i386 support, GNU binutils and ImageMagick
(for regenerating artwork only). Original supplied uploads remain unchanged.
