import unittest,xml.etree.ElementTree as E
from test_regional_runtime import Machine,OUT,MARKET,PORTS,SYMS
from unicorn.x86_const import UC_X86_REG_ESP,UC_X86_REG_ECX
from fix_xml_format import entries,decode
class TradeMachine(Machine):
 def __init__(self):self.native_trades=[];super().__init__()
 def hook(self,u,a,n,user):
  sp=u.reg_read(UC_X86_REG_ESP);cx=u.reg_read(UC_X86_REG_ECX)
  if a==0x42d390:self.ret(4,int(self.cstr(self.r(cx+4))==self.cstr(self.r(sp+4))))
  elif a in [0x4181a0,0x4184e0]:self.native_trades.append(a);self.ret()
  elif a in [0x401b10,0x4019a0]:self.ret(8)
  else:super().hook(u,a,n,user)
 def input(self,n):
  self.u.mem_write(0x218500,b'trade_inc\0');self.u.mem_write(0x218600,b'rg0+\0');self.call('rg_market_action',0x218500,0x218600)
  window=self.windows['trade_menu'];self.texts[self.controls[(window,'rga0')]]=str(n)
 def lower(self,cmd,arg=''):
  self.u.mem_write(0x218000,cmd.encode()+b'\0');self.u.mem_write(0x218100,arg.encode()+b'\0')
  self.native(0x4189f0,len(cmd),0x218000,len(arg),0x218100,owner=MARKET)
 def quantity(self):return self.texts[self.controls[(self.windows['trade_menu'],'rga0')]]
class TeaRowTests(unittest.TestCase):
 def test_buy_and_sell_use_lower_amount_and_native_flow(self):
  m=TradeMachine();m.input(7);m.u.mem_write(MARKET+0x9a,b'\1');gold=m.gold();m.lower('trade')
  self.assertEqual(sum(m.r(m.q(s))for s in m.ships),7);self.assertEqual(m.quantity(),'0');self.assertEqual(m.native_trades,[0x4181a0]);price=m.r(SYMS['rg_prices']);self.assertEqual(m.gold(),gold-7*price)
  m.input(3);m.u.mem_write(MARKET+0x9a,b'\0\1');m.lower('trade');self.assertEqual(sum(m.r(m.q(s))for s in m.ships),4);self.assertEqual(m.native_trades[-1],0x4184e0);self.assertEqual(m.gold(),gold-4*price)
 def test_sell_all_includes_tea_and_native_return_cleanup(self):
  m=TradeMachine();m.action('rg0B');before=m.gold();qty=sum(m.r(m.q(s))for s in m.ships);price=m.r(SYMS['rg_prices']);m.lower('sell_all')
  self.assertEqual(sum(m.r(m.q(s))for s in m.ships),0);self.assertEqual(m.gold(),before+qty*price)
 def test_lower_plus_minus_max_and_port_restriction(self):
  m=TradeMachine();m.input(0);m.u.mem_write(MARKET+0x9a,b'\1');m.lower('trade_inc','rg0+');self.assertEqual(m.quantity(),'1');m.lower('trade_inc','rg0-');self.assertEqual(m.quantity(),'0');m.lower('trade_inc','rg0-');self.assertEqual(m.quantity(),'0');m.lower('trade_inc','rg0M');self.assertEqual(m.quantity(),'140')
  m.w(PORTS+0x1c,m.ports[3]);m.lower('trade_inc','rg0M');self.assertEqual(m.quantity(),'0');m.input(10);m.lower('trade');self.assertEqual(sum(m.r(m.q(s))for s in m.ships),0)
 def test_warehouse_lower_trade_and_max_sell(self):
  m=TradeMachine();m.u.mem_write(MARKET+0x99,b'\1\1');m.input(8);m.lower('trade');w=m.ports[0]+0x80;self.assertEqual(m.r(m.q(w)),8)
  m.u.mem_write(MARKET+0x9a,b'\0\1');m.lower('trade_inc','rg0M');self.assertEqual(m.quantity(),'8');m.lower('trade');self.assertEqual(m.r(m.q(w)),0)
 def test_row_bindings_order_and_window_bounds(self):
  ui=E.fromstring(decode(dict(entries((OUT/'TW1_00.data').read_bytes()))['assets/xml/int_buildings.txt']));c=ui.find('trade_menu/children')
  self.assertEqual([int(c.findtext(t+'/y'))for t in ['item1','rtname0','item2','item3','item4']],[10,35,60,85,110])
  for tag,cmd in [('rtdec0','trade_inc(rg0-)'),('rtinc0','trade_inc(rg0+)'),('rtmax0','trade_inc(rg0M)')]:self.assertEqual(c.findtext(tag+'/onlclick'),cmd)
  self.assertEqual(c.findtext('action/onlclick'),'trade');self.assertEqual(c.findtext('sell_all/onlclick'),'sell_all');self.assertLessEqual(int(ui.findtext('trade_menu/y'))+int(ui.findtext('trade_menu/height')),485)
if __name__=='__main__':unittest.main(argv=[__file__],verbosity=2)
