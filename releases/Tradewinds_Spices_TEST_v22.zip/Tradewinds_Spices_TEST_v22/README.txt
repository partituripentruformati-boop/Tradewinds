Tradewinds v22 TEST — Spices, with the working v21.1 market fix retained

Spices buy exclusively in Lama Sut, with fluctuating prices based on 175 gold.
Sell Spices in any port. Tea retains its Tanchon-only source and existing behavior.
Jade & Gemstones remains disabled. The supplied Spices icon is included.

Spices appears after Tea in market and warehouse inventory/quantity panels:
General Merchandise, Tea, Spices, Arms, Silk and textiles, Dream Dust.
Use the normal Buy/Sell/Sell All and Transfer buttons for both regional goods.
Panels fit six items above the log; no extra upper shortcut row is added.
A random shared paid-round alehouse tip mentions Lama Sut as the Spices source.
The tip can appear at any alehouse, alongside the existing Tea and original tips.

The confirmed v21.1 purchase fix is retained: zero regional quantities skip
extra trade refreshes; selected original four-item quantities are preserved
across Tea/Spices refreshes. Regional goods trade first, then native original
goods use the remaining cash/space. No new global command registrations.
All existing ship, artwork, shipyard, cannon and warehouse upgrades remain.

SAVES
The existing three-slot extension format is unchanged. Tea-only v21/v21.1 saves
load without replacing your save files. Their zero Spices quote is accepted only
when saved Spices stock is zero, then initialized on UI refresh/use while Tea's
saved price and inventory are preserved. Save/load of both goods is supported.
Back up your saves: saving a game containing Spices under an older Tea-only
build is unsupported; keep a pre-v22 backup for rollback.

INSTALL AND TEST
Close the game; back up saves and both working v21.1 patch files. Extract this
ZIP and copy BOTH executable and TW1_00.data into the original game folder.
1. Confirm startup and a small original commodity purchase still work.
2. Visit Lama Sut; buy a small quantity in the lower Spices row.
3. Store/retrieve Spices at a warehouse and sell some in another port.
4. Save, close and reload; check both Tea and Spices inventories.
If it crashes, send Tradewinds-startup.log (first line says v22).

VALIDATION
94 existing regressions, nine Spices/migration tests, 18 regional-runtime tests,
four original-selection regressions, five market-row tests, four warehouse
checks, eight Fair Wind tests and eight diagnostic checks passed in x86
emulation. Spices checks include exclusivity, fluctuating prices, gold/shared
capacity, native command stack cleanup, mixed-original selections, transfers,
v21 save migration and two-commodity save/reload. Engine services and original
trade execution functions are mocked; actual Windows gameplay remains to test.
Source rebuild reproduces both release files exactly. Real Wine/QEMU startup
reached all 11 constructor entry markers with no logged crash; its existing
graphics-mode limitation remains.

REBUILD
source/build_spices_patch.py --base-v7 <working v7 folder> --output <folder>
Requires Python, pefile, capstone, Pillow, gcc -m32 and GNU binutils; tests use
Unicorn. The bundled v21 save-extension fixture is synthetic test data.
