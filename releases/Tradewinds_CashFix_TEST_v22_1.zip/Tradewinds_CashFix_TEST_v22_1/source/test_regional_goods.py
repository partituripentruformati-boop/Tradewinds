"""Build and emulate experimental x86 core; does not patch/run the game."""
from pathlib import Path
import random
import json
import hashlib
import struct
import subprocess
import tempfile
import unittest

from unicorn import Uc, UC_ARCH_X86, UC_MODE_32
from unicorn.x86_const import (
    UC_X86_REG_EAX, UC_X86_REG_EBX, UC_X86_REG_ESI, UC_X86_REG_EDI,
    UC_X86_REG_EBP, UC_X86_REG_ESP,
)

ROOT = Path(__file__).resolve().parent
BASE, DATA, STACK, STOP = 0x480000, 0x200000, 0x318000, 0x490000
with tempfile.TemporaryDirectory(prefix='tradewinds-goods-') as directory:
    target = Path(directory)
    subprocess.run(['as', '--32', str(ROOT/'regional_goods.s'), '-o', str(target/'core.o')], check=True)
    subprocess.run(['ld', '-m', 'elf_i386', '-Ttext', hex(BASE), '--entry', 'regional_quote',
                    str(target/'core.o'), '-o', str(target/'core.elf')], check=True)
    subprocess.run(['objcopy', '-O', 'binary', '--only-section=.text', str(target/'core.elf'),
                    str(target/'core.bin')], check=True)
    CODE = (target/'core.bin').read_bytes()
    SYMBOLS = {line.split()[2]: int(line.split()[0], 16) for line in subprocess.check_output(
        ['nm', '-n', str(target/'core.elf')], text=True).splitlines()}


class Core:
    def __init__(self):
        self.u = Uc(UC_ARCH_X86, UC_MODE_32)
        for base, size in [(BASE, 0x20000), (DATA, 0x10000), (0x300000, 0x20000)]:
            self.u.mem_map(base, size)
        self.u.mem_write(BASE, CODE)

    def call(self, name, *args):
        saved = {UC_X86_REG_EBX: 0x12345678, UC_X86_REG_ESI: 0x23456789,
                 UC_X86_REG_EDI: 0x34567890, UC_X86_REG_EBP: 0x45678901}
        for register, value in saved.items():
            self.u.reg_write(register, value)
        self.u.reg_write(UC_X86_REG_ESP, STACK)
        self.u.mem_write(STACK, struct.pack('<'+'I'*(len(args)+1), STOP,
                                           *(value & 0xffffffff for value in args)))
        self.u.emu_start(SYMBOLS[name], STOP, count=20000)
        assert self.u.reg_read(UC_X86_REG_ESP) == STACK+4
        for register, value in saved.items():
            assert self.u.reg_read(register) == value
        return self.u.reg_read(UC_X86_REG_EAX)

    def quantity(self, address):
        return struct.unpack('<I', self.u.mem_read(address, 4))[0]


class RegionalGoodsTests(unittest.TestCase):
    def test_supplied_sprite_assets_are_native_palette_icons(self):
        from PIL import Image
        root = ROOT/'regional-goods-assets'
        manifest = json.loads((root/'manifest.json').read_text())
        self.assertEqual([item['purchase_port'] for item in manifest['items']],
                         ['tanchon', 'lamasut', 'edamame'])
        for item in manifest['items']:
            path = root/item['icon_file']
            self.assertEqual(hashlib.sha256(path.read_bytes()).hexdigest(), item['sha256'])
            with Image.open(path) as icon:
                self.assertEqual(icon.size, (20, 20))
                self.assertEqual(icon.mode, 'P')
                alpha = icon.convert('RGBA').getchannel('A')
                self.assertEqual(alpha.getextrema(), (0, 255))
                self.assertEqual(alpha.getpixel((0, 0)), 0)
                self.assertEqual(alpha.getpixel((19, 19)), 0)

    def test_native_ship_capacity_counts_all_goods_without_mutation(self):
        core = Core()
        ship, ship_type = DATA, DATA+0x100
        for capacity, guns in [(450, 35), (350, 30), (50, 1)]:
            native = bytearray(56)
            struct.pack_into('<I', native, 0, ship_type)
            struct.pack_into('<IIIII', native, 0x14, guns, 4, 3, 2, 1)
            native[0x28:] = b'\xa5'*16
            core.u.mem_write(ship, bytes(native))
            core.u.mem_write(ship_type+0x18, struct.pack('<I', capacity))
            address = core.call('regional_slot', ship, 1)
            core.u.mem_write(address, struct.pack('<III', 17, 9, 21))
            self.assertEqual(core.call('regional_ship_free', ship),
                             (capacity-guns*10-10-47) & 0xffffffff)
            self.assertEqual(bytes(core.u.mem_read(ship, 56)), bytes(native))
        core.call('regional_clear', ship)
        self.assertEqual(core.call('regional_ship_free', ship), 30)

    def test_native_warehouse_capacity_counts_all_goods(self):
        core = Core()
        core.u.mem_write(DATA+0x100, struct.pack('<IIII', 4000, 3000, 2000, 1000))
        address = core.call('regional_slot', DATA, 1)
        core.u.mem_write(address, struct.pack('<III', 1000, 2000, 2000))
        self.assertEqual(core.call('regional_warehouse_free', DATA, DATA+0x100), 0)
        core.u.mem_write(address, struct.pack('<III', 1000, 2000, 2001))
        self.assertEqual(core.call('regional_warehouse_free', DATA, DATA+0x100), 0xffffffff)
        core.call('regional_clear', DATA)
        self.assertEqual(core.call('regional_warehouse_free', DATA, DATA+0x100), 5000)

    def test_exclusive_source_and_sell_port_independence(self):
        core = Core()
        for item, source in enumerate(['tanchon', 'lamasut', 'edamame']):
            for port in ['tanchon', 'lamasut', 'edamame', 'jiaching', 'lotus1', '', 'Tanchon']:
                core.u.mem_write(DATA, port.encode()+b'\0')
                self.assertEqual(core.call('regional_can_buy', item, DATA), int(port == source))
        self.assertEqual(core.call('regional_can_buy', 3, DATA), 0)
        self.assertEqual(core.call('regional_can_buy', 0, 0), 0)

    def test_price_range_variation_and_exact_base(self):
        core = Core()
        for item, base in enumerate([90, 175, 2500]):
            for source, modulus in [(1, 51), (0, 101)]:
                prices = [core.call('regional_quote', item, roll, source) for roll in range(modulus)]
                self.assertEqual(min(prices), base*75//100)
                self.assertEqual(max(prices), base*(125 if source else 175)//100)
                self.assertIn(base, prices)
                self.assertGreater(len(set(prices)), 30)
                for roll in [32767, 32768, 0xffffffff]:
                    self.assertEqual(core.call('regional_quote', item, roll, source),
                                     base*(75+(roll & 32767) % modulus)//100)
        self.assertEqual(core.call('regional_quote', 3, 42, 1), 0)

    def test_isolated_storage_and_lifecycle(self):
        core = Core()
        first = core.call('regional_slot', 0xabc, 1)
        second = core.call('regional_slot', 0xdef, 1)
        self.assertNotEqual(first, second)
        core.u.mem_write(first, struct.pack('<III', 17, 9, 21))
        self.assertEqual(core.call('regional_slot', 0xabc, 1), first)
        self.assertEqual(bytes(core.u.mem_read(first, 12)), struct.pack('<III', 17, 9, 21))
        self.assertEqual(bytes(core.u.mem_read(second, 12)), bytes(12))
        core.call('regional_clear', 0xabc)
        self.assertEqual(core.call('regional_slot', 0xabc, 0), 0)
        self.assertEqual(bytes(core.u.mem_read(first, 12)), bytes(12))
        self.assertEqual(core.call('regional_slot', 0x123, 1), first)
        self.assertEqual(core.call('regional_slot', 0, 1), 0)
        self.assertEqual(core.call('regional_slot', 0x999, 0), 0)

    def test_storage_full_fails_without_overwriting(self):
        core = Core()
        for owner in range(1, 1025):
            address = core.call('regional_slot', owner, 1)
            self.assertNotEqual(address, 0)
            core.u.mem_write(address, struct.pack('<I', owner))
        before = bytes(core.u.mem_read(SYMBOLS['regional_slots'], 16384))
        self.assertEqual(core.call('regional_slot', 1025, 1), 0)
        self.assertEqual(bytes(core.u.mem_read(SYMBOLS['regional_slots'], 16384)), before)
        core.call('regional_clear', 500)
        self.assertNotEqual(core.call('regional_slot', 1025, 1), 0)

    def test_transactions_against_integer_reference(self):
        core = Core()
        generator = random.Random(20261011)
        cases = [(100, 0, 10, 90, 100, 0), (2**40, 0, 100, 2500, 15, 0),
                 (2**64-1, 30, 10, 2500, 0, 1), (0, 4, 100, 175, 0, 1),
                 (2**64-1, 2**31-1, 1, 90, 100, 0), (0, 0, 1, 90, 10, 0)]
        for _ in range(300):
            cases.append((generator.randrange(2**64), generator.randrange(500),
                          generator.randrange(1, 1000), generator.choice([90, 175, 2500]),
                          generator.randrange(1000), generator.randrange(2)))
        for gold, quantity, requested, price, space, sell in cases:
            core.u.mem_write(DATA, struct.pack('<QI', gold, quantity))
            if sell:
                units = min(requested, quantity)
                if gold+units*price > 2**64-1:
                    units = 0
                expected = gold+units*price, quantity-units
            else:
                units = min(requested, space, gold//price, 2**31-1-quantity)
                expected = gold-units*price, quantity+units
            self.assertEqual(core.call('regional_trade', DATA, DATA+8, requested, price, space, sell), units)
            self.assertEqual(struct.unpack('<QI', core.u.mem_read(DATA, 12)), expected)

    def test_invalid_transactions_do_not_change_state(self):
        core = Core()
        for request, price, space, sell in [(0, 90, 100, 0), (-1, 90, 100, 0),
                                           (10, 0, 100, 0), (10, -1, 100, 0),
                                           (10, 90, -1, 0), (10, 90, 100, 2)]:
            before = struct.pack('<QI', 100000, 20)
            core.u.mem_write(DATA, before)
            self.assertEqual(core.call('regional_trade', DATA, DATA+8, request, price, space, sell), 0)
            self.assertEqual(bytes(core.u.mem_read(DATA, 12)), before)


if __name__ == '__main__':
    unittest.main(verbosity=2)
