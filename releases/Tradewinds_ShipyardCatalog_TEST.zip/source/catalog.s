.intel_syntax noprefix
.section .text
.global make_offer, dispatch, restock
# Same thiscall signature as the original random offer factory.
make_offer:
 push esi
 mov esi,ecx
 push 0
 push 1
 sub esp,12
 mov DWORD PTR [esp+8],0x3f800000
 mov ecx,esp
 push DWORD PTR [selected]
 mov eax,0x42d0e0
 call eax
 mov ecx,esi
 mov eax,0x424480
 call eax
 test eax,eax
 jz make_done
 mov BYTE PTR [eax+0x31],0
make_done:
 pop esi
 ret

# Enter with the original dispatch frame intact, ESI = Shipyards.
dispatch:
 push OFFSET FLAT:action_junk
 lea ecx,[esp+0x24]
 mov eax,0x42d390
 call eax
 test al,al
 jnz choose_junk
 push OFFSET FLAT:action_onemast
 lea ecx,[esp+0x24]
 mov eax,0x42d390
 call eax
 test al,al
 jnz choose_onemast
 push OFFSET FLAT:action_twomast
 lea ecx,[esp+0x24]
 mov eax,0x42d390
 call eax
 test al,al
 jnz choose_twomast
 push OFFSET FLAT:action_brigantine
 lea ecx,[esp+0x24]
 mov eax,0x42d390
 call eax
 test al,al
 jnz choose_brigantine
 push OFFSET FLAT:action_megaship
 lea ecx,[esp+0x24]
 mov eax,0x42d390
 call eax
 test al,al
 jnz choose_megaship
 # Replay overwritten push and resume original dispatcher.
 push 0x456288
 mov eax,0x42754a
 jmp eax
choose_junk:
 mov eax,OFFSET FLAT:type_junk
 jmp choose
choose_onemast:
 mov eax,OFFSET FLAT:type_onemast
 jmp choose
choose_twomast:
 mov eax,OFFSET FLAT:type_twomast
 jmp choose
choose_brigantine:
 mov eax,OFFSET FLAT:type_brigantine
 jmp choose
choose_megaship:
 mov eax,OFFSET FLAT:type_megaship
choose:
 mov DWORD PTR [selected],eax
 mov ecx,DWORD PTR ds:0x465dac
 mov eax,0x4232f0
 call eax
 cmp DWORD PTR [eax],100
 jge dispatch_done
 # Only the unpurchased offer belongs to Shipyards.
 mov edi,DWORD PTR [esi+0x10]
 test edi,edi
 jz new_offer
 lea ecx,[edi+4]
 mov eax,0x42d1a0
 call eax
 push edi
 mov eax,0x4373ff
 call eax
 add esp,4
new_offer:
 mov ecx,DWORD PTR ds:0x465dac
 call make_offer
 mov DWORD PTR [esi+0x10],eax
 mov BYTE PTR [esi+0x7c],1
 mov ecx,esi
 mov eax,0x427240
 call eax
 dispatch_done:
 mov eax,0x4277a3
 jmp eax

# Enter in place of the post-purchase notification call. Its arguments
# remain on the original stack for the original callee to consume.
restock:
 mov eax,0x4137b0
 call eax
 mov DWORD PTR [esi+0x10],0
 mov ecx,DWORD PTR ds:0x465dac
 mov eax,0x4232f0
 call eax
 cmp DWORD PTR [eax],100
 jge restock_done
 mov ecx,DWORD PTR ds:0x465dac
 call make_offer
 mov DWORD PTR [esi+0x10],eax
 mov BYTE PTR [esi+0x7c],1
restock_done:
 mov eax,0x425739
 jmp eax
.balign 4
selected: .long type_junk
type_junk: .asciz "junk"
type_onemast: .asciz "onemast"
type_twomast: .asciz "twomast"
type_brigantine: .asciz "brigantine"
type_megaship: .asciz "megaship"
action_junk: .asciz "yard_junk"
action_onemast: .asciz "yard_onemast"
action_twomast: .asciz "yard_twomast"
action_brigantine: .asciz "yard_brigantine"
action_megaship: .asciz "yard_megaship"
