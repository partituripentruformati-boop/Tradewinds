Tradewinds v16 TEST — Tea only

Tea is available to buy exclusively in Tanchon, with a fluctuating price based
on 90 gold. Tea can be sold in other ports, carried by ships, transferred to/from
warehouses, and saved/loaded. The supplied Tea artwork is included. Spices and
Jade & Gemstones are disabled and have no market rows or active trade commands.

Startup repair candidate: the new goods no longer add entries to the global
command registry. Tea buttons use the existing native trade_inc command with
a Tea action argument, intercepted before the original handler. The building
constructor's original registration code is unchanged. Refreshing the new UI
also checks that the fleet manager has been initialized before accessing it.
This avoids the added registration path associated with the earlier crash;
it is not yet a confirmed fix on the user's Windows machine.

All prior ship/shipyard upgrades retained: Black Dragon artwork, enlarged battle
sprite, 450 cargo/45 cannons; Fair Wind artwork, 250 cargo/25 cannons, doubled
original hull and requested combat size; Junk 50 cargo/5 cannons; five shipyard
types; max-affordable cannons; short repair labels; 15,000-unit warehouses;
existing fleet limit 100 and inherited global doubled-hull changes.

INSTALL AND TEST
Back up your saves and the working v15 executable and TW1_00.data.
Extract this ZIP; replace BOTH executable and TW1_00.data in the original game
folder alongside your original DLLs and TW1_01.data. Launch the patched EXE.
1. Confirm it gets past Constructing buildings and loads your save.
2. Visit Tanchon and buy a small quantity of Tea.
3. Check warehouse storage/retrieval, then sell Tea in another port.
4. Save, close, and reload to confirm Tea inventory survives.
5. Revisit ports and check Tea's price changes with the market refresh.
If it crashes, send Tradewinds-startup.log (first line should say v16).
Restore BOTH v15 files to roll back. Keep a pre-v16 save backup: saving in v15
drops Tea inventory. This build retains the three-slot extension format for
future additions; the inactive commodity slots stay zero for existing saves.

VALIDATION
94 ship/shipyard/warehouse/artwork/PE regressions; 18 Tea integration checks;
eight Fair Wind checks; eight diagnostic checks passed in x86 emulation.
Tea checks include port exclusivity, disabled items, varying prices, buying,
selling, warehouse transfers, limits, corrupted/old saves, roundtrip saving,
original commodity behavior, actual native market handler stack cleanup and
safe UI refresh before fleet initialization. Engine/Windows services are mocked.
Real Wine/QEMU startup reached all 11 building-constructor entry markers with
no logged crash; the runner still has a graphics-mode limitation. Windows
startup, actual UI rendering, travel and gameplay need the user's playtest.

REBUILD
From source, build_fairwind_patch.py --base-v7 <working v7 folder> --output <base>
then build_startup_trace.py --base <base> --output <output>. Requires Python,
pefile, capstone, Pillow, gcc with -m32, and GNU binutils. Tests also use Unicorn.
The bundled regional sources are the Tea-only revision used for this build.
