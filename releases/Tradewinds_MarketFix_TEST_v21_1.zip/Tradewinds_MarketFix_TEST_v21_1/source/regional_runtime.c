/* Freestanding i386 bridge for the fixed, SHA-checked Tradewinds executable.
 * These functions extend v7 in the separate v8 TEST build.
 * There are no C runtime imports; native calls use the game's original ABI. */
typedef unsigned int U;
typedef unsigned char B;
#define TC __attribute__((thiscall))
#define P(address) (*(void **)(address))
#define W(object, offset) (*(U *)((B *)(object)+(offset)))
typedef struct { U size; char *data; } String;
typedef void (TC *Ctor)(String *, const char *);
typedef void (TC *Dtor)(String *);
typedef void *(TC *Lookup)(void *, U, char *);
typedef void (TC *SetText)(void *, U, char *);
typedef void (TC *IterInit)(U *, void *);
typedef B (TC *IterNext)(U *);
typedef void *(TC *IterGet)(U *);
typedef void (TC *IterEnd)(U *);
extern U *regional_slot(void *, U);
extern void regional_clear(void *);
extern U regional_can_buy(U, const char *);
extern U regional_quote(U, U, U);
extern int regional_ship_free(void *);
extern int regional_warehouse_free(void *, void *);
extern U regional_trade(void *, U *, U, U, U, U);
extern U regional_slots[4096];

U rg_prices[3], rg_ship_count, rg_error;
void *rg_ships[1024];
static U quote_valid, trade_input;

static void zero(void *p,U n) { B *b=p; while(n--) *b++=0; }
static void copy(void *p,const void *q,U n) { B *a=p;const B *b=q;while(n--) *a++=*b++; }
static U hash(const char *p) { U h=2166136261u; if(p)while(*p){h^=(B)*p++;h*=16777619u;} return h; }
static String string(const char *p) { String s;((Ctor)0x42d0e0)(&s,p);return s; }
static void *lookup(void *owner, U address, const char *name) {
 if(!owner)return 0;
 String s=string(name);return ((Lookup)address)(owner,s.size,s.data);
}
static void *widget(const char *window,const char *control) {
 return lookup(lookup(P(0x465d44),0x401890,window),0x40a580,control);
}
static void set(void *control,const char *text) {
 if(!control)return;
 String s=string(text);
 ((SetText)(*(U **)control)[0x28/4])(control,s.size,s.data);
}
static void number(void *control,U value) {
 char b[12],*p=b+11;*p=0;do{*--p='0'+value%10;value/=10;}while(value);set(control,p);
}
static const char *port(void) {
 void *manager=P(0x465d98);void *p=manager?(void *)W(manager,0x1c):0;
 return p?(const char *)W(p,4):"";
}
static void *warehouse(void) {
 void *manager=P(0x465d98);void *p=manager?(void *)W(manager,0x1c):0;
 return p?(void *)W(p,0x48):0;
}
static void begin(U *it,void *list) { ((IterInit)0x430340)(it,list); }
static B next(U *it) { return ((IterNext)0x430370)(it); }
static void *item(U *it) { return ((IterGet)0x430360)(it); }
static void end(U *it) { ((IterEnd)0x430390)(it); }
static void fleet_begin(U *it) { begin(it,(B *)P(0x465dac)+0x38); }
static U owned(void *ship) { return ((B *)ship)[0x31]!=0; }

void rg_reset(void) { zero(regional_slots,16384);quote_valid=0;zero(rg_prices,12); }
void rg_collect_ship(void *ship) {
 if(rg_ship_count<1024)rg_ships[rg_ship_count++]=ship;else rg_error=1;
}
void rg_io_begin(void) { rg_ship_count=0;rg_error=0; }
void rg_speed(void *ship) {
 void *type=(void *)W(ship,0);
 U used=W(type,0x18)-(U)regional_ship_free(ship);
 W(ship,0xc)=W(type,0x1c)-used/25;
}
void rg_prices_refresh(void) {
 const char *tag=port();
 for(U i=0;i<1;i++) {
  U roll=((U (*)(void))0x4375c7)();
  rg_prices[i]=regional_quote(i,roll,regional_can_buy(i,tag));
 }
 quote_valid=1;
}
static U fleet_qty(U index) {
 U it,total=0;fleet_begin(&it);
 while(next(&it)) { void *ship=item(&it);U *q=regional_slot(ship,0);
  if(owned(ship)&&q)total+=q[index]; }
 end(&it);return total;
}
/* UI refresh hooks use separately named controls; native arrays stay at four. */
void rg_ui_refresh(void) {
 if(!P(0x465dac))return;
 if(!quote_valid)rg_prices_refresh();
 void *market=P(0x465d88),*ware=warehouse();
 U *q=ware?regional_slot(ware,0):0;
 U to_ware=market?((B *)market)[0x99]:0;
 for(U i=0;i<1;i++) {
  char label[]="rgp0",quantity[]="rgq0",buy[]="rgb0",maxbuy[]="rgb0m",wq[]="rgw0";
  label[3]=quantity[3]=buy[3]=maxbuy[3]=wq[3]='0'+i;
  number(widget("marketplace",label),rg_prices[i]);
  number(widget("marketplace",quantity),to_ware?(q?q[i]:0):fleet_qty(i));
  set(widget("marketplace",buy),regional_can_buy(i,port())?"Buy":"--");
  void *ware_ui=P(0x465dc0);
  set(widget("marketplace",maxbuy),regional_can_buy(i,port())?"Max":"--");
  char wv[]="rgv0";wv[3]='0'+i;number(widget("warehouse",wv),rg_prices[i]);
  number(widget("warehouse",wq),ware_ui&&((B *)ware_ui)[0x28]?(q?q[i]:0):fleet_qty(i));
 }
}
void rg_register(void *owner) {
 const char *modes="bsBSdlDL";
 for(U i=0;i<1;i++)for(U j=0;j<8;j++) {
  char name[]="rg0b";name[2]='0'+i;name[3]=modes[j];String s=string(name);
  typedef void (TC *Register)(void *,U,char *,void *);
  ((Register)0x412a00)(P(0x465d68),s.size,s.data,owner);
 }
}
static U read_quantity(void *control){
 if(!control)return 0;
 String s;typedef String *(TC *GetText)(void *,String *);
 ((GetText)0x40bff0)(control,&s);
 U n=0;char *p=s.data;
 while(p&&*p>='0'&&*p<='9'){
  if(n>214748364u||(n==214748364u&&*p>'7')){n=0;break;}
  n=n*10+*p++-'0';
 }
 ((Dtor)0x42d1a0)(&s);return n;
}
static U amount(U index,U ware){
 char name[]="rga0";name[3]='0'+index;
 return read_quantity(widget(ware?"warehouse":trade_input?"trade_menu":"marketplace",name));
}
static U trade_fleet(U index,U requested,U sell,U price) {
 U it,done=0;fleet_begin(&it);
 while(requested&&next(&it)) {
  void *ship=item(&it);if(!owned(ship))continue;
  U *q=regional_slot(ship,!sell);if(!q)continue;
  int free=regional_ship_free(ship);U n=regional_trade((B *)P(0x465d74)+0x10,
      q+index,requested,price,free>0?free:0,sell);
  if(n){done+=n;requested-=n;rg_speed(ship);}
 }
 end(&it);return done;
}
static U transfer(U index,U requested,U load) {
 void *ware=warehouse();if(!ware)return 0;
 U *w=regional_slot(ware,1);if(!w)return 0;
 if(load&&requested>w[index])requested=w[index];
 if(!load){int space=regional_warehouse_free(ware,ware);
  if(space<=0)return 0;
  if(requested>(U)space)requested=space;}
 U it,done=0;fleet_begin(&it);
 while(requested&&next(&it)) {
  void *ship=item(&it);if(!owned(ship))continue;
  U *s=regional_slot(ship,load);if(!s)continue;U n=requested;
  if(load){int space=regional_ship_free(ship);if(space<=0)continue;if(n>(U)space)n=space;}
  else if(n>s[index])n=s[index];
  if(!n)continue;
  if(load){w[index]-=n;s[index]+=n;}else{s[index]-=n;w[index]+=n;}
  requested-=n;done+=n;rg_speed(ship);
 }
 end(&it);return done;
}
U rg_action(const char *command) {
 if(!command||command[0]!='r'||command[1]!='g'||command[2]<'0'||command[2]>'0'||!command[3]||command[4])return 0;
 U i=command[2]-'0',mode=(B)command[3],sell=mode=='s'||mode=='S';
 U xfer=mode=='d'||mode=='D'||mode=='l'||mode=='L';
 if(!xfer&&!sell&&mode!='b'&&mode!='B')return 0;
 U requested=(mode>='A'&&mode<='Z')?0x7fffffff:amount(i,xfer);
 if(xfer)transfer(i,requested,mode=='l'||mode=='L');
 else if(sell||regional_can_buy(i,port())) {
  if(!quote_valid)rg_prices_refresh();
  void *market=P(0x465d88);
  if(((B *)market)[0x99]) {
   void *ware=warehouse();U *q=ware?regional_slot(ware,1):0;
   if(q){int space=regional_warehouse_free(ware,ware);
    regional_trade((B *)P(0x465d74)+0x10,q+i,requested,rg_prices[i],space>0?space:0,sell);}
  } else trade_fleet(i,requested,sell,rg_prices[i]);
 }
 /* Native refreshes update original rows and finances; their hooks add ours. */
 typedef void (TC *Refresh)(void *);
 ((Refresh)0x418010)(P(0x465d88));
 if(warehouse())((Refresh)0x42a340)(P(0x465dc0));
 typedef void (TC *GoldRefresh)(void *,U,U);
 ((GoldRefresh)0x414760)(P(0x465d74),0,0);
 return 1;
}

/* Versioned trailer after the entire native save. No process pointers on disk.
 * Native ship serialization order binds records; hashes detect mismatches.
 * Ports use native XML tag hashes, including presence of warehouse ownership. */
typedef struct {U key,q[3];} Record;
typedef struct {U magic,version,ships,ports,prices[3],checksum;} Header;
static struct {Header h;Record records[1056];} snapshot;
static U ship_key(void *p) {
 const char *tag=(const char *)W((void *)W(p,0),4);
 const char *expected="fairwind_visual",*cursor=tag;
 while(*cursor&&*cursor==*expected){cursor++;expected++;}
 if(!*cursor&&!*expected)tag="onemast"; /* Keep v8 trailer keys across migration. */
 return hash((const char *)W(p,8))^hash(tag);
}
static U checksum(const B *data,U n) {U h=2166136261u;while(n--){h^=*data++;h*=16777619u;}return h;}
static U port_records(U restore,U validate) {
 U it,count=0;begin(&it,(B *)P(0x465d98)+0x28);
 while(next(&it)) {
  void *p=item(&it),*ware=(void *)W(p,0x48);if(!ware)continue;
  if(count>=32){rg_error=1;break;}
  Record *r=&snapshot.records[rg_ship_count+count++];
  U key=hash((const char *)W(p,4));
  if(restore){if(r->key!=key){rg_error=1;break;}
   if(!validate){U *q=regional_slot(ware,1);if(!q){rg_error=1;break;}copy(q,r->q,12);}}
  else{r->key=key;U *q=regional_slot(ware,0);if(q)copy(r->q,q,12);else zero(r->q,12);}
 }
 end(&it);return count;
}
typedef U (*ReadWrite)(void *,U,U,void *);
U rg_save(void *file) {
 if(rg_error)return 0;
 if(!quote_valid)rg_prices_refresh();
 zero(&snapshot,sizeof(snapshot));
 for(U i=0;i<rg_ship_count;i++) {
  Record *r=&snapshot.records[i];r->key=ship_key(rg_ships[i]);
  U *q=regional_slot(rg_ships[i],0);if(q)copy(r->q,q,12);
 }
 U ports=port_records(0,0);if(rg_error)return 0;
 snapshot.h.magic=0x31434752; snapshot.h.version=1;
 snapshot.h.ships=rg_ship_count;snapshot.h.ports=ports;
 copy(snapshot.h.prices,rg_prices,12);
 U n=(rg_ship_count+ports)*sizeof(Record);
 snapshot.h.checksum=checksum((B *)snapshot.records,n);
 return ((ReadWrite)0x438a09)(&snapshot,sizeof(Header)+n,1,file)==1;
}
U rg_load(void *file) {
 zero(&snapshot,sizeof(snapshot));
 U n=((ReadWrite)0x438768)(&snapshot.h,1,sizeof(Header),file);
 if(!n){quote_valid=0;return 1;} /* Existing save, no trailer. */
 if(n!=sizeof(Header)||snapshot.h.magic!=0x31434752||snapshot.h.version!=1||
    snapshot.h.ships!=rg_ship_count||snapshot.h.ships>1024||snapshot.h.ports>32)return 0;
 n=(rg_ship_count+snapshot.h.ports)*sizeof(Record);
 if(((ReadWrite)0x438768)(snapshot.records,1,n,file)!=n||
    checksum((B *)snapshot.records,n)!=snapshot.h.checksum)return 0;
 for(U i=0;i<rg_ship_count;i++)if(snapshot.records[i].key!=ship_key(rg_ships[i]))return 0;
 for(U i=0;i<rg_ship_count+snapshot.h.ports;i++)for(U j=0;j<3;j++)
  if(snapshot.records[i].q[j]>15000)return 0;
 for(U i=0;i<1;i++)if(!snapshot.h.prices[i]||snapshot.h.prices[i]>100000)return 0;
 if(port_records(1,1)!=snapshot.h.ports||rg_error)return 0;
 /* Allocate all destinations before accepting any quantities. */
 for(U i=0;i<rg_ship_count;i++)if(!regional_slot(rg_ships[i],1))return 0;
 if(port_records(1,0)!=snapshot.h.ports||rg_error)return 0;
 for(U i=0;i<rg_ship_count;i++) {
  copy(regional_slot(rg_ships[i],0),snapshot.records[i].q,12);rg_speed(rg_ships[i]);
 }
 copy(rg_prices,snapshot.h.prices,12);quote_valid=1;return 1;
}

void TC rg_max_cannons(void *yard) {
 for(U guard=0;guard<100;guard++) {
  void *info=(void *)W(yard,0xc);if(!info)return;
  void *ship=(void *)W(info,0);if(!ship||!owned(ship)||regional_ship_free(ship)<10)return;
  U price=W(yard,0x24),*gold=(U *)((B *)P(0x465d74)+0x10);
  if(!price||(int)gold[1]<0||(!gold[1]&&gold[0]<price))return;
  U guns=W(ship,0x14);((void (TC *)(void *))0x4260c0)(yard);
  if(W(ship,0x14)<=guns)return;
 }
}
void rg_redistribute(void *source) {
 U *q=regional_slot(source,0);if(!q)return;
 U it;fleet_begin(&it);
 while(next(&it)) {
  void *dest=item(&it);if(dest==source||!owned(dest))continue;
  U *d=regional_slot(dest,1);if(!d)continue;
  for(U i=0;i<1;i++) {
   int free=regional_ship_free(dest);if(free<=0)break;
   U n=q[i]<(U)free?q[i]:(U)free;d[i]+=n;q[i]-=n;
  }
  rg_speed(dest);
 }
 end(&it);rg_speed(source);
}
U rg_extra_total(void *owner) {
 U *q=regional_slot(owner,0);return q?q[0]+q[1]+q[2]:0;
}
U *rg_theft_target(void *ware) {
 U *best=ware,*q=regional_slot(ware,0);
 for(U i=1;i<4;i++)if(((U *)ware)[i]>*best)best=(U *)ware+i;
 if(q)for(U i=0;i<1;i++)if(q[i]>*best)best=q+i;
 return best;
}
U rg_fleet_extra_total(void) { return fleet_qty(0)+fleet_qty(1)+fleet_qty(2); }
U rg_market_extra_total(void) {
 return ((B *)P(0x465d88))[0x99]?rg_extra_total(warehouse()):rg_fleet_extra_total();
}


/* Tea uses the existing router; native four-item actions continue unchanged. */
static U equals(const char *a,const char *b) {
 if(!a||!b)return 0;
 while(*a&&*a==*b){a++;b++;}return !*a&&!*b;
}
static U tea_input(void){trade_input=1;U n=amount(0,0);trade_input=0;return n;}
static void tea_set(U n){number(widget("trade_menu","rga0"),n);}
static U tea_max(void){
 void *market=P(0x465d88);if(!market)return 0;
 U sell=((B *)market)[0x9b],to_ware=((B *)market)[0x99];void *w=warehouse();
 if(sell){U *q=w?regional_slot(w,0):0;return to_ware?(q?q[0]:0):fleet_qty(0);}
 if(!((B *)market)[0x9a]||!regional_can_buy(0,port()))return 0;
 if(!quote_valid)rg_prices_refresh();
 if(!rg_prices[0])return 0;
 typedef int (TC *Free)(void *);
 int free=to_ware?(w?regional_warehouse_free(w,w):0):((Free)0x4236a0)(P(0x465dac));
 if(free<=0)return 0;
 unsigned long long gold=*(unsigned long long *)((B *)P(0x465d74)+0x10);
 U lo=0,hi=(U)free;
 while(lo<hi){U mid=lo+(hi-lo+1)/2;if((unsigned long long)mid*rg_prices[0]<=gold)lo=mid;else hi=mid-1;}
 return lo;
}
static U warehouse_max(void){
 void *ui=P(0x465dc0),*w=warehouse();if(!ui||!w)return 0;
 U load=((B *)ui)[0x28];U *q=regional_slot(w,0);
 U stock=load?(q?q[0]:0):fleet_qty(0);
 typedef int (TC *Free)(void *);
 int space=load?((Free)0x4236a0)(P(0x465dac)):regional_warehouse_free(w,w);
 return space>0?(stock<(U)space?stock:(U)space):0;
}
static U warehouse_action(const char *argument){
 if(!argument||argument[0]!='r'||argument[1]!='w'||argument[2]!='0')return 0;
 U n=amount(0,1);void *ui=P(0x465dc0);
 if(equals(argument,"rw0+")){if(n<0x7fffffff)n++;}
 else if(equals(argument,"rw0-")){if(n)n--;}
 else if(equals(argument,"rw0M")){n=warehouse_max();}
 else if(equals(argument,"rw0t")){
  if(!ui)return 1;
  U load=((B *)ui)[0x28];transfer(0,n,load);
  typedef void (TC *NativeTransfer)(void *);
  ((NativeTransfer)(load?0x42a780:0x42ab60))(ui);n=0;
 }else return 0;
 number(widget("warehouse","rga0"),n);return 1;
}
U rg_market_action(const char *command,const char *argument) {
 if(equals(command,"market_buy")||equals(command,"market_sell")||equals(command,"end_trade")){tea_set(0);return 0;}
 if(equals(command,"trade")){
  void *market=P(0x465d88);if(!market)return 0;
  U buy=((B *)market)[0x9a],sell=((B *)market)[0x9b];
  if((buy||sell)&&tea_input()){
   /* Native refresh resets qty_edit1..4. Preserve selections until native trade. */
   U selections[4];void *controls[4];
   for(U i=0;i<4;i++){controls[i]=(void *)W(market,0x40+i*4);selections[i]=read_quantity(controls[i]);}
   trade_input=1;rg_action(sell?"rg0s":"rg0b");trade_input=0;tea_set(0);
   for(U i=0;i<4;i++)number(controls[i],selections[i]);
  }
  return 0;
 }
 if(equals(command,"sell_all")){rg_action("rg0S");tea_set(0);return 0;}
 if(!equals(command,"trade_inc"))return 0;
 if(warehouse_action(argument))return 1;
 if(equals(argument,"rg0+")){U n=tea_input();if(n<0x7fffffff)n++;tea_set(n);return 1;}
 if(equals(argument,"rg0-")){U n=tea_input();tea_set(n?n-1:0);return 1;}
 if(equals(argument,"rg0M")){tea_set(tea_max());return 1;}
 return rg_action(argument);
}
