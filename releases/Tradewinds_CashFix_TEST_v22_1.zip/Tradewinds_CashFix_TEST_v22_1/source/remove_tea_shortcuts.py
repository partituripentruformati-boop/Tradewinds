"""UI-only v19: remove redundant Tea shortcuts; retain native lower trade row."""
from pathlib import Path
import argparse,hashlib,json,shutil,xml.etree.ElementTree as E
from fix_xml_format import entries,pack,decode,encode
p=argparse.ArgumentParser();p.add_argument('--base',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args();shutil.copytree(a.base,a.output,dirs_exist_ok=True)
path=a.output/'TW1_00.data';before=entries(path.read_bytes());assets=dict(before);name='assets/xml/int_buildings.txt';ui=E.fromstring(decode(assets[name]));market=ui.find('marketplace');children=market.find('children');removed=['rgamountheader','rga0','rgb0','rgb0m','rgs0','rgs0m']
for tag in removed:
 node=children.find(tag);assert node is not None,tag;children.remove(node)
market.find('height').text='205';children.find('frame/height').text='205'
for tag in ['market_menu','trade_menu']:ui.find(tag+'/y').text='265'
assert ui.find('trade_menu/children/rga0') is not None
assert ui.findtext('trade_menu/children/action/onlclick')=='trade'
assert int(ui.findtext('market_menu/y'))==int(market.findtext('y'))+205+20
assets[name]=encode(E.tostring(ui,encoding='ascii',xml_declaration=False));path.write_bytes(pack([(n,assets[n])for n,_ in before]));after=dict(entries(path.read_bytes()));assert all(after[n]==b for n,b in before if n!=name)
exe='TradewindsClassic_100Ships_2xHull_ShipyardCatalog_TEST.exe';assert (a.output/exe).read_bytes()==(a.base/exe).read_bytes()
(a.output/'clean-market-manifest.json').write_text(json.dumps(dict(version='v19',removed_controls=removed,scope='Only int_buildings UI resource changed; executable and other resources identical to v18',market_height=205,menu_y=265,startup_log_version='v18 (unchanged executable)'),indent=2)+'\n');print('Upper shortcuts removed; lower Tea row retained; 20-pixel menu gap verified')
