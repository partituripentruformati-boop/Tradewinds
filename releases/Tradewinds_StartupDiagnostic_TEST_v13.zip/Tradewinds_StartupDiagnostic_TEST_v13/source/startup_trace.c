/* Diagnostic only: preserve gameplay while logging actual native UI creation. */
typedef unsigned int U;
#define SC __attribute__((stdcall))
#define FN(a,t) (*(t *)(a))
typedef U (SC *Open)(const char *,U,U,void *,U,U,U);
typedef U (SC *Write)(U,const void *,U,U *,void *);
typedef U (SC *One)(U);
typedef U (SC *Filter)(void *);
typedef Filter (SC *Install)(Filter);
static U handle, initialized;
static Filter previous;
typedef U (SC *Query)(const void *,void *,U);
static Query query;

static void record(const char *p,U n) {
 U written;if(handle&&handle!=~0u){FN(0x452194,Write)(handle,p,n,&written,0);FN(0x45203c,One)(handle);}
}
static U text(char *out,const char *p,U max) {U n=0;if(p)while(n<max&&p[n]){out[n]=p[n];n++;}return n;}
static void hex(char *p,U v) {for(U i=0;i<8;i++)p[i]="0123456789ABCDEF"[(v>>(28-i*4))&15];}
static void field(const char *label,U value) {char b[64];U n=text(b,label,48);hex(b+n,value);n+=8;b[n++]='\r';b[n++]='\n';record(b,n);}
static U SC crash(void *exception) {
 U *e=*(U **)exception;char b[]="CRASH code=00000000 address=00000000\r\n";
 if(e){hex(b+11,e[0]);hex(b+28,e[3]);record(b,sizeof(b)-1);}
 if(e&&e[5]>=2){field("ACCESS=",e[6]);field("FAULT=",e[7]);}
 U *ctx=((U **)exception)[1];
 if(ctx){field("EIP=",ctx[46]);field("ESP=",ctx[49]);field("EBP=",ctx[45]);field("EAX=",ctx[44]);field("ECX=",ctx[43]);field("EDX=",ctx[42]);
  U *sp=(U *)ctx[49];U mbi[7];
  if(query&&query(sp,mbi,sizeof(mbi))==sizeof(mbi)&&mbi[4]==0x1000&&!(mbi[5]&0x101)){
   for(U i=0;i<32&&(U)(sp+i+1)<=mbi[0]+mbi[3];i++)field("STACK=",sp[i]);
  }
 }
 return previous?previous(exception):0;
}
void startup_trace(void *node) {
 if(!initialized){initialized=1;handle=FN(0x452038,Open)("Tradewinds-startup.log",0x40000000,3,0,2,0x80,0);previous=FN(0x452188,Install)(crash);typedef U (SC *Module)(const char *);typedef void *(SC *Proc)(U,const char *);
 query=(Query)FN(0x45215c,Proc)(FN(0x452158,Module)("kernel32.dll"),"VirtualQuery");
 record("Tradewinds v13 diagnostic: UI and building construction\r\n",55);}
 char b[512];U n=text(b,"BEGIN ",6);void *parents[16];U count=0;
 while(node&&count<16){parents[count++]=node;node=*(void **)((char *)node+0x10);}
 while(count&&n<480){void *p=parents[--count];b[n++]='/';n+=text(b+n,*(const char **)((char *)p+4),480-n);}
 b[n++]='\r';b[n++]='\n';record(b,n);
}

void startup_stage(U address) {field("CONSTRUCT=",address);}
