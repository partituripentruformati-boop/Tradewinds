"""Execute diagnostic machine code, checking stack, log I/O, and crash records."""
from pathlib import Path
import argparse,json,struct
import pefile
from unicorn import Uc,UC_ARCH_X86,UC_MODE_32,UC_HOOK_CODE
from unicorn.x86_const import *
p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True);a=p.parse_args()
pe=pefile.PE(str(a.output/'TradewindsClassic_100Ships_2xHull_ShipyardCatalog_TEST.exe'));symbols=json.loads((a.output/'startup-trace-manifest.json').read_text())['symbols']
class Machine:
 def __init__(self,fail=False):
  self.u=Uc(UC_ARCH_X86,UC_MODE_32)
  for x,n in [(0x400000,0x100000),(0x200000,0x10000),(0x300000,0x20000)]:self.u.mem_map(x,n)
  self.u.mem_write(0x400000,pe.get_memory_mapped_image());self.logs=[];self.opens=0;self.flushes=0;self.filter=0;self.fail=fail;self.target=0
  for x,t in [(0x452038,0x490010),(0x452194,0x490020),(0x45203c,0x490030),(0x452188,0x490040),(0x452158,0x490050),(0x45215c,0x490060)]:self.w(x,t)
  self.u.hook_add(UC_HOOK_CODE,self.hook)
 def w(self,x,n):self.u.mem_write(x,struct.pack('<I',n))
 def r(self,x):return struct.unpack('<I',self.u.mem_read(x,4))[0]
 def ret(self,n,v):
  s=self.u.reg_read(UC_X86_REG_ESP);self.u.reg_write(UC_X86_REG_EIP,self.r(s));self.u.reg_write(UC_X86_REG_ESP,s+4+n);self.u.reg_write(UC_X86_REG_EAX,v)
 def hook(self,u,x,n,_):
  s=u.reg_read(UC_X86_REG_ESP)
  if x in [0x401c46,0x49f000,self.target]:u.emu_stop()
  elif x==0x490010:self.opens+=1;self.ret(28,0xffffffff if self.fail else 7)
  elif x==0x490020:
   assert self.r(s+4)==7;self.logs.append(bytes(u.mem_read(self.r(s+8),self.r(s+12))));self.w(self.r(s+16),self.r(s+12));self.ret(20,1)
  elif x==0x490030:self.flushes+=1;self.ret(4,1)
  elif x==0x490050:self.ret(4,1)
  elif x==0x490060:
   ptr=self.r(s+8);name=bytes(u.mem_read(ptr,32)).split(b'\0')[0]
   self.ret(8,{'VirtualQuery':0x490070,'GetCurrentThreadId':0x490080,'GetModuleFileNameA':0x490090}[name.decode()])
  elif x==0x490080:self.ret(0,123)
  elif x==0x490090:
   name=b'C:\\Windows\\System32\\ntdll.dll\0';u.mem_write(self.r(s+8),name);self.ret(12,len(name)-1)
  elif x==0x490070:
   address=self.r(s+4);dest=self.r(s+8)
   for i,v in enumerate([address&~4095,0,4,4096,0x1000,4,0x20000]):self.w(dest+i*4,v)
   if address==0x778f4ec6:self.w(dest+4,0x77800000);self.w(dest+24,0x1000000)
   self.ret(12,28)
  elif x==0x490040:self.filter=self.r(s+4);self.ret(4,0)
 def node(self,x,name,parent=0):
  self.w(x,len(name));self.w(x+4,x+0x40);self.w(x+0x10,parent);self.u.mem_write(x+0x40,name.encode()+b'\0')
 def creation(self,node,sp):
  registers=[UC_X86_REG_EAX,UC_X86_REG_EBX,UC_X86_REG_ECX,UC_X86_REG_EDX,UC_X86_REG_ESI,UC_X86_REG_EDI]
  for i,r in enumerate(registers):self.u.reg_write(r,0xabc000+i)
  self.u.reg_write(UC_X86_REG_EBP,0x12345678);self.u.reg_write(UC_X86_REG_ESP,sp);self.w(sp,0x49f000);self.w(sp+4,node)
  self.u.emu_start(0x401c40,0x49f000,count=100000)
  assert self.u.reg_read(UC_X86_REG_EIP)==0x401c46
  assert self.u.reg_read(UC_X86_REG_ESP)==(sp-4)&~7
  assert self.u.reg_read(UC_X86_REG_EBP)==sp-4
  assert self.r(sp-4)==0x12345678
  for i,r in enumerate(registers):assert self.u.reg_read(r)==0xabc000+i
m=Machine();m.node(0x200000,'int_buildings');m.node(0x200100,'marketplace',0x200000);m.node(0x200200,'rgb0',0x200100)
m.creation(0x200200,0x318000);assert m.logs[-1]==b'BEGIN /int_buildings/marketplace/rgb0\r\n'
m.creation(0x200100,0x318004);assert m.opens==1 and m.flushes==3
m.w(0x200400,0x200500);m.w(0x200500,0xc0000005);m.w(0x20050c,0x405123)
m.u.reg_write(UC_X86_REG_ESP,0x318000);m.w(0x318000,0x49f000);m.w(0x318004,0x200400);m.u.emu_start(m.filter,0x49f000,count=100000)
assert b'CRASH code=C0000005 address=00405123\r\n' in m.logs;assert m.u.reg_read(UC_X86_REG_ESP)==0x318008
f=Machine(True);f.creation(0,0x318000);assert not f.logs
m.w(0x20050c,0x778f4ec6);m.w(0x200404,0x200600);m.w(0x200510,2);m.w(0x200514,1);m.w(0x200518,0x1234)
for i,v in [(46,0x778f4ec6),(49,0x310000),(45,0x310020),(44,7),(43,8),(42,9)]:m.w(0x200600+i*4,v)
for i in range(32):m.w(0x310000+i*4,0x400000+i)
m.u.reg_write(UC_X86_REG_ESP,0x318000);m.w(0x318000,0x49f000);m.w(0x318004,0x200400);m.u.emu_start(m.filter,0x49f000,count=100000)
assert b'FAULT=00001234\r\n' in m.logs and b'EIP=778F4EC6\r\n' in m.logs
assert b'STACK=0040001F\r\n' in m.logs
assert sum(x.startswith(b'STACK=') for x in m.logs)==256
assert b'CRASH_THREAD=0000007B\r\n' in m.logs
assert any(x.startswith(b'778F4EC6 77800000 ') and b'ntdll.dll' in x for x in m.logs)
for name,address in symbols.items():
 if name.startswith('stage_'):
  t=Machine();t.creation(0,0x318000);target=int(name.split('_')[1],16);t.target=target
  t.u.reg_write(UC_X86_REG_ESP,0x318000);t.w(0x318000,0x49f000);t.u.reg_write(UC_X86_REG_ECX,0xabcdef01);t.u.reg_write(UC_X86_REG_EAX,0x12345678)
  t.u.emu_start(address,0x49f000,count=100000)
  assert t.u.reg_read(UC_X86_REG_EIP)==target and t.u.reg_read(UC_X86_REG_ESP)==0x318000
  assert t.u.reg_read(UC_X86_REG_ECX)==0xabcdef01 and t.u.reg_read(UC_X86_REG_EAX)==0x12345678
print('8 diagnostic checks passed: native stack/registers, parent path, one-time initialization, flushed crash report, unwritable-folder fallback')
