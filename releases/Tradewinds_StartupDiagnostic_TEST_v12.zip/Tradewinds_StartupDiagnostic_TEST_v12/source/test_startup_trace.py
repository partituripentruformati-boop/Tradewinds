"""Execute diagnostic machine code, checking stack, log I/O, and crash records."""
from pathlib import Path
import argparse,json,struct
import pefile
from unicorn import Uc,UC_ARCH_X86,UC_MODE_32,UC_HOOK_CODE
from unicorn.x86_const import *
p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True);a=p.parse_args()
pe=pefile.PE(str(a.output/'TradewindsClassic_100Ships_2xHull_ShipyardCatalog_TEST.exe'));symbols=json.loads((a.output/'startup-trace-manifest.json').read_text())['symbols']
class Machine:
 def __init__(self,fail=False):
  self.u=Uc(UC_ARCH_X86,UC_MODE_32)
  for x,n in [(0x400000,0x100000),(0x200000,0x10000),(0x300000,0x20000)]:self.u.mem_map(x,n)
  self.u.mem_write(0x400000,pe.get_memory_mapped_image());self.logs=[];self.opens=0;self.flushes=0;self.filter=0;self.fail=fail
  for x,t in [(0x452038,0x490010),(0x452194,0x490020),(0x45203c,0x490030),(0x452188,0x490040)]:self.w(x,t)
  self.u.hook_add(UC_HOOK_CODE,self.hook)
 def w(self,x,n):self.u.mem_write(x,struct.pack('<I',n))
 def r(self,x):return struct.unpack('<I',self.u.mem_read(x,4))[0]
 def ret(self,n,v):
  s=self.u.reg_read(UC_X86_REG_ESP);self.u.reg_write(UC_X86_REG_EIP,self.r(s));self.u.reg_write(UC_X86_REG_ESP,s+4+n);self.u.reg_write(UC_X86_REG_EAX,v)
 def hook(self,u,x,n,_):
  s=u.reg_read(UC_X86_REG_ESP)
  if x in [0x401c46,0x49f000]:u.emu_stop()
  elif x==0x490010:self.opens+=1;self.ret(28,0xffffffff if self.fail else 7)
  elif x==0x490020:
   assert self.r(s+4)==7;self.logs.append(bytes(u.mem_read(self.r(s+8),self.r(s+12))));self.w(self.r(s+16),self.r(s+12));self.ret(20,1)
  elif x==0x490030:self.flushes+=1;self.ret(4,1)
  elif x==0x490040:self.filter=self.r(s+4);self.ret(4,0)
 def node(self,x,name,parent=0):
  self.w(x,len(name));self.w(x+4,x+0x40);self.w(x+0x10,parent);self.u.mem_write(x+0x40,name.encode()+b'\0')
 def creation(self,node,sp):
  registers=[UC_X86_REG_EAX,UC_X86_REG_EBX,UC_X86_REG_ECX,UC_X86_REG_EDX,UC_X86_REG_ESI,UC_X86_REG_EDI]
  for i,r in enumerate(registers):self.u.reg_write(r,0xabc000+i)
  self.u.reg_write(UC_X86_REG_EBP,0x12345678);self.u.reg_write(UC_X86_REG_ESP,sp);self.w(sp,0x49f000);self.w(sp+4,node)
  self.u.emu_start(0x401c40,0x49f000,count=100000)
  assert self.u.reg_read(UC_X86_REG_EIP)==0x401c46
  assert self.u.reg_read(UC_X86_REG_ESP)==(sp-4)&~7
  assert self.u.reg_read(UC_X86_REG_EBP)==sp-4
  assert self.r(sp-4)==0x12345678
  for i,r in enumerate(registers):assert self.u.reg_read(r)==0xabc000+i
m=Machine();m.node(0x200000,'int_buildings');m.node(0x200100,'marketplace',0x200000);m.node(0x200200,'rgb0',0x200100)
m.creation(0x200200,0x318000);assert m.logs[-1]==b'BEGIN /int_buildings/marketplace/rgb0\r\n'
m.creation(0x200100,0x318004);assert m.opens==1 and m.flushes==3
m.w(0x200400,0x200500);m.w(0x200500,0xc0000005);m.w(0x20050c,0x405123)
m.u.reg_write(UC_X86_REG_ESP,0x318000);m.w(0x318000,0x49f000);m.w(0x318004,0x200400);m.u.emu_start(m.filter,0x49f000,count=100000)
assert m.logs[-1]==b'CRASH code=C0000005 address=00405123\r\n';assert m.u.reg_read(UC_X86_REG_ESP)==0x318008
f=Machine(True);f.creation(0,0x318000);assert not f.logs
print('5 diagnostic checks passed: native stack/registers, parent path, one-time initialization, flushed crash report, unwritable-folder fallback')
