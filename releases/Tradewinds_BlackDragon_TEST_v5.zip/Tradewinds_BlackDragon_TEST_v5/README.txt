Tradewinds Classic - Shipyard Catalog TEST patch v5

WHAT CHANGES
v5 corrects the v4 disappearing-ship bug. The game groups fleet ships by
native type pointer identity. V4's visual shadow changed that pointer, so
the native grouping routine skipped Black Dragon during shipyard refresh
and combat setup. V5 keeps the actual ship model and type pointer untouched;
only the sidebar/ship-information icon and cached combat drawing sprites
select Black Dragon artwork. Original value calculation is restored.

Transparency masks and combat sheets now use indexed PNG, matching the
original game's assets. The grayscale masks in v4 used a different channel
layout from the graphics loader's expected expanded four-byte pixels.

Black sails, red dragon emblems and gold trim follow the supplied reference.
Combat includes animation and intact, damaged and heavily damaged states.
The targeting is a Juggernaut named exactly Black Dragon. Renaming the ship
changes the artwork selection on its next display initialization.
Other ships, all stats and the saved megaship identifier remain original.

Install both files below, then reload your game. Keep backups of all save
slots. If the ship is absent after reloading, use a save from before the
v4 disappearance. This patch does not rewrite save files or recreate ships.

This package retains the working shipyard and maximum-cannon features.

v3 adds Buy max cannons (affordable) to the selected owned ship options.
Click a fleet ship at the shipyard, then click that button once. It buys
as many cannons as current gold and free cargo space permit, using the
current cannon price. Each cannon uses 10 cargo units. Existing cargo
is retained. This spends gold immediately, just like buying one cannon.
The original single-cannon purchase button remains.

v2 fixes missing command registration that caused Unknown command: yard_*
messages. The catalog uses aligned ship-type/cargo columns, separate Buy
buttons and a repair/leave footer. Purchase price remains in the preview.

The shipyard menu offers all five types defined in your supplied game data:
Junk, One-Masted Sloop, Two-Masted Sloop, Brigantine, and Juggernaut.
Select a type to open the existing ship preview and purchase confirmation.
A successful purchase generates a new offer of the same type immediately.
The random check for whether a ship appears is removed. Gold checks and the
existing 100-ship limit remain. Other executable changes in the supplied
100Ships_2xHull_TEST build are retained.

INSTALL
1. Close the game. Back up the entire game folder, including save.tw0,
   save.tw1 and save.tw2, and keep the original TW1_00.data.
2. Copy this package's TW1_00.data and
   TradewindsClassic_100Ships_2xHull_ShipyardCatalog_TEST.exe into your existing
   game folder. The new TW1_00.data replaces the original data file.
3. Launch the new executable from that folder. It requires the other original
   game files, including TW1_01.data and the DLLs already in the game folder.
   Do not rename or overwrite your original executable.
4. If updating an earlier patch, replace BOTH the executable and TW1_00.data, then restart.
   Enter a shipyard. Each ship type should have its own Buy button.
   Choose a type, inspect the preview and price, then confirm or cancel.

IN-GAME CHECKS STILL REQUIRED
Use a backed-up save or a test game. For bulk cannons, test with ample gold,
limited gold and a full cargo hold. Check the cannon count and gold spent.
 Verify all five choices display the
correct type; buy the same type twice without travelling; try insufficient
gold; leave and revisit; save, exit and reload. Check repairs still work.
At 100 ships further catalog purchases are blocked; after selling a ship,
select a catalog type again to obtain a new offer.

VALIDATION AND LIMITS
78 automated checks passed using x86 emulation with engine and Windows calls
stubbed, plus PE and encoded-archive integrity checks. These validate injected
control flow, catalog selections, restock hooks, stack balance, the native
purchase affordability checks and fleet limit. They do not establish full
gameplay correctness. No Windows runtime is installed here, so game startup,
menu rendering, complete purchases and save/load have not been tested.
This is a TEST build, not a gameplay-verified release. No save files or
registry settings were modified.

ROLLBACK
Close the game, restore the original TW1_00.data from your backup, and launch
your original executable. Restore your backed-up saves if needed. The patched
executable and patched data file must be used together.

REPRODUCING
The source/ folder includes the x86 assembly, patch builder and tests.
Requires Python 3, GNU binutils (as, ld, objcopy, nm), pefile and unicorn.
Install the pinned Python dependencies from source/requirements-dev.txt.
Run:
python source/build_patch.py ORIGINAL_EXE ORIGINAL_TW1_00.data --output output
python source/test_patch.py --output output --original-data ORIGINAL_TW1_00.data
The builder checks the executable's SHA-256 and expected bytes before patching.

V5 VALIDATION
78 x86 emulation, archive and graphics checks passed. Engine calls are
stubbed; this is a Windows TEST build. Please check the Black Dragon icon,
combat animation, damage transitions and save/reload in the actual game.
Preview PNGs are included for reference; only the EXE and TW1_00.data
need to be copied into the original game folder.
