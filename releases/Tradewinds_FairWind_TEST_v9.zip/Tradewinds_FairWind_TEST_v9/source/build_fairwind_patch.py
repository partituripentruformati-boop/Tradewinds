"""Build v9 with all regional features plus registered Fair Wind artwork/stats."""
from pathlib import Path
import argparse,copy,hashlib,json,struct,subprocess,sys,tempfile,xml.etree.ElementTree as ET
import pefile
from capstone import Cs,CS_ARCH_X86,CS_MODE_32
ROOT=Path(__file__).resolve().parent
parser=argparse.ArgumentParser();parser.add_argument('--base-v7',type=Path,required=True);parser.add_argument('--output',type=Path,required=True);args=parser.parse_args()
subprocess.run([sys.executable,str(ROOT/'build_regional_patch.py'),'--base',str(args.base_v7),'--output',str(args.output)],check=True)
args.output.mkdir(exist_ok=True);exe=args.output/'TradewindsClassic_100Ships_2xHull_ShipyardCatalog_TEST.exe'
base=json.loads((args.base_v7/'patch-manifest.json').read_text());(args.output/'patch-manifest.json').write_text(json.dumps(base,indent=2)+'\n')
b=bytearray(exe.read_bytes());pe=pefile.PE(data=b);section=pe.sections[-1];address=(0x400000+section.VirtualAddress+section.Misc_VirtualSize+15)&~15
with tempfile.TemporaryDirectory(prefix='fairwind-build-') as directory:
 d=Path(directory)
 subprocess.run(['as','--32','--defsym',f'DRAGON_SELECTOR={base["symbols"]["dragon_visual_type"]}','--defsym','DRAGON_LOOKUP=0x423210',str(ROOT/'fairwind.s'),'-o',str(d/'art.o')],check=True)
 subprocess.run(['ld','-m','elf_i386','-Ttext',hex(address),'--entry','fairwind_visual_type',str(d/'art.o'),'-o',str(d/'art.elf')],check=True)
 subprocess.run(['objcopy','-O','binary','--only-section=.text',str(d/'art.elf'),str(d/'art.bin')],check=True)
 code=(d/'art.bin').read_bytes()
assert address+len(code)<=0x400000+section.VirtualAddress+section.SizeOfRawData
pos=section.PointerToRawData+address-0x400000-section.VirtualAddress
assert b[pos:pos+len(code)]==bytes(len(code));b[pos:pos+len(code)]=code
struct.pack_into('<I',b,section.get_field_absolute_offset('Misc_VirtualSize'),address+len(code)-0x400000-section.VirtualAddress)
changes=[];yard=next(s for s in pe.sections if s.VirtualAddress==0x70000)
instructions=[]
for name in ['dragon_icon','dragon_combat','dragon_capacity']:
 start=base['symbols'][name];off=pe.get_offset_from_rva(start-0x400000)
 instructions.extend(Cs(CS_ARCH_X86,CS_MODE_32).disasm(bytes(b[off:off+40]),start))
for instruction in {i.address:i for i in instructions}.values():
 if instruction.mnemonic=='call' and instruction.op_str==hex(base['symbols']['dragon_visual_type']):
  off=pe.get_offset_from_rva(instruction.address-0x400000);before=bytes(b[off:off+5]);after=b'\xe8'+struct.pack('<i',address-instruction.address-5);b[off:off+5]=after
  changes.append(dict(address=hex(instruction.address),before=before.hex(),after=after.hex()))
assert len(changes)==3,changes
new_pe=pefile.PE(data=bytes(b));struct.pack_into('<I',b,new_pe.OPTIONAL_HEADER.get_field_absolute_offset('CheckSum'),new_pe.generate_checksum());exe.write_bytes(b)
key=b'klxd8794lkds87934poi'
def decode(p):return bytes((v-key[i%len(key)])%256 for i,v in enumerate(p))
def encode(p):return bytes((v+key[i%len(key)])%256 for i,v in enumerate(p))
data=(args.output/'TW1_00.data').read_bytes();pos=8;entries=[]
for _ in range(struct.unpack_from('<I',data,4)[0]):
 end=data.index(0,pos);name=data[pos:end].decode();off,n=struct.unpack_from('<II',data,end+1);entries.append((name,data[off:off+n]));pos=end+9
assets=dict(entries);ships=ET.fromstring(decode(assets['assets/xml/ships.txt']));variant=copy.deepcopy(ships.find('types/onemast'));variant.tag='fairwind_visual'
variant.find('cargo').text='250';variant.find('hitpoints').text=str(int(variant.findtext('hitpoints'))*2)
for el in variant.iter():
 if el.text:
  el.text=el.text.replace('fleetstat_sloop','fleetstat_fairwind')
  if el.tag.startswith(('sprite','allysprite','enemysprite')):el.text=el.text.replace('sloop','fairwind',1)
ships.find('types').append(variant)
sprites=ET.fromstring(decode(assets['assets/xml/sprites.txt']));original=list(sprites)
for el in original:
 name=el.get('name','')
 if name in ['onemast_page','onemast_ally_page','onemast_enemy_page'] or name in [f'sloop{p}{i}' for p in ['', '_ally','_enemy'] for i in range(3)]:
  clone=copy.deepcopy(el);clone.set('name',name.replace('onemast','fairwind',1).replace('sloop','fairwind',1))
  enemy='enemy' in name;w,h=(66,50) if enemy else (95,72)
  if clone.tag=='spritepage':
   stem='el_fairwind' if enemy else 'fl_fairwind';clone.find('bitmap').text=f'assets/graphics/combatview/ships/{stem}.png';clone.find('alphamap').text=f'assets/graphics/combatview/ships/{stem}_alpha.png';clone.find('framewidth').text=str(w);clone.find('frameheight').text=str(h)
  else:clone.find('spritepage').text=clone.findtext('spritepage').replace('onemast','fairwind',1);clone.set('xoffset',str(w//2));clone.set('yoffset',str(h))
  sprites.append(clone)
characters=ET.fromstring(decode(assets['assets/xml/characters.txt']));characters.find('douglas/fleet/onemast').tag='fairwind_visual'
for name,tree in [('ships',ships),('sprites',sprites),('characters',characters)]:assets[f'assets/xml/{name}.txt']=encode(ET.tostring(tree,encoding='ascii'))
entries=[(name,assets[name]) for name,_ in entries]
for name in ['fleetstat_fairwind.jpg','fleetstat_fairwind_alpha.png','fl_fairwind.png','fl_fairwind_alpha.png','el_fairwind.png','el_fairwind_alpha.png']:
 folder='ui/hud/' if name.startswith('fleetstat') else 'combatview/ships/';entries.append(('assets/graphics/'+folder+name,(ROOT/'fairwind-assets'/name).read_bytes()))
pos=8+sum(len(name.encode())+9 for name,_ in entries);directory=bytearray(struct.pack('<II',0xdcac,len(entries)));payloads=bytearray()
for name,payload in entries:directory+=name.encode()+b'\0'+struct.pack('<II',pos,len(payload));payloads+=payload;pos+=len(payload)
(args.output/'TW1_00.data').write_bytes(directory+payloads)
report=dict(version='v9',selector_address=address,selector_bytes=len(code),redirects=changes,cargo=250,max_cannons=25,hull_xml=30,hull_engine=60,player_frame=[95,72],enemy_frame=[66,50],validation='Windows playtest pending',outputs={name:hashlib.sha256((args.output/name).read_bytes()).hexdigest() for name in [exe.name,'TW1_00.data']})
(args.output/'fairwind-manifest.json').write_text(json.dumps(report,indent=2)+'\n');print('Built Fair Wind v9:',args.output)
