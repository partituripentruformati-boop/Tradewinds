import unittest
from test_spices import SpiceMachine
from test_regional_runtime import PLAYER,MARKET,PORTS,SYMS
from unicorn.x86_const import UC_X86_REG_ESP
class CashMachine(SpiceMachine):
 def __init__(self):
  super().__init__();self.cash_controls=[0x238000,0x238080];self.setgold(5000000000)
  for i,p in enumerate(self.cash_controls):self.w(p,0x220000);self.w(PLAYER+0x34+i*4,p);self.texts[p]=f'{self.gold():,}'
 def hook(self,u,a,n,user):
  if a==0x414760:return # Execute the real native function: zero amount skips UI refresh.
  if a==0x413ea0:
   sp=u.reg_read(UC_X86_REG_ESP);dest=self.r(sp+4);value=self.r(sp+8)+(self.r(sp+12)<<32);self.string(dest,f'{value:,}');self.ret(0,dest)
  else:super().hook(u,a,n,user)
 def assert_cash(self,test):
  for p in self.cash_controls:test.assertEqual(self.texts[p],f'{self.gold():,}')
class CashDisplayTests(unittest.TestCase):
 def test_tea_and_spices_purchase_debit_and_visible_cash_fleet_and_warehouse(self):
  for i in range(2):
   for ware in [False,True]:
    m=CashMachine();m.w(PORTS+0x1c,m.ports[i]);m.u.mem_write(MARKET+0x99,bytes([ware,1]));m.setinput(i,7);before=m.gold();m.lower('trade');price=m.r(SYMS['rg_prices']+i*4);self.assertEqual(m.gold(),before-7*price);m.assert_cash(self)
 def test_sales_credit_and_refresh_both_cash_fields(self):
  for i in range(2):
   m=CashMachine();m.w(m.q(m.ships[0])+i*4,10);m.u.mem_write(MARKET+0x9a,b'\0\1');m.setinput(i,3);before=m.gold();m.lower('trade');price=m.r(SYMS['rg_prices']+i*4);self.assertEqual(m.gold(),before+3*price);m.assert_cash(self)
 def test_sell_all_both_goods_refreshes_final_cash(self):
  m=CashMachine();m.w(m.q(m.ships[0]),5);m.w(m.q(m.ships[0])+4,7);before=m.gold();m.lower('sell_all');expected=before+5*m.r(SYMS['rg_prices'])+7*m.r(SYMS['rg_prices']+4);self.assertEqual(m.gold(),expected);m.assert_cash(self)
 def test_spending_exact_available_gold_displays_zero(self):
  for i in range(2):
   m=CashMachine();m.w(PORTS+0x1c,m.ports[i]);m.call('rg_prices_refresh');price=m.r(SYMS['rg_prices']+i*4);m.setgold(7*price)
   for p in m.cash_controls:m.texts[p]=f'{m.gold():,}'
   m.u.mem_write(MARKET+0x9a,b'\1');m.setinput(i,7);m.lower('trade');self.assertEqual(m.gold(),0);m.assert_cash(self)
 def test_native_zero_subtraction_does_not_refresh_display_or_change_balance(self):
  m=CashMachine();m.setgold(m.gold()-100);before=m.gold();stale=m.texts[m.cash_controls[0]];m.native(0x414760,0,0,owner=PLAYER);self.assertEqual(m.gold(),before);self.assertEqual(m.texts[m.cash_controls[0]],stale);self.assertNotEqual(stale,f'{before:,}')
if __name__=='__main__':unittest.main(argv=[__file__],verbosity=2)
