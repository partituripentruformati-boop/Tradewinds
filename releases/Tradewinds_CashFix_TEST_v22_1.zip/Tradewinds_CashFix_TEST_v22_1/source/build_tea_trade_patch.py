"""Reproduce v18 from the SHA-checked working v7 baseline."""
from pathlib import Path
import argparse,subprocess,sys,tempfile
p=argparse.ArgumentParser();p.add_argument('--base-v7',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args();root=Path(__file__).resolve().parent
with tempfile.TemporaryDirectory() as td:
 base=Path(td)/'base';layout=Path(td)/'layout'
 for script,args in [('build_fairwind_patch.py',['--base-v7',a.base_v7,'--output',base]),('build_market_layout.py',['--base',base,'--output',layout]),('add_tea_trade_row.py',['--output',layout]),('build_startup_trace.py',['--base',layout,'--output',a.output])]:subprocess.run([sys.executable,str(root/script),*map(str,args)],check=True)
