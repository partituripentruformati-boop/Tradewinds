"""Close virtual section gaps without relocating game code or changing assets."""
from pathlib import Path
import argparse,hashlib,json,struct,shutil
import pefile

def validate(data):
 p=pefile.PE(data=data);align=p.OPTIONAL_HEADER.SectionAlignment
 expected=(p.OPTIONAL_HEADER.SizeOfHeaders+align-1)//align*align
 for section in p.sections:
  assert section.VirtualAddress==expected,(section.Name,hex(section.VirtualAddress),hex(expected))
  assert section.PointerToRawData%p.OPTIONAL_HEADER.FileAlignment==0
  assert section.PointerToRawData+section.SizeOfRawData<=len(data)
  expected=section.VirtualAddress+((max(section.Misc_VirtualSize,section.SizeOfRawData)+align-1)//align*align)
 assert expected==p.OPTIONAL_HEADER.SizeOfImage
 assert p.OPTIONAL_HEADER.CheckSum==p.generate_checksum()
 assert p.FILE_HEADER.Machine==0x14c and p.OPTIONAL_HEADER.Magic==0x10b
 return p

def fix(data):
 p=pefile.PE(data=data);b=bytearray(data);changes=[]
 for current,following in zip(p.sections,p.sections[1:]):
  align=p.OPTIONAL_HEADER.SectionAlignment
  end=current.VirtualAddress+((max(current.Misc_VirtualSize,current.SizeOfRawData)+align-1)//align*align)
  assert end<=following.VirtualAddress,'Overlapping sections'
  if end<following.VirtualAddress:
   offset=current.get_field_absolute_offset('Misc_VirtualSize');value=following.VirtualAddress-current.VirtualAddress
   changes.append(dict(section=current.Name.rstrip(b'\0').decode(),offset=offset,before=current.Misc_VirtualSize,after=value))
   struct.pack_into('<I',b,offset,value)
 checksum=p.OPTIONAL_HEADER.get_field_absolute_offset('CheckSum')
 new=pefile.PE(data=bytes(b));struct.pack_into('<I',b,checksum,new.generate_checksum())
 validate(bytes(b))
 allowed={x for c in changes for x in range(c['offset'],c['offset']+4)}|set(range(checksum,checksum+4))
 assert len(b)==len(data) and all(x in allowed for x,(old,new) in enumerate(zip(data,b)) if old!=new)
 return bytes(b),changes
if __name__=='__main__':
 parser=argparse.ArgumentParser();parser.add_argument('--base',type=Path,required=True);parser.add_argument('--output',type=Path,required=True);args=parser.parse_args()
 shutil.copytree(args.base,args.output,dirs_exist_ok=True)
 exe=args.output/'TradewindsClassic_100Ships_2xHull_ShipyardCatalog_TEST.exe'
 original=exe.read_bytes();patched,changes=fix(original);exe.write_bytes(patched)
 (args.output/'loader-fix-manifest.json').write_text(json.dumps(dict(input_sha256=hashlib.sha256(original).hexdigest(),output_sha256=hashlib.sha256(patched).hexdigest(),changes=changes,validation='Contiguous PE sections, checksum, raw ranges and unchanged machine code/assets; Windows execution untested'),indent=2)+'\n')
 print('Corrected PE layout:',changes)
