from pathlib import Path
import argparse,copy,json,xml.etree.ElementTree as E
from fix_xml_format import entries,pack,decode,encode
TIP="Looking for Spices, my friend? Only Lama Sut's market sells them, but traders in every port will buy them from you."
p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True);a=p.parse_args();path=a.output/'TW1_00.data';assets=entries(path.read_bytes());m=dict(assets);name='assets/xml/int_buildings.txt';u=E.fromstring(decode(m[name]))
def setv(n,k,v):
 e=n.find(k)
 if e is None:e=E.SubElement(n,k)
 e.text=str(v)
def move(c,tag,y):setv(c.find(tag),'y',y)
def clone(c,old,new,y,kind=''):
 n=copy.deepcopy(c.find(old));n.tag=new;setv(n,'y',y)
 if kind=='icon':n.find('bitmap').set('bitmap','assets/graphics/ui/popup/icon_spices.png');setv(n,'x',10)
 if kind=='name':setv(n,'text','Spices')
 click=n.find('onlclick')
 if click is not None:click.text=click.text.replace('rg0','rg1').replace('rw0','rw1')
 c.append(n)
c=u.find('marketplace/children');setv(u.find('marketplace'),'height',225);setv(c.find('frame'),'height',225)
for i,y in [(1,48),(2,132),(3,160),(4,188)]:
 move(c,'icon'+str(i),y)
 for pfx in ['item','value','qty']:move(c,pfx+str(i),y+5)
for old,new,y,kind in [('rgicon0','rgicon1',104,'icon'),('rgn0','rgn1',109,'name'),('rgp0','rgp1',109,''),('rgq0','rgq1',109,'')]:clone(c,old,new,y,kind)
for n in ['market_menu','trade_menu']:setv(u.find(n),'y',280)
w=u.find('trade_menu');c=w.find('children');setv(w,'height',205);setv(c.find('topframe'),'height',205)
for i,y in [(1,5),(2,80),(3,105),(4,130)]:
 for pfx in ['icon','item','qty_decrease','qty_edit','qty_increase','maxout']:move(c,pfx+str(i),y if pfx in ['icon','qty_edit']else y+5)
for old,new,y,kind in [('rticon0','rticon1',55,'icon'),('rtname0','rtname1',60,'name'),('rga0','rga1',55,''),('rtdec0','rtdec1',60,''),('rtinc0','rtinc1',60,''),('rtmax0','rtmax1',60,'')]:clone(c,old,new,y,kind)
move(c,'message',152)
for tag in ['action','sell_all','back']:move(c,tag,175)
w=u.find('warehouse');c=w.find('children');setv(w,'height',445);setv(c.find('fleetframe'),'height',215)
for i,y in [(1,65),(2,137),(3,161),(4,185)]:
 move(c,'icon'+str(i),y)
 for pfx in ['prod','value','qty']:move(c,pfx+str(i),y+5)
move(c,'rgicon0',87)
for tag in ['rgn0','rgw0','rgv0']:move(c,tag,94)
for old,new,y,kind in [('rgicon0','rgicon1',113,'icon'),('rgn0','rgn1',118,'name'),('rgw0','rgw1',118,''),('rgv0','rgv1',118,'')]:clone(c,old,new,y,kind)
for i,y in [(1,235),(2,307),(3,331),(4,355)]:
 for pfx in ['iconb','prodb','dec','edit','inc','max']:move(c,pfx+str(i),y if pfx in ['iconb','edit']else y+5)
for tag,y in [('rwicon0',257),('rwname0',264),('rga0',259),('rwdec0',264),('rwinc0',264),('rwmax0',264)]:move(c,tag,y)
for old,new,y,kind in [('rwicon0','rwicon1',283,'icon'),('rwname0','rwname1',288,'name'),('rga0','rga1',283,''),('rwdec0','rwdec1',288,''),('rwinc0','rwinc1',288,''),('rwmax0','rwmax1',288,'')]:clone(c,old,new,y,kind)
move(c,'transfer',385)
for tag in ['leave','sell']:move(c,tag,415)
m[name]=encode(E.tostring(u,encoding='ascii',xml_declaration=False));pool='assets/xml/alehouse.txt';plain=decode(m[pool]);m[pool]=encode(plain.replace(b'</alehouse>',b'\t<tip>'+TIP.encode()+b'</tip>\r\n</alehouse>'))
icon='assets/graphics/ui/popup/icon_spices.png';m[icon]=(Path(__file__).parent/'regional-goods-assets/icon_spices.png').read_bytes()
path.write_bytes(pack([(n,m[n])for n,_ in assets]+[(icon,m[icon])]))
assert int(u.findtext('trade_menu/y'))+int(u.findtext('trade_menu/height'))<=485
assert int(w.findtext('y'))+int(w.findtext('height'))<=485
assert 175+28<=205 and 415+28<=445
(a.output/'spices-manifest.json').write_text(json.dumps(dict(version='v22',enabled=['Tea','Spices'],spices_base_gold=175,spices_buy_port='lamasut',spices_tip=TIP,save_format_unchanged=True,new_registry_entries=0,order=['General Merchandise','Tea','Spices','Arms','Silk and textiles','Dream Dust']),indent=2)+'\n');print('Spices added to both market and warehouse panels; all panels fit above log')
