"""Fair Wind migration, native grouping, stats, saves and engine graphics tests."""
from pathlib import Path
import json,struct,unittest,xml.etree.ElementTree as ET
from io import BytesIO
from PIL import Image,ImageChops
from unicorn.x86_const import *
from test_regional_runtime import Machine,OUT,SYMS,STACK,STOP,MANAGER
FAIR=json.loads((OUT/'fairwind-manifest.json').read_text())
BASE=json.loads((OUT/'patch-manifest.json').read_text())['symbols']
class FairMachine(Machine):
 def __init__(self):
  self.template=0x216000;self.grouped=[];self.types=[]
  super().__init__();self.fair=self.ships[1];self.typ=self.r(self.fair)
  self.string(self.fair+4,'Fair Wind');self.string(self.typ,'onemast')
  self.w(self.typ+0x18,150);self.w(self.typ+0x20,30);self.w(self.typ+0x1c,12)
  self.w(self.fair+0x10,30);self.w(self.fair+0x14,8)
  self.string(self.template,'fairwind_visual');self.w(self.template+0x18,250);self.w(self.template+0x20,60);self.w(self.template+0x1c,12)
  for offset in range(0x30,0x64,4):self.w(self.template+offset,0x217000+offset)
  self.types=[self.typ,self.template,self.r(self.ships[0])]
 def hook(self,u,a,n,user):
  sp=u.reg_read(UC_X86_REG_ESP);cx=u.reg_read(UC_X86_REG_ECX)
  if a==0x42d390:self.ret(4,int(self.cstr(self.r(cx+4))==self.cstr(self.r(sp+4))))
  elif a==0x423210:
   self.ret(8,self.template if self.cstr(self.r(sp+8))=='fairwind_visual' else 0)
  elif a==0x4303c0:self.grouped=[];self.ret()
  elif a in [0x430340,0x430380] and self.r(sp+4)==MANAGER+0x14:self.it[cx]=[self.types,-1];self.ret(4,cx)
  elif a==0x4303a0:self.ret(0,self.it[cx][0][self.it[cx][1]])
  elif a==0x430400:self.grouped.append(self.r(sp+4));self.ret(4)
  else:super().hook(u,a,n,user)
 def upgrade(self,entry='value'):
  self.w(0x214000,self.fair);self.w(STACK+4,self.fair)
  self.fragment(0x423090 if entry=='value' else 0x424c1d,
   0x423095 if entry=='value' else 0x424c22,{UC_X86_REG_ESI:0x214000})
 def select(self):
  self.w(STACK,STOP);self.u.reg_write(UC_X86_REG_ESP,STACK);self.u.reg_write(UC_X86_REG_EAX,self.fair)
  self.u.emu_start(FAIR['selector_address'],STOP,count=100000)
  return self.u.reg_read(UC_X86_REG_EAX)
class FairWindTests(unittest.TestCase):
 def test_upgrade_once_and_registered_grouping(self):
  m=FairMachine();m.upgrade();self.assertEqual(m.r(m.fair),m.template);self.assertEqual(m.r(m.fair+0x10),60)
  for _ in range(5):m.upgrade('info');m.upgrade();self.assertEqual(m.r(m.fair+0x10),60)
  m.native(0x4232f0);self.assertIn(m.fair,m.grouped)
  self.assertEqual(m.r(m.template+0x18),250);self.assertEqual(m.r(m.typ+0x18),150)
 def test_native_icon_and_combat_cache_hooks(self):
  m=FairMachine();view=0x215000;m.w(view+0x64,m.fair)
  m.fragment(0x40cd80,0x40cd85,{UC_X86_REG_ESI:view})
  self.assertEqual(m.r(m.fair),m.template)
  self.assertEqual([m.r(view+0x54+i*4) for i in range(4)],[m.r(m.template+0x34+i*4) for i in range(4)])
  m.fragment(0x424c2a,0x424c2f,{UC_X86_REG_EAX:m.fair})
  self.assertEqual(m.u.reg_read(UC_X86_REG_EAX),m.r(m.template+0x30))
 def test_damaged_hull_and_renaming_keep_variant(self):
  m=FairMachine();m.w(m.fair+0x10,17);m.upgrade();self.assertEqual(m.r(m.fair+0x10),34)
  m.string(m.fair+4,'Renamed Ship');m.upgrade('info');self.assertEqual(m.r(m.fair),m.template);self.assertEqual(m.r(m.fair+0x10),34)
 def test_other_ships_and_missing_resources_are_unchanged(self):
  for name,tag in [('Enterprise','onemast'),('Fair Wind','junk'),('Fair Wind','twomast')]:
   m=FairMachine();m.string(m.fair+4,name);m.string(m.typ,tag);self.assertEqual(m.select(),m.typ);self.assertEqual(m.r(m.fair+0x10),30)
  for offset in [0x30,0x34,0x38,0x3c,0x40]:
   m=FairMachine();m.w(m.template+offset,0);self.assertEqual(m.select(),m.typ);self.assertEqual(m.r(m.fair),m.typ);self.assertEqual(m.r(m.fair+0x10),30)
 def test_cannon_limit_goods_and_gold(self):
  for goods,gold,expected in [(0,1000000,25),(10,1000000,24),(0,12000,10),(171,1000000,8)]:
   m=FairMachine();m.upgrade();m.w(m.q(m.fair),goods);m.setgold(gold)
   yard=0x214000;info=yard+0x80;m.w(yard+0xc,info);m.w(info,m.fair);m.w(yard+0x24,6000)
   m.native(SYMS['rg_max_cannons'],owner=yard);self.assertEqual(m.r(m.fair+0x14),expected)
 def test_v8_trailer_survives_type_upgrade_and_v9_roundtrip(self):
  m=FairMachine();m.w(m.q(m.fair),45);m.collect();self.assertEqual(m.call('rg_save',0x1234),1);v8=m.stream
  m.upgrade();m.call('rg_reset');m.collect();m.stream=v8;m.position=0
  self.assertEqual(m.call('rg_load',0x1234),1);self.assertEqual(m.r(m.q(m.fair)),45)
  m.stream=b'';m.position=0;m.collect();self.assertEqual(m.call('rg_save',0x1234),1)
  m.call('rg_reset');m.collect();m.position=0;self.assertEqual(m.call('rg_load',0x1234),1);self.assertEqual(m.r(m.q(m.fair)),45)
 def test_native_doubled_hull_loader(self):
  m=FairMachine()
  for base,expected in [(15,30),(30,60)]:
   m.fragment(0x451980,0x451985,{UC_X86_REG_EAX:base,UC_X86_REG_EDI:m.template,UC_X86_REG_ESI:0x214000})
   self.assertEqual(m.r(m.template+0x20),expected)
 def test_xml_stats_sprite_sizes_and_character_exclusivity(self):
  data=(OUT/'TW1_00.data').read_bytes();assets={};pos=8
  for _ in range(struct.unpack_from('<I',data,4)[0]):
   end=data.index(0,pos);name=data[pos:end].decode();off,size=struct.unpack_from('<II',data,end+1);assets[name]=data[off:off+size];pos=end+9
  key=b'klxd8794lkds87934poi'
  def xml(name):return ET.fromstring(bytes((v-key[i%len(key)])%256 for i,v in enumerate(assets['assets/xml/'+name+'.txt'])))
  ships=xml('ships');normal=ships.find('types/onemast');custom=ships.find('types/fairwind_visual')
  self.assertEqual(custom.findtext('cargo'),'250');self.assertEqual(custom.findtext('hitpoints'),'30')
  for tag in ['speed','cost','footprint','name','combatgrid','wakesprite']:self.assertEqual(ET.tostring(custom.find(tag)),ET.tostring(normal.find(tag)))
  chars=xml('characters');self.assertEqual(chars.find('douglas/fleet')[0].tag,'fairwind_visual')
  self.assertEqual(sum(1 for el in chars.iter('fairwind_visual')),1)
  sprites=xml('sprites');pages={el.get('name'):el for el in sprites if el.tag=='spritepage'}
  self.assertLess(int(pages['onemast_page'].findtext('framewidth')),95);self.assertLess(95,int(pages['twomast_page'].findtext('framewidth')))
  for prefix,w,h in [('',95,72),('_ally',95,72),('_enemy',66,50)]:
   page=pages['fairwind'+prefix+'_page'];self.assertEqual(page.findtext('framewidth'),str(w));self.assertEqual(page.findtext('frameheight'),str(h))
   for i in range(3):
    sprite=next(el for el in sprites if el.get('name')==f'fairwind{prefix}{i}');original=next(el for el in sprites if el.get('name')==f'sloop{prefix}{i}')
    self.assertEqual(sprite.get('xoffset'),str(w//2));self.assertEqual(sprite.get('yoffset'),str(h));self.assertEqual([x.text for x in sprite.findall('frame')],[x.text for x in original.findall('frame')])
  for stem,w,h in [('fleetstat_fairwind',130,89),('fl_fairwind',380,216),('el_fairwind',264,150)]:
   folder='ui/hud/' if stem.startswith('fleetstat') else 'combatview/ships/'
   mask=Image.open(BytesIO(assets['assets/graphics/'+folder+stem+'_alpha.png']));self.assertEqual(mask.mode,'P');self.assertEqual(mask.size,(w,h));self.assertEqual(mask.convert('L').getpixel((0,0)),0);self.assertGreater(mask.convert('L').getextrema()[1],250)
   if not stem.startswith('fleetstat'):
    color=Image.open(BytesIO(assets['assets/graphics/'+folder+stem+'.png']));fw,fh=w//4,h//3
    frames=[color.crop((i*fw,j*fh,(i+1)*fw,(j+1)*fh)) for j in range(3) for i in range(4)]
    self.assertTrue(all(ImageChops.difference(frames[0],frames[i]).getbbox() for i in [1,2,3,4,8]))
if __name__=='__main__':
 import sys
 unittest.main(argv=[__file__]+[arg for arg in sys.argv[1:] if arg not in ['--output',str(OUT)]],verbosity=2)
