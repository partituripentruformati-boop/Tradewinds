Tradewinds v18 TEST — Tea in the normal Buy/Sell window

Tea appears between General Merchandise and Arms in BOTH market panels.
The lower trading window now has its own Tea quantity box and minus/plus/Max
controls. Set Tea's quantity there and use the existing main Buy or Sell button.
Sell All includes Tea. Original four commodities still use their native handler;
Tea's selected trade runs first, then the native four-item action continues.
Buying is bounded by funds and capacity. Tea input resets after trade completion.
The separate upper Tea Buy/Max/Sell/Max shortcuts remain available on a spaced
row below Dream Dust. The lower window is expanded/repositioned to fit above
the log panel. All v17 spacing improvements are included.

Tea buys ONLY in Tanchon and can be sold elsewhere. Spices and Jade remain
disabled. Warehouse/fleet selection applies to Tea in either panel. Existing
Tea price changes, save extension, icons and all ship/warehouse upgrades remain.
No new global command registrations are added; the v16 routing approach remains.
This package changes both executable and data to implement the lower controls.

INSTALL AND TEST
Close Tradewinds; back up saves and the current patch executable/TW1_00.data.
Extract this ZIP and copy BOTH the executable and TW1_00.data into the original
game folder alongside its original DLLs and TW1_01.data. Launch the patched EXE.
Open Buy in Tanchon: set a small Tea quantity in the lower row, then click Buy.
Open Sell: set Tea quantity and click Sell; test Sell All on a backup save.
Check warehouse trades, mixed Tea/original goods and save/reload.
If it crashes, send Tradewinds-startup.log (first line now says v18).
Keep pre-Tea saves and v15 files for rollback; saving in v15 drops Tea inventory.

VALIDATION
94 existing regression checks, 18 Tea integration tests, eight Fair Wind tests,
eight startup diagnostic checks and five new lower-trade tests passed.
Lower-trade tests cover native command stack cleanup, Buy/Sell selected Tea,
Sell All, plus/minus/Max, source-port restrictions, warehouse trading, order
and window bounds. Native original four-item execution functions/Windows APIs
are mocked for these integration checks; actual Windows gameplay needs testing.
Real Wine/QEMU startup reached all 11 building-constructor entry markers without
a logged crash; the runner still has its graphics-mode limitation.

REBUILD
source/build_tea_trade_patch.py --base-v7 <working v7 folder> --output <folder>
Requires Python, pefile, capstone, Pillow, gcc -m32 and GNU binutils; tests use
Unicorn. All Tea-only source and supplied artwork assets are included.
