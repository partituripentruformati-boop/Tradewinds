from pathlib import Path
import sys,struct,json,argparse,xml.etree.ElementTree as ET
ROOT=Path(__file__).parent;sys.path.insert(0,str(ROOT/'python-libs'))
import pefile
from unicorn import Uc,UC_ARCH_X86,UC_MODE_32,UC_HOOK_CODE
from unicorn.x86_const import *
parser=argparse.ArgumentParser()
parser.add_argument('--output',type=Path,required=True)
parser.add_argument('--original-data',type=Path,required=True)
args=parser.parse_args()
OUT=args.output;exe=OUT/'TradewindsClassic_100Ships_2xHull_ShipyardCatalog_TEST.exe';pe=pefile.PE(str(exe))
syms=json.loads((OUT/'patch-manifest.json').read_text())['symbols']
TYPES=['junk','onemast','twomast','brigantine','megaship'];COSTS=[1000,8000,12000,20000,30000]
YARD=0x210000;MANAGER=0x200100;FLEET=0x200200;PLAYER=0x200300;STACK=0x318000
passed=[]
class Machine:
 def __init__(self,count=1):
  self.u=Uc(UC_ARCH_X86,UC_MODE_32)
  for base,size in [(0,0x1000),(0x400000,0x80000),(0x200000,0x80000),(0x300000,0x20000)]:self.u.mem_map(base,size)
  self.u.mem_write(0x400000,pe.get_memory_mapped_image())
  self.w(0x465d68,0x200400);self.w(0x465dac,MANAGER);self.w(0x465d74,PLAYER);self.w(FLEET,count)
  self.u.reg_write(UC_X86_REG_ESP,STACK);self.u.reg_write(UC_X86_REG_ESI,YARD)
  self.u.reg_write(UC_X86_REG_EBX,0);self.u.reg_write(UC_X86_REG_EBP,0x12345678)
  self.registered={};self.created=[];self.freed=[];self.notifications=0;self.shown=[];self.random_calls=0;self.next=0x220000;self.stops=set();self.alloc=0x250000
  self.u.hook_add(UC_HOOK_CODE,self.hook)
 def r(self,a):return struct.unpack('<I',self.u.mem_read(a,4))[0]
 def w(self,a,v):self.u.mem_write(a,struct.pack('<I',v&0xffffffff))
 def str(self,a):
  b=bytearray()
  while (v:=bytes(self.u.mem_read(a+len(b),1)))!=b'\0':b+=v
  return b.decode()
 def string(self,a,text):
  p=self.alloc;self.alloc+=0x100;self.u.mem_write(p,text.encode()+b'\0');self.w(a,len(text));self.w(a+4,p)
 def ret(self,pop=0,eax=None):
  esp=self.u.reg_read(UC_X86_REG_ESP);dest=self.r(esp)
  self.u.reg_write(UC_X86_REG_ESP,esp+4+pop)
  if eax is not None:self.u.reg_write(UC_X86_REG_EAX,eax)
  self.u.reg_write(UC_X86_REG_EIP,dest)
 def hook(self,u,a,n,user):
  if a in self.stops:u.emu_stop();return
  esp=u.reg_read(UC_X86_REG_ESP);ecx=u.reg_read(UC_X86_REG_ECX)
  if a==0x4375c7:self.random_calls+=1;raise AssertionError('Random generator unexpectedly reached')
  if a==0x42d0e0:
   self.string(ecx,self.str(self.r(esp+4)));self.ret(4,ecx)
  elif a==0x42d330:self.ret(0,self.r(ecx+4))
  elif a==0x4346f0:
   assert ecx==0x200400
   command=self.str(self.r(esp+4));owner=self.r(esp+8)
   assert command not in self.registered
   self.registered[command]=owner;self.ret(8)
  elif a==0x42d390:
   self.ret(4,int(self.str(self.r(ecx+4))==self.str(self.r(esp+4))))
  elif a==0x424480:
   assert ecx==MANAGER
   name=self.str(self.r(esp+8));assert name in TYPES
   assert self.r(esp+12)==0x3f800000 and self.r(esp+16)==1 and self.r(esp+20)==0
   ptr=self.next;self.next+=0x100;self.w(ptr+0x2c,COSTS[TYPES.index(name)]);self.w(ptr+0x14,1)
   self.u.mem_write(ptr+0x31,b'\x01');self.created.append((name,ptr));self.ret(20,ptr)
  elif a==0x4232f0:assert ecx==MANAGER;self.ret(0,FLEET)
  elif a==0x42d1a0:self.ret(0)
  elif a==0x4373ff:self.freed.append(self.r(esp+4));self.ret(0)
  elif a==0x427240:self.shown.append(self.r(YARD+0x10));self.ret(0)
  elif a==0x4137b0:self.notifications+=1;self.ret(12)
  elif a==0x42d180:self.string(ecx,'');self.ret(0,ecx)
  elif a==0x42d230:self.string(ecx,self.str(self.r(esp+4)));self.ret(4,ecx)
  elif a==0x42d1d0:
   self.string(ecx,self.str(self.r(self.r(esp+4)+4)));self.ret(4,ecx)
  elif a==0x423140:
   self.purchased=self.r(esp+4);self.w(FLEET,self.r(FLEET)+1);self.ret(4)
  elif a==0x414760:
   cost=self.r(esp+4)+(self.r(esp+8)<<32);gold=self.r(PLAYER+0x10)+(self.r(PLAYER+0x14)<<32)
   gold-=cost;self.w(PLAYER+0x10,gold);self.w(PLAYER+0x14,gold>>32);self.ret(8)
  elif a==0x4260c0:
   ship=self.r(self.r(YARD+0x0c));price=self.r(YARD+0x24)
   gold=self.r(PLAYER+0x10)+(self.r(PLAYER+0x14)<<32)
   assert gold>=price
   self.w(ship+0x14,self.r(ship+0x14)+1)
   gold-=price;self.w(PLAYER+0x10,gold);self.w(PLAYER+0x14,gold>>32)
   self.notifications+=1;self.ret()
  elif a==0x4154d0:self.ret()
 def run(self,a,stops):
  self.stops=set(stops);self.u.emu_start(a,0,count=20000)
  assert self.u.reg_read(UC_X86_REG_EIP) in self.stops

def check(label):passed.append(label);print('PASS',label)
# Execute the native registration routine, mocking only its dictionary storage
# and string methods. Each XML command must route to the Shipyards instance.
m=Machine();m.u.reg_write(UC_X86_REG_EAX,0x234500);m.w(STACK,0xabcdef01)
m.run(0x4251d8,[0x4251df])
assert m.registered==dict({'yard_'+name:YARD for name in TYPES},buy_max_cannons=YARD)
assert m.r(YARD+0x2c)==0x234500
assert m.u.reg_read(UC_X86_REG_ESP)==STACK+4
assert m.u.reg_read(UC_X86_REG_EDI)==0xabcdef01
assert m.u.reg_read(UC_X86_REG_ESI)==YARD and m.u.reg_read(UC_X86_REG_EBX)==0
check('Native router registers all five commands and preserves initialization frame')
for name in TYPES:
 assert m.registered['yard_'+name]==YARD
 m.u.reg_write(UC_X86_REG_ESP,STACK);m.string(STACK+0x20,'yard_'+name)
 m.run(0x427545,[0x4277a3]);assert m.created[-1][0]==name
 check('Registered click routes to matching offer: '+name)
for name in TYPES:
 m=Machine();m.w(syms['selected'],syms['type_'+name]);m.u.reg_write(UC_X86_REG_ECX,MANAGER);m.w(STACK,0x47f000)
 m.run(syms['make_offer'],[0x47f000]);assert m.created[0][0]==name
 assert m.u.reg_read(UC_X86_REG_ESP)==STACK+4
 assert m.u.reg_read(UC_X86_REG_ESI)==YARD
 assert bytes(m.u.mem_read(m.created[0][1]+0x31,1))==b'\0'
 check('Factory '+name+': full hull, one cannon, unowned offer, balanced stack')
for name in TYPES:
 for previous in [0,0x230000]:
  m=Machine();m.w(YARD+0x10,previous);m.string(STACK+0x20,'yard_'+name)
  m.run(0x427545,[0x4277a3]);assert m.created[0][0]==name
  assert m.shown==[m.created[0][1]] and m.r(YARD+0x10)==m.created[0][1]
  assert m.freed==([previous] if previous else [])
  assert m.u.reg_read(UC_X86_REG_ESP)==STACK
  check('Catalog '+name+(' replaces old offer' if previous else ' creates missing offer'))
m=Machine();m.string(STACK+0x20,'repair_all');m.run(0x427545,[0x42754a]);assert m.r(STACK-4)==0x456288 and not m.created
check('Unrelated actions resume original dispatcher')
for count in [99,100]:
 m=Machine(count);m.string(STACK+0x20,'yard_megaship');m.run(0x427545,[0x4277a3]);assert bool(m.created)==(count<100)
 check('Catalog respects fleet count '+str(count))
for count in [1,99,100]:
 m=Machine(count);m.u.reg_write(UC_X86_REG_ECX,YARD);m.run(0x4273f0,[0x4274a3])
 assert bool(m.created)==(count<100);assert m.random_calls==0
 if count<100:assert m.r(YARD+0x10)==m.created[0][1]
 check('Native availability path fleet '+str(count)+': no random gate')
for name in TYPES:
 m=Machine(2);m.w(syms['selected'],syms['type_'+name]);m.w(YARD+0x10,0x230000)
 for i in range(4):
  m.u.reg_write(UC_X86_REG_ESP,STACK);m.run(0x425731,[0x425739])
  assert m.r(YARD+0x10)==m.created[-1][1] and m.created[-1][0]==name
  assert m.u.reg_read(UC_X86_REG_ESP)==STACK+12
 assert len({p for _,p in m.created})==4 and not m.freed
 check('Restock '+name+': four distinct offers, purchased objects never freed')
m=Machine(100);m.w(YARD+0x10,0x230000);m.run(0x425731,[0x425739]);assert not m.created and m.r(YARD+0x10)==0
check('Restock stops at fleet limit 100')
for gold in [0,999,1000,1001,2**32+500]:
 m=Machine();ship=0x230000;m.w(ship+0x2c,1000);m.w(YARD+0x10,ship)
 m.w(PLAYER+0x10,gold);m.w(PLAYER+0x14,gold>>32);m.w(STACK,0x47f000);m.u.reg_write(UC_X86_REG_ECX,YARD)
 m.run(0x425590,[0x42564e,0x425739])
 success=m.u.reg_read(UC_X86_REG_EIP)==0x42564e
 assert success==(gold>=1000)
 actual=m.r(PLAYER+0x10)+(m.r(PLAYER+0x14)<<32)
 assert actual==gold-(1000 if success else 0)
 assert m.r(FLEET)==(2 if success else 1)
 check('Native purchase affordability and gold deduction: gold '+str(gold))
# Bulk purchase capacity and gold boundary checks. Native single-cannon
# purchase is stubbed; injected eligibility/repeat logic executes as x86.
for cargo,current,goods,gold,price,owned in [
 (25,1,0,100000,6000,1),(150,1,0,1000000,6000,1),
 (200,1,0,1000000,6000,1),(300,1,0,1000000,6000,1),
 (350,1,0,1000000,6000,1),(150,2,105,1000000,6000,1),
 (150,15,0,1000000,6000,1),(150,1,0,5999,6000,1),
 (150,1,0,6000,6000,1),(150,1,0,17999,6000,1),
 (350,1,0,2**32+500,6000,1),(150,1,0,12000,3000,1),
 (150,1,0,1000000,6000,0),(150,1,0,1000000,0,1)]:
 m=Machine();ship=0x230000;info=0x231000;typ=0x232000
 m.w(YARD+0x0c,info);m.w(info,ship);m.w(ship,typ);m.w(typ+0x18,cargo)
 m.w(ship+0x14,current);m.w(ship+0x18,goods);m.u.mem_write(ship+0x31,bytes([owned]))
 m.w(YARD+0x24,price);m.w(PLAYER+0x10,gold);m.w(PLAYER+0x14,gold>>32)
 m.u.reg_write(UC_X86_REG_ECX,YARD);m.w(STACK,0x47f000)
 m.run(syms['buy_max_cannons'],[0x47f000])
 amount=min(max(0,(cargo-current*10-goods)//10),gold//price) if owned and price>0 else 0
 assert m.r(ship+0x14)==current+amount and m.notifications==amount
 assert m.r(PLAYER+0x10)+(m.r(PLAYER+0x14)<<32)==gold-amount*price
 assert m.u.reg_read(UC_X86_REG_ESP)==STACK+4
 check(f'Max cannons: cargo={cargo}, current={current}, goods={goods}, gold={gold}, price={price}, owned={owned}')
m=Machine();m.string(STACK+0x20,'buy_max_cannons');m.run(0x427545,[0x4277a3]);assert m.notifications==0
check('Bulk command safely handles no selected ship')
# Archive roundtrip and unchanged unrelated content.
def unpack(data):
 out={};pos=8
 for _ in range(struct.unpack_from('<I',data,4)[0]):
  end=data.index(0,pos);name=data[pos:end].decode();off,n=struct.unpack_from('<II',data,end+1);pos=end+9
  assert off+n<=len(data);out[name]=data[off:off+n]
 return out
old=unpack(args.original_data.read_bytes());new=unpack((OUT/'TW1_00.data').read_bytes())
assert old.keys()==new.keys()
for name in old:
 if name!='assets/xml/int_buildings.txt':assert old[name]==new[name]
key=b'klxd8794lkds87934poi';decode=lambda b:bytes((v-key[i%len(key)])%256 for i,v in enumerate(b))
a=decode(old['assets/xml/int_buildings.txt']);b=decode(new['assets/xml/int_buildings.txt']);xml=ET.fromstring(b)
menu=xml.find('shipyard_menu/children');actions=[el.findtext('onlclick') for el in menu]
for name in TYPES:assert actions.count('yard_'+name)==1
assert 'repair_all' in actions and 'endshipyards' in actions
assert xml.find('ship_options/children/buymaxcannons').findtext('onlclick')=='buy_max_cannons'
assert xml.find('ship_options/children/sellcannon').findtext('y')=='100'
assert xml.find('ship_options/children/back').findtext('y')=='125'
before=a[:a.index(b'\t<ship_options ')];assert b[:len(before)]==before
check('Asset archive: five catalog entries; repairs, leave, unrelated assets preserved')
for name in TYPES:
 assert menu.find('label_'+name).findtext('text')
 assert menu.find('catalog_'+name).findtext('width')=='64'
 assert int(menu.find('catalog_'+name).findtext('x'))==340
 assert int(menu.find('label_'+name).findtext('x'))==18
 assert menu.find('cargo_'+name).findtext('text')==str([25,150,200,300,350][TYPES.index(name)])
rows=[int(menu.find('catalog_'+name).findtext('y')) for name in TYPES]
assert rows==[26,49,72,95,118]
assert menu.find('fixall').findtext('y')==menu.find('ok').findtext('y')=='148'
assert int(xml.find('shipyard_menu').findtext('y'))+int(xml.find('shipyard_menu').findtext('height'))<490
check('UI layout: aligned type/cargo/Buy columns, spaced rows and separate footer above log')
assert pe.OPTIONAL_HEADER.CheckSum==pe.generate_checksum()
assert pe.sections[-1].VirtualAddress==0x70000 and pe.OPTIONAL_HEADER.SizeOfImage==0x71000
check('PE section mapping and checksum')
(OUT/'validation.txt').write_text('\n'.join('PASS '+s for s in passed)+'\n\nThese are x86 emulation checks with engine/Windows calls stubbed. The full Windows game, UI rendering and save/load have not been tested.\n')
print(len(passed),'checks passed')
