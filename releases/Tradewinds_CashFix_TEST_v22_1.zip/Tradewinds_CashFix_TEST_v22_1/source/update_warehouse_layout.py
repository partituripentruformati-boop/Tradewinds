"""Add aligned Tea warehouse rows and package generated art for the P8 engine."""
from pathlib import Path
import argparse,copy,xml.etree.ElementTree as E
from PIL import Image,ImageOps
from fix_xml_format import entries,pack,decode,encode
p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True);p.add_argument('--icon-source',type=Path,required=True);a=p.parse_args();path=a.output/'TW1_00.data';assets=entries(path.read_bytes());m=dict(assets);name='assets/xml/int_buildings.txt';u=E.fromstring(decode(m[name]));w=u.find('warehouse');c=w.find('children')
def setv(node,key,value):
 el=node.find(key)
 if el is None:el=E.SubElement(node,key)
 el.text=str(value)
for i,y in [(1,65),(2,121),(3,149),(4,177)]:
 setv(c.find('icon'+str(i)),'y',y)
 for prefix in ['prod','value','qty']:setv(c.find(prefix+str(i)),'y',y+5)
setv(c.find('rgicon0'),'x',7);setv(c.find('rgicon0'),'y',91)
setv(c.find('rgn0'),'y',98);setv(c.find('rgw0'),'x',300);setv(c.find('rgw0'),'y',98)
value=copy.deepcopy(c.find('value1'));value.tag='rgv0';setv(value,'y',98);c.append(value)
for tag in ['rgl0','rgd0']:c.remove(c.find(tag))
setv(c.find('warehouseframe'),'height',215)
for i,y in [(1,235),(2,285),(3,310),(4,335)]:
 for prefix in ['iconb','prodb','dec','edit','inc','max']:setv(c.find(prefix+str(i)),'y',y if prefix in ['iconb','edit']else y+5)
for original,tag,y,command in [('iconb1','rwicon0',258,None),('prodb1','rwname0',265,None),('edit1','rga0',260,None),('dec1','rwdec0',265,'trade_inc(rw0-)'),('inc1','rwinc0',265,'trade_inc(rw0+)'),('max1','rwmax0',265,'trade_inc(rw0M)')]:
 node=copy.deepcopy(c.find(original));node.tag=tag;setv(node,'y',y)
 if tag=='rwicon0':setv(node,'x',7);node.find('bitmap').set('bitmap','assets/graphics/ui/popup/icon_tea.png')
 if tag=='rwname0':setv(node,'text','Tea')
 if command:setv(node,'onlclick',command)
 c.append(node)
setv(c.find('transfer'),'y',370);setv(c.find('transfer'),'onlclick','trade_inc(rw0t)')
for tag in ['leave','sell']:setv(c.find(tag),'y',405)
setv(c.find('fleetframe'),'height',205);setv(w,'height',435)
for parent,tag,y in [(u.find('marketplace/children'),'rgicon0',74),(u.find('trade_menu/children'),'rticon0',28)]:setv(parent.find(tag),'x',7);setv(parent.find(tag),'y',y)
m[name]=encode(E.tostring(u,encoding='ascii',xml_declaration=False))
# Convert generated transparent artwork into a 24px indexed PNG for GapiDraw.
im=Image.open(a.icon_source).convert('RGBA');bounds=im.getchannel('A').getbbox();assert bounds;im=im.crop(bounds);im.thumbnail((24,24),Image.Resampling.LANCZOS)
canvas=Image.new('RGBA',(24,24));canvas.alpha_composite(im,((24-im.width)//2,(24-im.height)//2));rgb=canvas.convert('RGB').quantize(colors=255,dither=Image.Dither.NONE)
pixels=[0 if alpha<128 else idx+1 for idx,alpha in zip(rgb.getdata(),canvas.getchannel('A').getdata())];out=Image.new('P',(24,24));out.putdata(pixels);palette=[0,0,0]+rgb.getpalette()[:765];out.putpalette(palette);out.info['transparency']=0
icon=a.output/'Tea_icon_preview.png';out.save(icon,transparency=0);m['assets/graphics/ui/popup/icon_tea.png']=icon.read_bytes()
path.write_bytes(pack([(n,m[n])for n,_ in assets]));assert u.find('marketplace/children/tea_source_note') is None;assert c.find('rgl0') is None;assert c.find('rgd0') is None
assert [int(c.findtext(tag+'/y'))for tag in ['prod1','rgn0','prod2','prod3','prod4']]==[70,98,126,154,182]
print('Warehouse panels aligned; normal Transfer includes Tea; icon packaged at 24x24 P8')
